import json,sys,subprocess,os,re
sys.path.insert(0,'/home/claude')
from montage_lib import *
from PIL import Image
from curated_spec import ROUNDS
BOX=json.load(open('/home/claude/det/boxes.json')); DY=json.load(open('/home/claude/mont/name_dy.json'))
SP=json.load(open('/home/claude/curated_spans.json'))
ENC='-c:v libx264 -preset fast -crf 21 -profile:v high -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 -c:a aac -b:a 64k -ar 16000 -ac 1'
UP='/mnt/user-data/uploads/'; OUT='/mnt/user-data/outputs/curated_cut/'
def vol(src,ss,dur,key):
    r=subprocess.run(['ffmpeg','-nostdin','-v','info','-ss',f'{ss:.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-af','volumedetect','-f','null','-'],capture_output=True,text=True).stderr
    m=re.search(key+r': (-?[\d.]+) dB',r); return float(m.group(1)) if m else -91.0
def extend_short(n,s,e,minlen):
    m=seg_map(n); mid=(s+e)/2
    i=next((k for k,(a,b,o) in enumerate(m) if a<=mid<=b),min(range(len(m)),key=lambda k:abs((m[k][0]+m[k][1])/2-mid)))
    S_i,E_i,a=m[i]; os_=a+(s-S_i); oe=a+(e-S_i); src=UP+plans[n]['file']
    for T in (minlen,minlen-0.2,minlen-0.4):
        for l in (0.12,0.5,0.9,1.3):          # try padding the end first, then add silence before the answer too
            ss=os_-l; tail=ss+T-oe
            if l>0.2 and vol(src,ss,l,'max_volume')>=-32: continue
            if tail>0.05 and vol(src,oe,tail,'max_volume')>=-32: continue
            return src,ss,T
    return None
def make_seq(n,variant,cid,dur):
    N=int(round(dur*48)); d=f'/home/claude/mont/seq/{cid}'; os.makedirs(d,exist_ok=True)
    c=f'/home/claude/mont/cache/{n}'+('_name' if variant=='name' else ''); blank=f'/home/claude/mont/cache/blank_{n}_{variant}.png'
    if not os.path.exists(blank): Image.new('RGBA',Image.open(f'{c}/hold.png').size,(0,0,0,0)).save(blank)
    n_in=54; n_ex=31; ex=max(n_in,N-46) if N>=100 else N+99
    off=12 if N<130 else 0
    for k in range(N):
        if k<n_in-off: t=f'{c}/in_{k+off:04d}.png'
        elif k>=ex+n_ex: t=blank
        elif k>=ex: t=f'{c}/out_{k-ex:04d}.png'
        else: t=f'{c}/hold.png'
        lk=f'{d}/{k:04d}.png'
        if os.path.lexists(lk): os.remove(lk)
        os.symlink(t,lk)
    return d
os.makedirs('/home/claude/mont/cut',exist_ok=True)
sh=['cd /home/claude','rm -f mont/cut_build.log']; files=[]; notes=[]
def add(cmd): sh.append(cmd+' && echo ok >> mont/cut_build.log || echo FAIL >> mont/cut_build.log')
cur_round=-1; idx=0; shown=set()
for o in SP:
    if o['round']!=cur_round:
        cur_round=o['round']; tf=f'/home/claude/mont/cut/{cur_round:02d}_title.mp4'
        add(f'ffmpeg -y -nostdin -v error -framerate 48 -i /home/claude/mont/ctitle_{cur_round}/%04d.png -f lavfi -i anullsrc=r=16000:cl=mono -t 2.4 -vf "fade=t=out:st=2.2:d=0.2,format=yuv420p" {ENC} -shortest {tf}')
        files.append(tf)
    idx+=1; n=o['n']; ln=o['e']-o['s']; bx=BOX[n]; needs_full=n not in shown
    minlen=2.6
    if ln<minlen:
        ex=extend_short(n,o['s'],o['e'],minlen)
        if ex: src,ss,dur=ex; notes.append(f'{n} "{o["text"][:40]}": {ln:.1f}s -> {dur:.1f}s (padded with original footage)')
        else:
            src=f'/mnt/user-data/outputs/softcut/{NAMES[n]}_softcut.mp4'; ss=o['s']+SHIFT.get(n,0); dur=ln; notes.append(f'{n} "{o["text"][:40]}": {ln:.1f}s could NOT be padded')
    elif o['kind']=='orig': src=UP+plans[n]['file']; ss=o['so']; dur=ln
    else: src=f'/mnt/user-data/outputs/softcut/{NAMES[n]}_softcut.mp4'; ss=o['s']+SHIFT.get(n,0); dur=ln
    variant='full'
    if variant=='full': shown.add(n)
    mean=vol(src,ss,dur,'mean_volume'); gain=max(-12,min(15,-18.5-mean))
    seq=make_seq(n,variant,f'c{idx:02d}_{n}',dur); oy=877 if variant=='full' else int(round(877+DY[n]))
    vf=(f'[0:v]fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:{oy}:shortest=1,fade=t=in:st=0:d=0.08,fade=t=out:st={dur-0.08:.3f}:d=0.08[v]')
    af=(f'[0:a]aresample=16000,aformat=channel_layouts=mono,volume={gain:.2f}dB,alimiter=limit=0.89,afade=t=in:st=0:d=0.06,afade=t=out:st={dur-0.09:.3f}:d=0.09[a]')
    out=f'/home/claude/mont/cut/{idx:02d}_{n}.mp4'
    add(f'ffmpeg -y -nostdin -v error -ss {ss:.3f} -t {dur:.3f} -i "{src}" -framerate 48 -i {seq}/%04d.png -filter_complex "{vf};{af}" -map "[v]" -map "[a]" -t {dur:.3f} {ENC} {out}')
    files.append(out)
open('/home/claude/mont/list_cut.txt','w').write(''.join(f"file '{f}'\n" for f in files))
sh.append(f'mkdir -p {OUT}')
pass
sh.append('echo ALLDONE >> mont/cut_build.log')
open('/home/claude/mont/cut_build.sh','w').write('\n'.join(sh)+'\n'); print(len(files),'files;',len(sh),'steps'); print('\n'.join(notes))
