import re,subprocess,json,glob,numpy as np
cmds=[l for l in open('/home/claude/mont/cut_build.sh') if '-ss ' in l and '/mont/seq/c' in l]
items=[]
for l in cmds:
    m=re.search(r'-ss ([\d.]+) -t ([\d.]+) -i "([^"]+)".*?/mont/seq/(c\d+_\w+)/',l)
    items.append((float(m.group(1)),float(m.group(2)),m.group(3),m.group(4)))
clips=sorted(c for c in glob.glob('/home/claude/mont/cut/[0-9][0-9]_*.mp4') if 'title' not in c)
assert len(items)==len(clips)==60
def aud(path,ss,dur):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',path,'-vn','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(r,np.int16).astype(float)/32768
def vid(path,ss,dur):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',path,'-an','-vf','fps=16,crop=iw*0.62:ih*0.72:iw*0.19:ih*0.04,scale=64:48,format=gray','-f','rawvideo','-'],capture_output=True).stdout
    return np.frombuffer(r,np.uint8).reshape(-1,48,64).astype(float)
def xcorr(x,y):   # find where x (short) sits inside y (long); return sample offset
    n=len(y)+len(x); F=1<<(n-1).bit_length()
    X=np.fft.rfft(x[::-1]-x.mean(),F); Y=np.fft.rfft(y-y.mean(),F); c=np.fft.irfft(X*Y,F)[len(x)-1:len(y)]
    # normalise by local energy
    cs=np.cumsum(np.concatenate([[0],(y-y.mean())**2])); en=np.sqrt(np.maximum(cs[len(x):len(y)+1]-cs[:len(y)-len(x)+1],1e-9))
    return c[:len(en)]/ (en*np.sqrt(((x-x.mean())**2).sum())+1e-9)
out=[]
for i,((ss,dur,src,cid),clip) in enumerate(zip(items,clips),1):
    W=2.0; seg=min(1.4,dur*0.7); ts=max(0.35,(dur-seg)/2)       # analyse a stretch from the middle of the clip
    # --- audio: where does this stretch come from in the source?
    ca=aud(clip,ts,seg); sa=aud(src,ss+ts-W,seg+2*W)
    if len(sa)<len(ca)+10 or np.abs(ca).max()<1e-3: out.append((i,cid,None,None,None)); continue
    cc=xcorr(ca,sa); pk=int(np.argmax(cc)); a_off=(max(0,ss+ts-W)+pk/16000)-(ss+ts)
    # --- video: same question for the picture
    cv=vid(clip,ts,seg); sv=vid(src,ss+ts-W,seg+2*W); n=len(cv)
    if n<4 or len(sv)<n+2: out.append((i,cid,round(a_off,3),None,None)); continue
    best=None
    for s0 in range(0,len(sv)-n+1):
        e=np.mean((sv[s0:s0+n]-cv)**2)
        if best is None or e<best[1]: best=(s0,e)
    v_off=(max(0,ss+ts-W)+best[0]/16)-(ss+ts)
    out.append((i,cid,round(a_off,3),round(v_off,3),round(v_off-a_off,3)))
json.dump(out,open('/home/claude/verify_sync2.json','w'))
print('DONE',flush=True)
