import sys,json,os,shutil,subprocess
sys.path.insert(0,'/home/claude')
from reedit_lib import *
OLD=json.load(open('/home/claude/mont/re/manifest.json'))['sections']; OLDMAP={q:[o for o,d in row] for q,row in OLD}
ROOT='/home/claude/mont/re2'; shutil.rmtree(ROOT,ignore_errors=True); os.makedirs(ROOT+'/items'); os.makedirs(ROOT+'/seq')
def R(q,i): return ('reuse',q,i)
def S(n,sp,ep,**o): return ('single',n,sp,ep,o)
def SP(mode,A,B,kw=None): return ('split',mode,A,B,kw)
def C(n,sp,ep,**o): return (n,sp,ep,o)
SECTIONS=[
 (1,[R(1,0),R(1,1),R(1,2),R(1,3),R(1,4)]),
 (2,[R(2,0),R(2,1),R(2,2),S('Arijit','good at cooking and I like to cook Italian','made the best',buf=2.0)]),            # Riddhima's stalled clip removed
 (3,[S('Ananya','I would proudly say','and drawing',buf=1.5),R(3,1),S('Riddhima','very efficient at packing','able to do that',buf=1.5),S('Monesh','experience has taught me how to connect dots','minimal preparation',buf=1.5)]),
 (4,[R(4,0),R(4,1),R(4,2),R(4,3),R(4,4)]),
 (5,[R(5,0),R(5,1),R(5,2),R(5,3),S('Shobhita',"The phrase that I've heard the most",'in Deloitte',buf=1.5)]),
 (6,[S('Malavikka',"I think it's dynamic",'dynamic'),S('Mohammed','I would say my project is dynamic','figure out'),S('Irin','My project in one word','detectives'),
     S('Ananya','If I had to describe my work','something to investigate'),S('Ayush','Intriguing','Intriguing'),
     S('Riddhima','to describe my project in one word','interesting and unique',buf=1.5),R(6,3),R(6,4),R(6,5)]),
 (7,[R(7,0),R(7,1),S('Monesh',"I'm excited to learn more",'energetic crowd',buf=1.5)]),
 (8,[R(8,0),R(8,1),R(8,2)]),
 (9,[S('Malavikka','one word to describe my new team is supportive','very supportive',buf=1.5),R(9,1),R(9,2),S('Monesh','financial superheroes','terrorist financing',buf=1.5)]),
 (10,[SP('chorus',C('Ananya','that would be Love You Zindagi','Love You Zindagi',complete=False),C('Malavikka','I think Love You Zindagi','Love You Zindagi',complete=False),kw='Love You Zindagi'),
      S('Irin','My theme song would be 7 Rings by Ariana','7 Rings by Ariana',buf=1.5),S('Riddhima','Wake Up Sid',"hustle I'm facing",buf=1.5,complete=False),
      S('Shobhita',"Shin Chan's theme song",'get things done',buf=1.5),R(10,4),R(10,6),S('Arijit',"Don't Stop Me Now by Queen",'by Queen',buf=2.0)]),   # Mohammed's Shoe Dog clip removed
]
cmds=[]; notes=[]; idx=100
XD2=0.25
def addcmd(c,out): cmds.append(c+f' && echo ok >> {ROOT}/items.log || echo FAIL {out} >> {ROOT}/items.log')
def make_clip(spec):
    n,sp,ep,o=spec; c=clip_def(n,sp,ep,complete=o.get('complete',True)); c['opts']=o
    c['real_end']=c['end']; c['freeze']=0.0; c['ext']=0.0; c['lis']=None
    B=o.get('buf',0.0)
    if B>0:
        mind,mg=(1.0,(0.08,0.08)) if n=='Riddhima' else (1.5,(0.3,0.2))
        ls,avail=find_listen(n,B+XD2,mind,mg)
        if ls is not None and avail>=0.7:
            Lis=min(B+XD2,avail); c['lis']=(ls,Lis); c['ext']=Lis-XD2
        else: c['freeze']=min(B,0.4)
    return c
def vlen_of(c):
    L=c['real_end']-c['ss']
    if c['sq']: L=L-(c['sq'][1]-c['sq'][0])+0.45
    return L
def single(i,spec):
    c=make_clip(spec[1:5]); n=c['n']; vlen=vlen_of(c); out_dur=vlen+c['ext']+c['freeze']; gain=gain_for(c); seg=c['real_end']-c['ss']
    seq=make_seq(n,f'j{i:03d}_{n}',out_dur,root=ROOT+'/seq'); bx=BOX[n]; inputs=f'-ss {c["ss"]:.3f} -t {seg:.3f} -i "{c["src"]}" -framerate 48 -i {seq}/%04d.png'
    pre=('[0:v]'+squeeze_video(c)+'[vs];[vs]') if c['sq'] else '[0:v]'
    if c['lis']:
        ls,Lis=c['lis']; inputs+=f' -ss {ls:.3f} -t {Lis+0.05:.3f} -i "{c["src"]}"'
        vf=(f'{pre}fps=16,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[cv];[2:v]fps=16,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[lv];'
            f'[cv][lv]xfade=transition=fade:duration={XD2}:offset={vlen-XD2:.3f}[xv];[xv]fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:877:shortest=1[v]')
    else:
        tp=f'tpad=stop_mode=clone:stop_duration={c["freeze"]:.3f},' if c['freeze']>0.01 else ''
        vf=f'{pre}{tp}fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:877:shortest=1[v]'
    af='[0:a]aresample=16000,aformat=channel_layouts=mono,'+v_audio_chain(c,out_dur,gain)+'[a]'
    out=f'{ROOT}/items/{i:03d}_{n}.mp4'
    addcmd(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{vf};{af}" -map "[v]" -map "[a]" -t {out_dur:.3f} {ENC_I} {out}',out)
    notes.append(f'  {n:9} {out_dur:5.1f}s  natural idle footage {c["ext"]:.1f}s + held frame {c["freeze"]:.1f}s | {c["text"][:56]}')
    return out,out_dur
src=open('/home/claude/reedit_items.py').read(); blk=src[src.index('def logo_png'):src.index('sections_out=[]')]
# reuse the split builder from the first version (chorus only is used here)
g={'sys':sys,'json':json,'os':os,'shutil':shutil,'subprocess':subprocess,'np':np,'Image':Image,'BOX':BOX,'ROOT':ROOT,'make_seq':lambda n,cid,dur,root=None: make_seq(n,cid,dur,root=ROOT+'/seq')}
exec('from reedit_lib import *',g)
exec(src[src.index('TAILS='):src.index('def addcmd')],g)
g['cmds']=cmds; g['notes']=notes; g['addcmd']=addcmd
exec('def make_clip(spec):\n    n,sp,ep,o=spec; c=clip_def(n,sp,ep,complete=o.get("complete",True)); add_buffer(c,o.get("buf",0.0)); c["opts"]=o; return c',g)
exec(blk,g)
sections_out=[]
for (q,items) in SECTIONS:
    row=[]; notes.append(f'Q{q}:')
    for it in items:
        if it[0]=='reuse':
            p=OLDMAP[it[1]][it[2]]; d=float(subprocess.check_output(['ffprobe','-v','error','-select_streams','v','-show_entries','stream=duration','-of','csv=p=0',p]).decode()); row.append((p,d)); notes.append(f'  (kept) {os.path.basename(p)}')
        elif it[0]=='single': idx+=1; row.append(single(idx,it))
        else: idx+=1; g['idx']=idx; row.append(g['split'](idx,it))
    sections_out.append((q,row))
json.dump(dict(sections=[(q,[(o,d) for o,d in row]) for q,row in sections_out]),open(ROOT+'/manifest.json','w'))
open(ROOT+'/items.sh','w').write('#!/bin/sh\ncd /home/claude\nrm -f '+ROOT+'/items.log\n'+'\n'.join(cmds)+f'\necho ALLDONE >> {ROOT}/items.log\n')
print('\n'.join(notes)); print(len(cmds),'new items to render')
