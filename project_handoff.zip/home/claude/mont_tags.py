import sys,json
sys.argv=['x']
exec(open('/home/claude/anim5.py').read().split("if __name__")[0])
spans=json.load(open('/home/claude/q1_spans.json'))
for o in spans:
    n=o['n']; ln=o['e']-o['s']
    render_seq(n,'L',f'/home/claude/mont/tag_{n}',ln,t0=0.30,te=ln-0.95); print(n,round(ln,2),flush=True)
print('TAGS DONE')
