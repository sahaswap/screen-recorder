import sys,math,json,subprocess
sys.path.insert(0,'/home/claude')
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
FPS=48; BEAT=60/118; TA=4*BEAT; TB=8*BEAT; EXT=0.30; T0=TA+TB             # card A = 1 bar, card B = 2 bars, Deloitte opening starts on bar 4
BG=Image.open('/home/claude/mont/pause_bg.png').convert('RGB')
OSB='/home/claude/fonts_ttf/OpenSans-Bold.ttf'; OSR='/home/claude/fonts_ttf/OpenSans-Regular.ttf'; LORA='/home/claude/fonts_ttf/Lora-Italic-Variable.ttf'
def lora(px):
    f=ImageFont.truetype(LORA,px)
    try: f.set_variation_by_axes([700])
    except Exception: pass
    return f
GREEN=(134,188,37); WHITE=(255,255,255)
def clamp(x): return max(0.0,min(1.0,x))
def eo(p): return 1-(1-p)**3
def eback(p,c=1.5): c3=c+1; return 1+c3*(p-1)**3+c*(p-1)**2
def word_img(txt,font,fill,glow=False):
    d=ImageDraw.Draw(Image.new('RGBA',(10,10))); bb=d.textbbox((0,0),txt,font=font,anchor='ls'); w=bb[2]-bb[0]+40; h=bb[3]-bb[1]+60
    im=Image.new('RGBA',(w,h),(0,0,0,0)); dr=ImageDraw.Draw(im); base=(20-bb[0],h-30)
    sh=Image.new('RGBA',(w,h),(0,0,0,0)); ImageDraw.Draw(sh).text((base[0]+3,base[1]+5),txt,font=font,fill=(0,0,0,170),anchor='ls'); im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(5)))
    if glow:
        g=Image.new('RGBA',(w,h),(0,0,0,0)); ImageDraw.Draw(g).text(base,txt,font=font,fill=fill+(255,),anchor='ls'); g=g.filter(ImageFilter.GaussianBlur(14)); g.putalpha(g.getchannel('A').point(lambda v:int(v*0.55))); im.alpha_composite(g)
    dr.text(base,txt,font=font,fill=fill+(255,),anchor='ls'); return im,(bb[2]-bb[0]),base
class Line:
    def __init__(self,items,cy,gap=30):
        self.items=[]; ims=[word_img(t,f,c,g) for (t,f,c,g,_) in items]; total=sum(i[1] for i in ims)+gap*(len(ims)-1); x=960-total/2
        for (t,f,c,g,t0),(im,w,base) in zip(items,ims): self.items.append(dict(im=im,w=w,base=base,x=x,cy=cy,t0=t0,acc=(c==GREEN))); x+=w+gap
def draw_line(frame,L,t,exit_t=None,exit_len=0.3):
    for it in L.items:
        p=clamp((t-it['t0'])/0.40)
        if p<=0: continue
        a=eo(p); dy=(1-eo(p))*52; sc=1.0
        if it['acc']: sc=0.92+0.08*eback(p,1.6)
        if exit_t is not None and t>exit_t: q=clamp((t-exit_t)/exit_len); a*=(1-q); dy-=34*eo(q)
        if a<=0.01: continue
        im=it['im']
        if sc!=1.0: im=im.resize((int(im.width*sc),int(im.height*sc)),Image.LANCZOS)
        if a<0.999: im=im.copy(); im.putalpha(im.getchannel('A').point(lambda v,a=a:int(v*a)))
        x=int(it['x']-20+(it['im'].width-im.width)/2); y=int(it['cy']-it['base'][1]+30-dy+(it['im'].height-im.height)/2)
        frame.alpha_composite(im,(x,y))
def rule(frame,t,t0,x0,x1,y,exit_t=None):
    p=clamp((t-t0)/0.45)
    if p<=0: return
    a=1.0
    if exit_t is not None and t>exit_t: a=1-clamp((t-exit_t)/0.3)
    if a<=0.01: return
    xe=x0+(x1-x0)*eo(p); g=Image.new('RGBA',frame.size,(0,0,0,0)); d=ImageDraw.Draw(g)
    for k in range(int(xe-x0)):
        al=int(255*a*(1-0.8*(k/max(1,x1-x0))**1.2)); d.rectangle([x0+12+k,y-1,x0+12+k,y+1],fill=(134,188,37,al))
    d.ellipse([x0-6,y-6,x0+6,y+6],fill=(134,188,37,int(255*a))); gl=g.filter(ImageFilter.GaussianBlur(6)); frame.alpha_composite(gl); frame.alpha_composite(g)
fW=ImageFont.truetype(OSB,118); fN=ImageFont.truetype(OSB,150); fA=ImageFont.truetype('/home/claude/fonts_ttf/OpenSans-BoldItalic.ttf',126)
A1=Line([('Welcome',fA,GREEN,True,0.25),('our',fW,WHITE,False,0.43)],cy=470,gap=34); A2=Line([('2026',fN,WHITE,False,0.70),('New',fN,WHITE,False,0.88),('Hires',fN,WHITE,False,1.06)],cy=640,gap=40)
f1=ImageFont.truetype(OSB,100); fS=ImageFont.truetype('/home/claude/fonts_ttf/OpenSans-BoldItalic.ttf',116); fSub=ImageFont.truetype(OSR,54); fTiny=ImageFont.truetype(OSR,38)
B1=Line([("Let's",f1,WHITE,False,0.15),('hear',f1,WHITE,False,0.32),('them',f1,WHITE,False,0.49)],cy=430,gap=30); B2=Line([('share',f1,WHITE,False,0.80),('their',f1,WHITE,False,0.97),('stories',fS,GREEN,True,1.14)],cy=590,gap=34)
B3=Line([('and answer some fun questions.',fSub,(235,240,235),False,1.75)],cy=700); B4=Line([('(no pressure… mostly)',fTiny,(160,175,160),False,2.75)],cy=770)
def frameA(t):
    f=BG.copy().convert('RGBA'); EX=1.78
    rule(f,t,1.30,700,1220,745,EX); draw_line(f,A1,t,EX); draw_line(f,A2,t,EX); return f.convert('RGB')
def frameB(t):
    f=BG.copy().convert('RGBA'); EX=3.82
    rule(f,t,0.0,640,1280,330,EX); [draw_line(f,L,t,EX) for L in (B1,B2,B3,B4)]; return f.convert('RGB')
enc=subprocess.Popen(['ffmpeg','-y','-nostdin','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r','48','-i','-','-c:v','libx264','-preset','fast','-crf','17','-pix_fmt','yuv420p','-g','96','/home/claude/demo_open/cards.mp4'],stdin=subprocess.PIPE)
NA=int(round(TA*FPS)); NB=int(round((TB+EXT)*FPS))
for k in range(NA): enc.stdin.write(np.asarray(frameA(k/FPS)).tobytes())
for k in range(NB): enc.stdin.write(np.asarray(frameB(k/FPS)).tobytes())
enc.stdin.close(); enc.wait(); print('title cards rendered: A %.2fs + B %.2fs (+%.2fs overlap) | Deloitte opening starts at %.3fs (bar 4)'%(TA,TB,EXT,T0))
# a few stills to review
for name,fn,ts in (('A',frameA,(0.4,0.9,1.3,1.7)),('B',frameB,(0.6,1.4,2.2,3.2))):
    ims=[fn(t).resize((480,270)) for t in ts]; s=Image.new('RGB',(480*4,270)); [s.paste(im,(i*480,0)) for i,im in enumerate(ims)]; s.save(f'/home/claude/demo_open/still_{name}.png')
