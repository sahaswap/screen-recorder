import sys,json,subprocess,wave
import numpy as np
from scipy.signal import butter,lfilter
W='/home/claude/final3/w'; SR=32000; BEAT=60/118; TA=4*BEAT; XF=0.30; T0=12*BEAT
P=json.load(open(W+'/plan.json')); TOP=P['opening']['T']; Bt=P['opening']['beats']; Tf=P['rounds'][0]['Tf']; vo_t0=P['rounds'][0]['vo_t0']
FS=T0+TOP; TOTAL=FS+Tf
# ---- video: cards -> (crossfade on the bar line) -> Deloitte flash -> first question card
r=subprocess.run(f'ffmpeg -y -nostdin -v error -i cards.mp4 -i {W}/items/cold_i00.mp4 -i {W}/items/r00_flash.mp4 -filter_complex "[0:v][1:v]xfade=transition=fade:duration={XF}:offset={T0}[x];[x][2:v]concat=n=2:v=1:a=0[v]" -map "[v]" -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p -r 48 base.mp4',shell=True,capture_output=True,text=True); print('video:',r.stderr[-200:] or 'ok')
# ---- audio
def rd(p):
    with wave.open(p) as f: return np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
N=int(round(TOTAL*SR)); vo=np.zeros(N+SR,np.float32); sfx=np.zeros_like(vo); rng=np.random.default_rng(5)
def blip(f0,f1,dur,amp,dec=9):
    n=int(dur*SR); t=np.arange(n)/SR; f=f0+(f1-f0)*t/dur; return (amp*np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*dec)).astype(np.float32)
def put(buf,x,t): s=int(t*SR); buf[s:s+len(x)]+=x[:max(0,len(buf)-s)]
def sweep(dur,amp): 
    n=int(dur*SR); ws=np.convolve(rng.standard_normal(n),np.ones(40)/40,'same'); return (ws*np.hanning(n)*amp).astype(np.float32)
# title-card word ticks (accent words get a soft chime)
A=[0.25,0.43,0.70,0.88,1.06]; B=[0.15,0.32,0.49,0.80,0.97,1.14,1.75,2.75]
put(sfx,sweep(0.30,0.05),1.78); put(sfx,sweep(0.32,0.05),TA+3.80)
# the Deloitte opening, exactly as in the full video (starts on bar 4)
def thump():
    n=int(0.45*SR); t=np.arange(n)/SR; f=46+70*np.exp(-t*32); return (0.38*np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*8)).astype(np.float32)
for k in (1,2,3): put(sfx,thump(),T0+Bt[k])
put(sfx,(np.diff(rng.standard_normal(int(0.55*SR)),prepend=0)*np.hanning(int(0.55*SR))*0.035).astype(np.float32),T0+Bt[3])
n=int((TOP-Bt[4])*SR); ws=np.convolve(rng.standard_normal(n),np.ones(40)/40,'same'); put(sfx,(ws*np.linspace(0,1,n)**1.6*0.11).astype(np.float32),T0+Bt[4])
bw=rd(W+'/brand.wav'); put(vo,bw,T0)
# first question card: pop, spoken question, swoosh
y=np.load(W+'/vo/r00.npy').copy()*0.60; e=int(0.01*SR); y[:e]*=np.linspace(0,1,e); y[-e:]*=np.linspace(1,0,e); put(vo,y,FS+vo_t0);
mus=rd('/home/claude/final3/music.wav'); mus=np.resize(mus,N+SR)*10**(-9/20)*0.5      # background music at 50%
sp=np.abs(vo); k=np.ones(int(0.06*SR))/int(0.06*SR); env=np.convolve(sp,k,'same'); duck=np.clip(env/0.03,0,1)
b,a=butter(1,6/(SR/2)); duck=lfilter(b,a,duck).astype(np.float32); b2,a2=butter(1,2.5/(SR/2)); duck=np.maximum(duck,lfilter(b2,a2,duck).astype(np.float32)); mus*=(1-0.6*duck)
mix=(vo+mus+sfx)[:N]; fo=int(0.7*SR); mix[-fo:]*=np.linspace(1,0,fo); mix=np.clip(mix/max(1.0,np.abs(mix).max()*1.02),-1,1)
with wave.open('audio.wav','wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR); f.writeframes((mix*32767).astype(np.int16).tobytes())
out='/mnt/user-data/outputs/opening_demo/Opening_demo_welcome_to_Deloitte.mp4'
subprocess.run(['ffmpeg','-y','-nostdin','-v','error','-i','base.mp4','-i','audio.wav','-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','160k','-ar','32000','-ac','1','-movflags','+faststart',out],check=True)
print('saved',out,'| planned length %.2fs'%TOTAL)
