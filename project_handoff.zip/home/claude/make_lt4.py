import json
from PIL import Image, ImageDraw, ImageFont
INFO=json.load(open('/home/claude/info.json'))
B='/home/claude/fonts_ttf/OpenSans-Bold.ttf'; R='/home/claude/fonts_ttf/OpenSans-Regular.ttf'
GREEN=(134,188,37); DARK=(40,39,40); WHITE=(255,255,255); GREY=(190,190,190)
S=2  # supersample for smooth edges
def make(n):
    name,role,loc,client=INFO[n]
    H=124*S; badgeW=176*S; pad=30*S
    fn=ImageFont.truetype(B,50*S); fb=ImageFont.truetype(B,26*S); fr=ImageFont.truetype(R,27*S); fbadge=ImageFont.truetype(B,27*S)
    d=ImageDraw.Draw(Image.new('RGBA',(10,10)))
    t_name=name.upper(); l1=('CLIENT: '+client).upper(); l2=f'{role}  ·  {loc}'
    wn=d.textlength(t_name,font=fn); wr=max(d.textlength(l1,font=fb),d.textlength(l2,font=fr))
    W=int(badgeW+pad+wn+pad+2*S+pad+wr+pad)
    im=Image.new('RGBA',(W,H),DARK+(240,)); dr=ImageDraw.Draw(im)
    dr.rectangle([0,0,badgeW,H],fill=GREEN+(255,))
    # badge text (two lines, left aligned, dark on green)
    for i,t in enumerate(['SHARE A','STORY']):
        asc,desc=fbadge.getmetrics(); y=H//2-(asc+desc)+ i*(asc+desc)+ (asc+desc)//2 - 2*S
        dr.text((22*S,y+4*S),t,font=fbadge,fill=DARK+(255,))
    x=badgeW+pad
    asc,desc=fn.getmetrics(); dr.text((x,(H-(asc+desc))//2+3*S),t_name,font=fn,fill=GREEN+(255,))
    x+=wn+pad
    dr.rectangle([x,int(H*0.2),x+2*S-1,int(H*0.8)],fill=GREEN+(150,)); x+=2*S+pad
    a1=fb.getmetrics(); a2=fr.getmetrics(); h1=a1[0]+a1[1]; h2=a2[0]+a2[1]; gap=2*S
    top=(H-(h1+gap+h2))//2
    dr.text((x,top),l1,font=fb,fill=GREEN+(255,))
    dr.text((x,top+h1+gap),l2,font=fr,fill=GREEN+(255,))
    from PIL import ImageFilter
    P=24*S   # padding for the shadow
    canvas=Image.new('RGBA',(W+2*P,H+2*P),(0,0,0,0))
    sh=Image.new('RGBA',canvas.size,(0,0,0,0)); ImageDraw.Draw(sh).rectangle([P,P+5*S,P+W,P+H+5*S],fill=(0,0,0,150))
    sh=sh.filter(ImageFilter.GaussianBlur(8*S)); canvas=Image.alpha_composite(canvas,sh); canvas.alpha_composite(im,(P,P))
    canvas=canvas.resize((canvas.width//S,canvas.height//S),Image.LANCZOS)
    canvas.save(f'/home/claude/lt4/{n}.png'); return canvas.size
if __name__=='__main__':
    for n in INFO: print(n,make(n))
