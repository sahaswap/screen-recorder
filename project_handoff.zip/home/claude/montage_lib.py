import json, re
TR='/home/claude/tr/'
NAMES={'Ananya':'AML_ShareAStory_Ananya_K','Ayush':'AML_ShareAstory_Ayush_Bhalotia','Irin':'AML_ShareAStory_Irin_WinonaS','Malavikka':'AML_ShareAStory_Malavikka_Subash','Mohammed':'AML_ShareAStory_Mohammed_Maqsood','Shobhita':'AML_ShareAStory_Shobhita_Hegde','Monesh':'AML_ShareStory_MONESH_MC','Arijit':'AML_ShareAStory_Arijit_Sarkar','Riddhima':'AML_ShareAStory_Riddhima_Gupta'}
SHIFT={'Riddhima':1.125}   # transcript was made on the older softcut file; plan timeline starts 1.125s later
D=0.25
plans=json.load(open('/home/claude/plans.json'))
def key(w): return re.sub(r"[^a-z0-9']","",w.lower())
def words(n):
    d=json.load(open(TR+NAMES[n]+'.json')); sh=SHIFT.get(n,0)
    return [[w[0],w[1]-sh,w[2]-sh] for w in d['words'] if w[1]-sh>=-0.01]
def find(ws,phr,after=0):
    ks=[key(x) for x in phr.split()]
    for i in range(after,len(ws)-len(ks)+1):
        if [key(w[0]) for w in ws[i:i+len(ks)]]==ks: return i
    raise ValueError(f'not found: {phr}')
def span(n,start_phrase,end_phrase,lead=0.30,tail=0.45):
    ws=words(n); i0=find(ws,start_phrase); i1=find(ws,end_phrase,i0)+len(end_phrase.split())-1
    s=ws[i0][1]-lead; e=ws[i1][2]+tail
    if i1+1<len(ws): e=min(e,ws[i1+1][1]-0.05)
    if i0>0: s=max(s,ws[i0-1][2]+0.05)
    return max(0,round(s,3)),round(e,3)
def seg_map(n):
    segs=plans[n]['segs']; out=[]; S=0.0
    for i,(a,b) in enumerate(segs):
        L=b-a; out.append((S,S+L,a)); S=S+L-D
    return out
def to_source(n,t0,t1):
    """map a clip on the edited timeline back to the original file if it sits inside one uncut stretch"""
    m=seg_map(n)
    for i,(s0,s1,a) in enumerate(m):
        lo=s0+(D if i>0 else 0); hi=s1-(D if i<len(m)-1 else 0)
        if t0>=lo-1e-6 and t1<=hi+1e-6: return ('orig',a+(t0-s0))
    return ('softcut',None)
