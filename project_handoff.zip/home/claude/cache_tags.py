import sys,os,shutil
sys.argv=['x']
exec(open('/home/claude/anim5.py').read().split("if __name__")[0])
for n in INFO:
    tag=Tag3(n,'L'); L=LEN['L']; d=f'/home/claude/mont/cache/{n}'; shutil.rmtree(d,ignore_errors=True); os.makedirs(d)
    def save(im,name): im.resize((im.width//S,im.height//S),Image.LANCZOS).save(f'{d}/{name}.png')
    n_in=int(math.ceil((0.30+L)*FPS))
    for k in range(n_in): save(tag.frame(vtime(k/FPS,0.30,L,None)),f'in_{k:04d}')
    save(tag.frame(TS*0+L*TS if False else L),'hold')   # fully drawn state
    n_ex=int(math.ceil(L*0.8*FPS))
    for j in range(n_ex): save(tag.frame(max(0.0,L-(j/FPS)/0.8)),f'out_{j:04d}')
    print(n,n_in,n_ex,flush=True)
