import json, re, sys, os
TR='/home/claude/tr/'; OUT='/home/claude/caps/'
NAMES={'Ananya':'AML_ShareAStory_Ananya_K','Ayush':'AML_ShareAstory_Ayush_Bhalotia','Irin':'AML_ShareAStory_Irin_WinonaS',
 'Malavikka':'AML_ShareAStory_Malavikka_Subash','Mohammed':'AML_ShareAStory_Mohammed_Maqsood','Shobhita':'AML_ShareAStory_Shobhita_Hegde',
 'Monesh':'AML_ShareStory_MONESH_MC','Arijit':'AML_ShareAStory_Arijit_Sarkar','Riddhima':'AML_ShareAStory_Riddhima_Gupta'}
# (match keys..., replacement)  -- high-confidence fixes only: speaker names, "Deloitte", well-known titles/idioms
REPL={
 'Ananya':[(['melania'],'Ananya'),(['love','you','zindigi'],'Love You Zindagi')],
 'Arijit':[(['arjeet'],'Arijit'),(['delight','journey'],'Deloitte journey'),(['don\'t','stop','me','now','by','queens'],"Don't Stop Me Now by Queen")],
 'Irin':[(['iran'],'Irin'),(['7','drinks','by','ariana'],'7 Rings by Ariana'),(['i','won','it'],'I want it'),(['i','see','it'],'I see it')],
 'Malavikka':[(['mali','vika'],'Malavikka'),(['love','you','zindiki'],'Love You Zindagi')],
 'Mohammed':[(['mohamed','maksood'],'Mohammed Maqsood'),(['shoe','dog'],'Shoe Dog')],
 'Shobhita':[(['shobita'],'Shobhita'),(['dialogue','journey'],'Deloitte journey'),(['shin','chan\'s'],"Shin Chan's")],
 'Monesh':[(['moni','shir'],'Monesh'),(['hook','or','cook'],'hook or crook'),(['kabi','kushi','kabikum'],'Kabhi Khushi Kabhie Gham')],
 'Riddhima':[(['deloyd','journey'],'Deloitte journey'),(['wake','up','sit'],'Wake Up Sid')],
 'Ayush':[(['the','nights','by','abc'],'The Nights by Avicii')],
}
GUESSES={'Riddhima':['Wake Up Sid'],'Ayush':['The Nights by Avicii'],'Irin':['7 Rings by Ariana','I want it']}
KEEP={'deloitte','deloitte\'s','excel','italian','monday','ariana','sanctions','kyc','aml','odc'}
FILL=re.compile(r"^(uh|um|uhm|hmm|er|erm)[,.]?$",re.I)
def key(w): return re.sub(r"[.,?!;:\"]","",w).lower()
def apply_repl(words,rules):
    out=[];i=0
    while i<len(words):
        hit=False
        for ks,rep in rules:
            n=len(ks)
            if i+n<=len(words) and [key(w[0]) for w in words[i:i+n]]==ks:
                last=words[i+n-1][0]; tail=re.search(r"[.,?!;:]+$",last); tail=tail.group(0) if tail else ''
                out.append([rep+tail,words[i][1],words[i+n-1][2],words[i][3],True]); i+=n; hit=True; break
        if not hit: out.append(list(words[i])+[False]); i+=1
    return out
def fix_case(words):
    prev_end=True
    for w in words:
        t=w[0]
        if not prev_end and not w[4]:
            core=re.sub(r"[^A-Za-z']","",t)
            if core[:1].isupper() and core[1:].islower() and not re.match(r"^I($|')",core) and key(t) not in KEEP:
                w[0]=re.sub(r"[A-Za-z]",lambda m:m.group(0).lower(),t,count=1)
        prev_end=bool(re.search(r"[.?!]$",w[0]))
    return words
def build(name,shift=0.0):
    d=json.load(open(TR+NAMES[name]+'.json'))
    words=[[w[0],w[1]-shift,w[2]-shift,w[3]] for w in d['words'] if w[1]>=shift-1e-6 or shift==0]
    words=[w for w in words if not FILL.match(w[0])]
    words=apply_repl(words,REPL.get(name,[]))
    words=fix_case(words)
    return words,d['duration']-shift
CONJ={'and','but','so','because','which','that','when','if','or','to','with','for','as','where','while','even','then','now'}
def ctext(c): return ' '.join(x[0] for x in c)
def cues(words,maxc=66,maxdur=6.5,gap=0.7):
    out=[];cur=[]
    def over(c): return len(ctext(c))>maxc or (c[-1][2]-c[0][1])>maxdur
    def split_at(c):
        best=None
        for k in range(1,len(c)):
            L=c[:k]
            if over(L) or len(ctext(L))<16: continue
            last=L[-1][0]; nxt=re.sub(r"[^a-z']","",c[k][0].lower())
            sc=0 if re.search(r"[.?!]$",last) else 1 if re.search(r"[,;:]$",last) else 2 if nxt in CONJ else 5
            cand=(sc,-k)
            if best is None or cand<best[0]: best=(cand,k)
        return best[1] if best else max(1,len(c)-1)
    for w in words:
        if cur and w[1]-cur[-1][2]>gap: out.append(cur); cur=[]
        cur.append(w)
        while len(cur)>1 and over(cur):
            k=split_at(cur); out.append(cur[:k]); cur=cur[k:]
        t=w[0]; n=len(ctext(cur))
        if (re.search(r"[.?!]$",t) and n>=20) or (re.search(r"[,;:]$",t) and n>=42):
            out.append(cur); cur=[]
    if cur: out.append(cur)
    merged=[]
    for c in out:
        if merged and len(ctext(c))<14 and not over(merged[-1]+c) and c[0][1]-merged[-1][-1][2]<0.5: merged[-1]+=c
        else: merged.append(c)
    return merged
def two_lines(text,maxl=40):
    if len(text)<=maxl: return text
    mid=len(text)/2; best=None
    for m in re.finditer(' ',text):
        p=m.start()
        score=abs(p-mid)-(6 if text[p-1] in ',.;:' else 0)
        if best is None or score<best[0]: best=(score,p)
    p=best[1]; return text[:p]+'\\N'+text[p+1:]
def times(cs,total):
    res=[]
    for i,c in enumerate(cs):
        s=max(0,c[0][1]-0.10); e=c[-1][2]+0.30
        if res: s=max(s,res[-1][1]+0.04)
        nxt=cs[i+1][0][1]-0.10-0.04 if i+1<len(cs) else total
        e=min(e,nxt,total-0.05)
        if e-s<1.0: e=min(max(e,s+1.0),nxt if nxt>s+0.6 else s+1.0,total-0.05)
        res.append([s,e,' '.join(x[0] for x in c)])
    return res
def ts_srt(t): h=int(t//3600);m=int(t%3600//60);s=t%60; return f"{h:02d}:{m:02d}:{int(s):02d},{int(round((s-int(s))*1000)):03d}"
def ts_ass(t): h=int(t//3600);m=int(t%3600//60);s=t%60; return f"{h}:{m:02d}:{s:05.2f}"
def write(name,shift=0.0):
    words,total=build(name,shift); cs=cues(words); tm=times(cs,total)
    with open(OUT+name+'.srt','w') as f:
        for i,(st,en,t) in enumerate(tm,1):
            f.write(f"{i}\n{ts_srt(st)} --> {ts_srt(en)}\n{two_lines(t).replace(chr(92)+'N',chr(10))}\n\n")
    hdr="""[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Default,Inter,50,&H00FFFFFF,&H000000FF,&H8C000000,&H00000000,-1,0,0,0,100,100,0,0,3,14,0,2,160,160,78,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    with open(OUT+name+'.ass','w') as f:
        f.write(hdr)
        for s,e,t in tm: f.write(f"Dialogue: 0,{ts_ass(s)},{ts_ass(e)},Default,,0,0,0,,{two_lines(t)}\n")
    return words,tm
if __name__=='__main__':
    for n in NAMES:
        words,tm=write(n, 1.125 if n=='Riddhima' else 0.0)
        print(n,len(words),'words',len(tm),'cues')
