import subprocess,os,shutil
M='/home/claude/mont/'; OUT='/mnt/user-data/outputs/montage/'
NAMEQ={1:'Introduce_yourself_in_3_words',2:'My_Deloitte_journey',3:'Unexpectedly_good_at',4:'First_week_surprise',5:'One_thing_your_team_should_know',6:'Hidden_talent',7:'Looking_forward_to',8:'One_word_for_your_team',9:'Theme_song',10:'Most_common_phrase',11:'Project_in_one_word'}
jobs=[(f'{M}list_q{q:02d}.txt',f'{OUT}Q{q:02d}_{NAMEQ[q]}.mp4') for q in range(1,12)]+[(f'{M}list_master.txt',f'{OUT}All_questions_montage.mp4')]
def fdur(p): return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',p]).decode())
log=open(M+'rejoin_all.log','w')
for lst,out in jobs:
    files=[l.split("'")[1] for l in open(lst)]; D=[fdur(p) for p in files]
    inp=' '.join(f'-i "{p}"' for p in files)
    fc=''.join(f'[{i}:a]aresample=16000,asetpts=PTS-STARTPTS,apad,atrim=0:{d:.4f},asetpts=PTS-STARTPTS[a{i}];' for i,d in enumerate(D))+''.join(f'[a{i}]' for i in range(len(files)))+f'concat=n={len(files)}:v=0:a=1[a]'
    tmp=M+'rj_'
    cmds=[f'ffmpeg -y -nostdin -v error -f concat -safe 0 -i {lst} -an -c:v copy {tmp}v.mp4',
          f'ffmpeg -y -nostdin -v error {inp} -filter_complex "{fc}" -map "[a]" -c:a aac -b:a 64k -ar 16000 -ac 1 {tmp}a.m4a',
          f'ffmpeg -y -nostdin -v error -i {tmp}v.mp4 -i {tmp}a.m4a -map 0:v -map 1:a -c copy -movflags +faststart {tmp}out.mp4']
    ok=all(subprocess.run(c,shell=True).returncode==0 for c in cmds)
    if ok:
        shutil.copyfile(tmp+'out.mp4',out); log.write(f'OK {os.path.basename(out)}\n')
    else: log.write(f'FAIL {os.path.basename(out)}\n')
    log.flush()
log.write('ALLDONE\n'); log.close()
