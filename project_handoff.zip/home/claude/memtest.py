import subprocess,time,sys
def run(c,label,limit=60):
    t=time.time(); p=subprocess.Popen(['bash','-c',c],stderr=subprocess.DEVNULL,stdout=subprocess.DEVNULL); peak=0
    while p.poll() is None:
        out=subprocess.run("ps -eo rss,comm | awk '$2==\"ffmpeg\"{s+=$1} END{print s+0}'",shell=True,capture_output=True,text=True).stdout.strip()
        peak=max(peak,int(out or 0)); time.sleep(0.4)
        if time.time()-t>limit: p.kill(); break
    print(f'{label:34} rc={p.returncode} peak RSS {peak//1024} MB  {round(time.time()-t)}s',flush=True)
lines=open('/home/claude/run_nl2.sh').read().split('\n')
cmd=[l for l in lines if l.startswith('ffmpeg') and 'Shobhita' in l][0].split(' 2> ')[0].replace('/mnt/user-data/outputs/final_node_line/','/tmp/').replace('-movflags +faststart','-t 12 -movflags +faststart')
run(cmd,'full graph (PNG sequence, 48fps)')
c2=cmd.replace('-framerate 48 -i "/home/claude/anim/Shobhita_L4/%04d.png"','-loop 1 -framerate 48 -i "/home/claude/lt5/Shobhita.png"')
run(c2,'single looped PNG instead')
c3=cmd.replace('[x1]fps=48,delogo','[x1]delogo').replace(' -r 48','')
run(c3,'no fps=48 / no -r 48')
