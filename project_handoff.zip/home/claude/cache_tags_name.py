import sys,os,shutil,json
sys.argv=['x']
exec(open('/home/claude/anim6.py').read().split("if __name__")[0])
dy={}
for n in INFO:
    nm=INFO[n][0]; INFO[n]=(nm,'','','')
    tag=Tag3(n,'L'); L=LEN['L']; d=f'/home/claude/mont/cache/{n}_name'; shutil.rmtree(d,ignore_errors=True); os.makedirs(d)
    def save(im,name): im.resize((im.width//S,im.height//S),Image.LANCZOS).save(f'{d}/{name}.png')
    n_in=int(math.ceil((0.30+L)*FPS))
    for k in range(n_in): save(tag.frame(vtime(k/FPS,0.30,L,None)),f'in_{k:04d}')
    save(tag.frame(L),'hold')
    n_ex=int(math.ceil(L*0.8*FPS))
    for j in range(n_ex): save(tag.frame(max(0.0,L-(j/FPS)/0.8)),f'out_{j:04d}')
    dy[n]=(tag.tops[2]+tag.hs[2]-(tag.tops[0]+tag.hs[0]))/S
    print(n,n_in,n_ex,round(dy[n],1),tag.overlay_y,flush=True)
json.dump(dy,open('/home/claude/mont/name_dy.json','w'))
