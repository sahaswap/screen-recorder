import json
from PIL import Image, ImageDraw, ImageFont, ImageFilter
INFO=json.load(open('/home/claude/info.json'))
B='/home/claude/fonts_ttf/OpenSans-Bold.ttf'; R='/home/claude/fonts_ttf/OpenSans-Regular.ttf'
GREEN=(134,188,37); DARK=(40,39,40)
S=3; P=14   # supersample; shadow padding (px at 1x)
NAME_PX=34; INFO_PX=23
def make(n):
    name,role,loc,client=INFO[n]
    fn=ImageFont.truetype(B,NAME_PX*S); fi=ImageFont.truetype(R,INFO_PX*S)
    lines=[name,f'{role}  ·  {loc}',f'Client: {client}']
    d=ImageDraw.Draw(Image.new('RGBA',(10,10)))
    w=max(d.textlength(lines[0],font=fn),d.textlength(lines[1],font=fi),d.textlength(lines[2],font=fi))
    pad=20*S; bar=5*S; gap1=7*S; gap2=3*S
    a1=fn.getmetrics(); a2=fi.getmetrics(); h1=a1[0]+a1[1]; h2=a2[0]+a2[1]
    W=int(bar+pad+w+pad); H=int(14*S+h1+gap1+h2+gap2+h2+14*S)
    card=Image.new('RGBA',(W,H),DARK+(222,)); dr=ImageDraw.Draw(card)
    dr.rectangle([0,0,bar-1,H],fill=GREEN+(255,))
    x=bar+pad; y=14*S
    dr.text((x,y),lines[0],font=fn,fill=GREEN+(255,)); y+=h1+gap1
    dr.text((x,y),lines[1],font=fi,fill=GREEN+(255,)); y+=h2+gap2
    dr.text((x,y),lines[2],font=fi,fill=GREEN+(255,))
    PP=P*S
    cv=Image.new('RGBA',(W+2*PP,H+2*PP),(0,0,0,0))
    sh=Image.new('RGBA',cv.size,(0,0,0,0)); ImageDraw.Draw(sh).rectangle([PP,PP+3*S,PP+W,PP+H+3*S],fill=(0,0,0,130))
    sh=sh.filter(ImageFilter.GaussianBlur(6*S)); cv=Image.alpha_composite(cv,sh); cv.alpha_composite(card,(PP,PP))
    cv=cv.resize((cv.width//S,cv.height//S),Image.LANCZOS); cv.save(f'/home/claude/lt5/{n}.png'); return cv.size
if __name__=='__main__':
    for n in INFO: print(n,make(n))
