import re,subprocess,json,glob,numpy as np
exec(open('/home/claude/verify_sync2.py').read().split("out=[]")[0].replace("assert len(items)==len(clips)==60","assert len(items)==len(clips)"))
SP=json.load(open('/home/claude/curated_spans.json'))
rows=[];endrows=[]
for i,((ss,dur,src,cid),clip,o) in enumerate(zip(items,clips,SP),1):
    # ---- speech still running at the cut?  RMS (dB) in the last 0.30..0.12 s before the fades
    a=aud(clip,0,dur); sr=16000
    def rms(t0,t1): x=a[int(t0*sr):int(t1*sr)]; return 20*np.log10(np.sqrt((x**2).mean())+1e-6) if len(x) else -99
    peak=np.percentile([rms(t,t+0.1) for t in np.arange(0.3,dur-0.3,0.1)],90)
    endrows.append((i,cid,round(rms(dur-0.30,dur-0.12),1),round(peak,1)))
    # ---- drift: offsets measured at start / middle / end of the clip
    if dur<2.8: continue
    W=1.5; seg=0.9; res=[]
    for ts in (0.45,(dur-seg)/2,dur-seg-0.5):
        ca=aud(clip,ts,seg); sa=aud(src,ss+ts-W,seg+2*W)
        if len(sa)<len(ca)+10 or np.abs(ca).max()<1e-3: res.append((None,None)); continue
        pk=int(np.argmax(xcorr(ca,sa))); a_off=(max(0,ss+ts-W)+pk/16000)-(ss+ts)
        cv=vid(clip,ts,seg); sv=vid(src,ss+ts-W,seg+2*W); n=len(cv)
        if n<4 or len(sv)<n+2: res.append((a_off,None)); continue
        best=min(((np.mean((sv[s0:s0+n]-cv)**2),s0) for s0 in range(0,len(sv)-n+1)))
        res.append((a_off,(max(0,ss+ts-W)+best[1]/16)-(ss+ts)))
    rows.append((i,cid,res))
json.dump({'drift':rows,'end':endrows},open('/home/claude/verify_drift.json','w')); print('DONE')
