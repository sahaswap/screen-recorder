import sys,re,json
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3')
import spans_all as S
from reedit_lib import orig_time
INFO=json.load(open('/home/claude/info.json'))
ORDER=['Malavikka','Monesh','Riddhima','Mohammed','Ananya','Irin','Arijit','Ayush','Shobhita']
QTXT={1:'Introduce yourself in 3 words',2:'Complete the sentence: "My Deloitte journey is going to be / has been…"',3:"What's something you're unexpectedly (or weirdly) good at?",4:'What surprised you about your first week?',
      5:'What is one thing the new team should know about you?',6:"What's your hidden talent?",7:'What are you looking forward to the most?',8:'Describe your new team in one word',
      9:'If your life had a theme song (book / movie title), what would it be?',10:'What is the most common phrase you have heard after joining Deloitte?',11:'Describe your project in one word'}
KEY={1:(r"three words",r"three words"),2:(r"complete the sentence|deloitte journey",r"going to be|has been|to be"),
     3:(r"unexpectedly|weirdly|something (?:that )?i(?:'m| am)? (?:surprisingly )?good",r"good at"),4:(r"surpris\w* (?:you|me) about|first week",r"first week"),
     5:(r"one thing",r"about you|about me|learn about me"),6:(r"hidden talent",r"hidden talent"),7:(r"looking forward",r"the most"),
     8:(r"new team|one word",r"in one word|new team"),9:(r"theme song|theme|book title|movie title",r"would it be|movie title|book title|theme song"),
     10:(r"common phrase|most common",r"joining deloitte|after joining|joining"),11:(r"project in one word|describe (?:your|my) project|project in",r"in one word|one word")}
STOP=set("next then now so and also the question first second third fourth fifth sixth seventh eighth ninth tenth eleventh last is comes come coming to i it was like what what's that moving move onto on one".split())
def prep(ws):
    toks=[S.norm(w[0]) for w in ws]; pos=[]; s=''
    for t in toks: pos.append(len(s)+(1 if s else 0)); s=(s+' '+t).strip() if s else t
    return s,pos
def tok_at(pos,charidx): return max(k for k,x in enumerate(pos) if x<=charidx)
def find(ws,s,pos,regex,after_tok,maxtok=None):
    start=pos[after_tok] if after_tok<len(pos) else len(s)
    m=re.compile(regex).search(s,start)
    if not m: return None
    a=tok_at(pos,m.start()); b=tok_at(pos,max(m.start(),m.end()-1))
    if maxtok is not None and a-after_tok>maxtok: return None
    return a,b
def segment(n):
    ws=S.words(n); s,pos=prep(ws); marks={}; cur=0
    for q in range(1,12):
        kr,er=KEY[q]; hit=find(ws,s,pos,kr,cur)
        if not hit: continue
        a,b=hit
        # include the lead-in words ("so the next question is ...") but not a previous sentence
        st=a
        if q==1:
            while st>cur and a-st<6 and not re.search(r'[.?!]$',ws[st-1][0]): st-=1
        else:
            while st>cur and a-st<9 and not re.search(r'[.?!]$',ws[st-1][0]) and (S.norm(ws[st-1][0]) in STOP): st-=1
        eh=find(ws,s,pos,er,b if q not in (6,) else a)   # end of the question as read
        if q==6: end=b
        else: end=eh[1] if (eh and eh[0]-b<=14) else b
        marks[q]=(st,a,end); cur=end+1
    return ws,marks
def t(n,i,which): return orig_time(n,S.words(n)[i][which])
def mmss(x): return f'{int(x//60)}:{x%60:04.1f}'
rows=[]; trans={}
for n in ORDER:
    ws,marks=segment(n); qs=sorted(marks); trans[n]=(ws,marks)
    bounds=[(q,marks[q][0]) for q in qs]
    for k,q in enumerate(qs):
        st,a,end=marks[q]; nxt=bounds[k+1][1] if k+1<len(bounds) else len(ws)
        qtext=' '.join(w[0] for w in ws[st:end+1]); atext=' '.join(w[0] for w in ws[end+1:nxt]).strip()
        s0=orig_time(n,ws[st][1]); e0=orig_time(n,ws[nxt-1][2])
        rows.append(dict(n=n,q=q,s=s0,e=e0,qtext=qtext,ans=atext,full=' '.join(w[0] for w in ws[st:nxt])))
    miss=[q for q in range(1,12) if q not in marks]; print(f'{n:10} {len(ws):3d} words | questions found {len(marks)}/11' + (f' | MISSING {miss}' if miss else ''))
json.dump(dict(rows=rows),open('/home/claude/xl/rows.json','w'))
