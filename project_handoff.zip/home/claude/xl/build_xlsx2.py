import sys,re,json,os
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3'); sys.path.insert(0,'/home/claude/xl')
exec(open('/home/claude/xl/build_xlsx.py').read().split("rows=[]; trans={}")[0])      # reuse helpers: segment(), KEY, QTXT, find(), prep()
from spans_all import locate
ORDER=['Malavikka','Monesh','Riddhima','Mohammed','Ananya','Irin','Arijit','Ayush','Shobhita']
def sent_start(ws,i):
    st=i
    while st>0 and i-st<14 and not re.search(r'[.?!]$',ws[st-1][0]) and (ws[st][1]-ws[st-1][2])<0.45: st-=1      # stop at punctuation or at a pause
    return st
def build_person(n):
    ws=S.words(n); s,pos=prep(ws); _,marks=segment(n); anchors={}
    for q in range(2,12):
        if n in S.SPEC.get(q,{}):
            try: a,_=locate(ws,S.SPEC[q][n][0]); anchors[q]=sent_start(ws,a)
            except Exception: pass
    # Q1: spoken question if read, else the sentence with 'three words' / 'describe myself'
    if 1 in marks: anchors[1]=marks[1][2]+1
    else:
        m=re.search(r"three words|describe myself",s)
        if m: anchors[1]=sent_start(ws,tok_at(pos,m.start()))
    segs=[]
    for q in sorted(anchors):
        a=anchors[q]; st=a; qs=qe=None
        if q in marks and q!=1:
            mst,_,mend=marks[q]
            if mst<=a and mend>=mst: st=mst; qs,qe=mst,min(mend,a-1) if mend>=a else mend
        if q==1 and 1 in marks: st,_,qe=marks[1]; qs=st
        segs.append(dict(q=q,st=st,a=a,qs=qs,qe=qe))
    segs.sort(key=lambda d:d['st'])
    # keep strictly increasing starts
    clean=[]; 
    for d in segs:
        if clean and d['st']<=clean[-1]['st']: d['st']=d['a']
        clean.append(d)
    return ws,clean
def mmss(x): return f'{int(x//60)}:{x%60:04.1f}'
out={}; allrows=[]
for n in ORDER:
    ws,segs=build_person(n); first=segs[0]['st'] if segs else len(ws)
    for k,d in enumerate(segs):
        nxt=segs[k+1]['st'] if k+1<len(segs) else len(ws)
        if k+1==len(segs):                      # last answer: stop at the end of the sentence that contains the curated end phrase
            qd=d['q']; endtok=nxt
            try:
                _,b=locate(ws,S.SPEC[qd][n][1],d['a']) if qd in S.SPEC and n in S.SPEC[qd] else (0,nxt-1)
                j=b
                while j+1<len(ws) and not re.search(r'[.?!]$',ws[j][0]): j+=1
                endtok=min(nxt,j+1)
            except Exception: pass
            nxt=endtok
        qt=' '.join(w[0] for w in ws[d['qs']:d['qe']+1]) if d['qs'] is not None and d['qe'] is not None else ''
        astart=(d['qe']+1) if (d['qe'] is not None and d['qe']<d['a']) else d['a']
        at=' '.join(w[0] for w in ws[astart:nxt]).strip()
        allrows.append(dict(n=n,q=d['q'],qread=qt,ans=at,s=orig_time(n,ws[d['st']][1]),e=orig_time(n,ws[nxt-1][2]),i0=d['st'],i1=nxt-1))
    out[n]=dict(ws=ws,segs=segs,intro=(0,first-1))
# ---- which answers are in the current video (v14): read the clip definitions from the build script
src=open('/home/claude/final3/build_v3.py').read(); a=src.index('def S(n,sp,ep'); b=src.index('log=open(')
ns={'CHORUS_W':'','CHORUS_Z':''}; exec(src[a:b],ns)
RQ=[1,3,6,5,10,11,4,8,9]; used={}
def mark(n,phrase,label):
    try:
        ws=S.words(n); i,_=locate(ws,phrase)
        for r in allrows:
            if r['n']==n and r['i0']<=i<=r['i1']: used.setdefault((n,r['q']),[]).append(label); return
    except Exception: pass
for ri,(txt,spoken,items) in enumerate(ns['ROUNDS']):
    for it in items:
        if it['kind']=='single': mark(it['n'],it['sp'],'solo clip')
        elif it['kind']=='merge':
            for m in it['members']:
                if m['anchor']: mark(m['n'],m['anchor'],f"split-screen ('{it['label']}')")
for r in allrows: r['inv']='; '.join(dict.fromkeys(used.get((r['n'],r['q']),[]))) or ''
json.dump(dict(rows=allrows),open('/home/claude/xl/rows2.json','w'))
have={(r['n'],r['q']) for r in allrows}
for n in ORDER:
    miss=[q for q in range(1,12) if (n,q) not in have]; print(f"{n:10} answers placed {sum(1 for r in allrows if r['n']==n):2d}/11" + (f' | no answer found for Q{miss}' if miss else ''))
print('answers marked as used in the current video:',sum(1 for r in allrows if r['inv']))
