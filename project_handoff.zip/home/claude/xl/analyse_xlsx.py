import sys,re,json,shutil
sys.path.insert(0,'/home/claude')
from openpyxl import load_workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
SRC='/mnt/user-data/outputs/transcripts/AML_ShareAStory_transcripts.xlsx'; DST='/mnt/user-data/outputs/transcripts/AML_ShareAStory_transcripts_analysed.xlsx'
shutil.copy(SRC,DST); wb=load_workbook(DST)
R=json.load(open('/home/claude/xl/rows2.json'))['rows']
P,M,SK,CK,MG='Pick','Maybe','Skip','Check','Merge'
SUG={
(1,'Malavikka'):(P,"Distinct, calm contrast to the 'curious' wave."),(1,'Monesh'):(M,'Good line but long (8 s) and from late in his recording.'),(1,'Riddhima'):(MG,"Part of the 'curious' merge."),(1,'Mohammed'):(MG,"Part of the 'curious' merge."),
(1,'Ananya'):(CK,"Transcript garbled ('sweet… quite until Monday and curious') – listen to the video; probably 'sweet, quiet and curious'."),(1,'Irin'):(P,"Crisp true 3-word answer – not yet in the video."),(1,'Arijit'):(MG,"Part of the 'curious' merge (segment also runs into the next question)."),
(1,'Ayush'):(MG,"Part of the 'curious' merge."),(1,'Shobhita'):(MG,"Part of the 'curious' merge."),
(2,'Malavikka'):(M,"Generic ('exciting, challenging, growth') – use only in a 'growth' merge."),(2,'Monesh'):(SK,'Long (13 s); stronger lines elsewhere.'),(2,'Riddhima'):(M,"'Growth' merge candidate."),(2,'Mohammed'):(M,"'Growth' merge candidate; 16 s."),
(2,'Ananya'):(P,"Vivid: 'roller coaster… good friendships and memories'. Merge with Ayush."),(2,'Irin'):(P,"Punchy: 'challenging me to be excellent every day'."),(2,'Arijit'):(M,"'Awesome so far' – short but flat."),(2,'Ayush'):(P,"3 s, 'A roller coaster of learning, surprises and opportunities' – merge with Ananya."),(2,'Shobhita'):(M,"'Exciting chapter' – generic."),
(3,'Malavikka'):(M,"'Tiniest details' – merge with Mohammed's 'smallest details'."),(3,'Riddhima'):(P,"Relatable and fun: guesses the song from its first notes. NOT in the video yet."),(3,'Mohammed'):(M,"'Smallest details' – merge with Malavikka."),(3,'Ananya'):(P,"'I can read minds' – in video."),
(3,'Irin'):(P,"'Making Excel do magic' – in video."),(3,'Arijit'):(P,"Cooks Italian – in video."),(3,'Ayush'):(SK,'Generic.'),(3,'Shobhita'):(SK,'Generic (networking).'),
(4,'Malavikka'):(M,'Sincere (support and handholding) but not distinctive.'),(4,'Monesh'):(SK,'16 s, generic.'),(4,'Mohammed'):(M,"'Welcoming' – said again in Q8."),(4,'Ananya'):(P,"Passwords vs. memory – the funniest in this question; in video."),
(4,'Irin'):(P,"'Strangers became teammates' – short and quotable; NOT in the video."),(4,'Arijit'):(SK,"Unclear ('there was no target')."),(4,'Ayush'):(P,'People willing to help you settle in – in video.'),(4,'Shobhita'):(M,'Welcoming – generic.'),
(5,'Malavikka'):(M,"Sincere ('take time to open up, love helping people')."),(5,'Monesh'):(P,"'Hook or crook' – in video (the funny ending)."),(5,'Riddhima'):(P,'Snack recommendations – in video.'),(5,'Mohammed'):(SK,'Generic, 17 s.'),
(5,'Ananya'):(M,"'May look quiet at first' (transcript says 'quite first' – check)."),(5,'Irin'):(P,"'If I say I will do it, I'll do it' – in video."),(5,'Arijit'):(P,'Terrified of spiders – in video.'),(5,'Ayush'):(SK,"'Always curious / learning' – said by several people."),(5,'Shobhita'):(SK,'Long and generic.'),
(6,'Malavikka'):(P,'Dancing – in the dancing merge.'),(6,'Monesh'):(M,"'Connect dots… minimal preparation' – serious tone, long."),(6,'Riddhima'):(P,'Packs her whole life into suitcases – in video.'),(6,'Mohammed'):(SK,'Cut off in the transcript and generic.'),
(6,'Ananya'):(P,"'Professional overthinker' – in video."),(6,'Irin'):(P,'Dances to any song – in the dancing merge.'),(6,'Arijit'):(P,"'I can speak five languages' – good fun fact, NOT in the video."),(6,'Ayush'):(SK,'Generic.'),(6,'Shobhita'):(SK,'Generic.'),
(7,'Malavikka'):(M,"'Memories' theme (round currently dropped)."),(7,'Monesh'):(SK,'Generic.'),(7,'Riddhima'):(M,'Generic.'),(7,'Mohammed'):(M,"'Memories' theme."),(7,'Ananya'):(M,"'Memories' theme."),
(7,'Irin'):(P,"'Growing from a fresher to someone people can depend on' – best of a weak question."),(7,'Arijit'):(SK,"Confusing ('disconnect')."),(7,'Ayush'):(P,'Short; mentions memories.'),
(8,'Malavikka'):(M,"'Supportive' – merge candidate."),(8,'Monesh'):(P,"'Financial superheroes… money laundering and terrorist financing' – the AML line; in video."),(8,'Riddhima'):(M,"'Fostering' – fine but long."),(8,'Mohammed'):(P,"'Welcoming' – in the welcoming merge."),
(8,'Ananya'):(M,"'Supportive and fun' – supportive merge."),(8,'Irin'):(P,"'Unstoppable' – short and punchy; NOT in the video."),(8,'Arijit'):(P,"'Synergistic' pun – in video."),(8,'Ayush'):(P,"'Welcoming' – in the welcoming merge."),(8,'Shobhita'):(M,"'Supportive' – merge candidate."),
(9,'Malavikka'):(P,"'Love You Zindagi' – merge, in video."),(9,'Monesh'):(P,'Kabhi Khushi Kabhie Gham / ups and downs – in video.'),(9,'Riddhima'):(P,'Wake Up Sid – in video.'),(9,'Mohammed'):(SK,'Shoe Dog is a book, 19 s (removed earlier).'),
(9,'Ananya'):(P,"'Love You Zindagi' – merge, in video."),(9,'Irin'):(P,'7 Rings – in video.'),(9,'Arijit'):(P,"Don't Stop Me Now – in video (finale)."),(9,'Ayush'):(P,"The Nights – 'trust me, it gets better'; in video."),(9,'Shobhita'):(P,'Shin Chan – the most fun answer here; in video.'),
(10,'Malavikka'):(P,"'Let's connect' – in the connect merge."),(10,'Riddhima'):(M,"'Delighted to meet you' – merge with Arijit's 'delighted'."),(10,'Mohammed'):(P,"'Networking ×3 … my first official Deloitte skill' – in video."),(10,'Ananya'):(P,"'Quick connect' – in the connect merge."),
(10,'Irin'):(P,"'Did you fill your timesheet?' – in video."),(10,'Arijit'):(M,"'Failed and delighted' – interesting but rambling (24 s); check wording."),(10,'Shobhita'):(SK,"'Welcome to Deloitte' – you asked to remove."),
(11,'Malavikka'):(P,'Dynamic – in the dynamic merge.'),(11,'Monesh'):(P,"'Follow the money, analyze and report' – the AML motto; in video."),(11,'Riddhima'):(M,"'Interesting and unique' – generic."),(11,'Mohammed'):(P,'Dynamic – in the dynamic merge.'),
(11,'Ananya'):(P,"'Detective work' – detective merge (AML-flavoured)."),(11,'Irin'):(P,"'Detectives' – detective merge."),(11,'Arijit'):(P,"'Awesome' – in video."),(11,'Ayush'):(P,"'Intriguing' – 1 s, in video."),(11,'Shobhita'):(SK,"'Disconnect / ODC' – you asked to remove.")}
FILL={P:'DCEFC0',M:'FFF2CC',SK:'EDEDED',CK:'FFD9D9',MG:'DCEFC0'}
WRAP=Alignment(wrap_text=True,vertical='top'); thin=Side(style='thin',color='D0D0D0'); BORD=Border(left=thin,right=thin,top=thin,bottom=thin)
HDR=PatternFill('solid',fgColor='1F2A1F'); HF=Font(bold=True,color='FFFFFF')
def wc(t): return len(re.findall(r"[A-Za-z']+",t))
# ---------- All answers: add analysis columns
wa=wb['All answers']; short={ 'Malavikka Subash':'Malavikka','Monesh M C':'Monesh','Riddhima Gupta':'Riddhima','Mohammed Maqsood':'Mohammed','Ananya K':'Ananya','Irin Winona S':'Irin','Arijit Sarkar':'Arijit','Ayush Bhalotia':'Ayush','Shobhita P Hegde':'Shobhita'}
for c,(h,w) in enumerate([('Words',8),('Analysis: suggestion',14),('Analysis: why',58)],14):
    cell=wa.cell(row=1,column=c,value=h); cell.fill=HDR; cell.font=HF; cell.alignment=Alignment(wrap_text=True,vertical='center'); wa.column_dimensions[get_column_letter(c)].width=w
for r in range(2,wa.max_row+1):
    q=wa.cell(row=r,column=1).value; n=short[wa.cell(row=r,column=3).value]; ans=str(wa.cell(row=r,column=8).value or '')
    if (q,n) in SUG:
        s,why=SUG[(q,n)]; wa.cell(row=r,column=14,value=wc(ans)); wa.cell(row=r,column=15,value=s); wa.cell(row=r,column=16,value=why); wa.cell(row=r,column=15).fill=PatternFill('solid',fgColor=FILL[s])
    for c in (14,15,16): wa.cell(row=r,column=c).alignment=WRAP; wa.cell(row=r,column=c).border=BORD
wa.auto_filter.ref=f'A1:P{wa.max_row}'
def sheet(name,cols,widths,rows,after=None):
    ws=wb.create_sheet(name,(wb.sheetnames.index(after)+1) if after else None); ws.append(cols)
    for c,w in enumerate(widths,1):
        cell=ws.cell(row=1,column=c); cell.fill=HDR; cell.font=HF; cell.alignment=Alignment(wrap_text=True,vertical='center'); ws.column_dimensions[get_column_letter(c)].width=w
    ws.freeze_panes='A2'
    for r_ in rows:
        ws.append(r_)
        for c in range(1,len(cols)+1): ws.cell(row=ws.max_row,column=c).alignment=WRAP; ws.cell(row=ws.max_row,column=c).border=BORD
        h=max(1,max(-(-len(str(v))//max(1,int(w*1.1))) for v,w in zip(r_,widths))); ws.row_dimensions[ws.max_row].height=min(300,max(18,15*h))
    return ws
# ---------- Suggested picks (ranked per question)
QT={1:'Introduce yourself in 3 words',2:'Deloitte journey sentence',3:"Unexpectedly / weirdly good at",4:'Surprised about first week',5:'One thing the team should know',6:'Hidden talent',7:'Looking forward to',8:'One word for the new team',9:'Theme song',10:'Most common phrase heard',11:'Project in one word'}
INV={(r['n'],r['q']):r['inv'] for r in R}; ANS={(r['n'],r['q']):r['ans'] for r in R}
order={P:0,MG:1,CK:2,M:3,SK:4}; rows=[]
for q in range(1,12):
    items=sorted([(order[SUG[(q,n)][0]],n) for (qq,n) in SUG if qq==q and SUG[(qq,n)][0] in (P,MG,CK)],key=lambda x:(x[0],['Malavikka','Monesh','Riddhima','Mohammed','Ananya','Irin','Arijit','Ayush','Shobhita'].index(x[1])))
    for k,(_,n) in enumerate(items,1):
        s,why=SUG[(q,n)]; rows.append([q,QT[q],s,n,(ANS[(n,q)][:170]+('…' if len(ANS[(n,q)])>170 else '')),why,'yes – '+INV[(n,q)] if INV[(n,q)] else 'NOT yet'])
sp=sheet('Suggested picks',['Q#','Question','Suggestion','Person','Answer (excerpt)','Why','In current video (v14)?'],[5,30,11,12,70,60,24],rows,after='By question')
for r in range(2,sp.max_row+1):
    s=sp.cell(row=r,column=3).value; sp.cell(row=r,column=3).fill=PatternFill('solid',fgColor=FILL[s])
    if sp.cell(row=r,column=7).value=='NOT yet': sp.cell(row=r,column=7).font=Font(bold=True,color='B45F06')
# ---------- Merge ideas
merges=[('curious','Q1','Riddhima, Mohammed, Shobhita, Ayush, Arijit (+ Ananya, garbled)','In v14','Strongest merge: 6 of 9 people say it.'),
('dancing','Q6','Malavikka, Irin, Ananya','In v14','Fun and visual.'),('connect','Q10','Malavikka, Ananya (+ Mohammed "networking")','In v14','Now plays at normal pace with the shared word.'),
('dynamic','Q11','Malavikka, Mohammed','In v14',''),('detective(s)','Q11','Irin, Ananya','In v14','Natural AML flavour.'),('welcoming','Q8','Mohammed, Ayush','In v14','Liked in the earlier review.'),('Love You Zindagi','Q9','Malavikka, Ananya','In v14','Liked in the earlier review.'),
('roller coaster','Q2','Ananya, Ayush','NEW idea','Strong, vivid word; Q2 is not in the video at all.'),('details ("tiniest / smallest")','Q3','Malavikka, Mohammed','NEW idea','Near-identical wording.'),
('delighted','Q10','Riddhima, Arijit','NEW idea','Check Arijit\'s wording against the video first.'),('supportive','Q8','Malavikka, Ananya, Shobhita','NEW idea','Three people; pairs with the welcoming merge.'),
('growth','Q2','Malavikka, Riddhima, Mohammed, Shobhita','NEW idea','Generic – only if you bring Q2 back.'),('memories','Q7','Malavikka, Mohammed, Ananya, Ayush','NEW idea','Only if Q7 comes back.'),
('welcoming (first week)','Q4','Mohammed, Shobhita (+ Monesh "friendly welcome")','NEW idea','Generic but quick.'),('always learning','Q5','Riddhima, Mohammed, Ayush, Shobhita','NEW idea','Generic.')]
sheet('Merge ideas',['Shared word / theme','Q#','Who','Status','Notes'],[26,6,52,12,50],[list(m) for m in merges],after='Suggested picks')
# ---------- Insights
ORDER=['Malavikka','Monesh','Riddhima','Mohammed','Ananya','Irin','Arijit','Ayush','Shobhita']
air={'Malavikka':7.9,'Monesh':25.5,'Riddhima':21.2,'Mohammed':9.7,'Ananya':12.5,'Irin':14.0,'Arijit':20.8,'Ayush':10.8,'Shobhita':7.4}; pace={'Malavikka':1.57,'Monesh':2.03,'Riddhima':3.12,'Mohammed':1.95,'Ananya':2.60,'Irin':1.96,'Arijit':1.40,'Ayush':1.72,'Shobhita':2.44}
wi=wb.create_sheet('Insights',1); wi.column_dimensions['A'].width=30
for c in 'BCDEF': wi.column_dimensions[c].width=22
wi.column_dimensions['G'].width=70
lines=[("What the file says (editorial analysis – my judgement, plus counts from the transcripts)",'h'),
("1. Coverage: 94 of 99 possible answers exist. Not answered: Monesh Q3 and Q10, Riddhima Q4, Ayush Q10, Shobhita Q7.",''),
("2. Strongest questions (funny, personal, distinct): Q3 unexpectedly good at, Q5 one thing the team should know, Q6 hidden talent, Q9 theme song, Q10 common phrase, Q11 project in one word.",''),
("3. Weakest questions (generic, repetitive): Q2 Deloitte journey ('growth', 'exciting'), Q7 looking forward ('learning', 'memories'), Q4 first week (mostly 'welcoming' / 'support'). That is why the current cut leaves Q2 and Q7 out.",''),
("4. Repetition is the story: 'curious' appears in 6 of 9 Q1 answers; learning/growth in 17 answers; welcoming/support in 13; 'connect/networking' in 9. The merges turn that repetition into the hook.",''),
("5. AML flavour is almost all Monesh (10 terms: AML, KYC, sanctions, transaction monitoring, fraud, money laundering, terrorist financing, follow the money). Ananya and Irin add 'detective / investigate'. The detective merge plus Monesh's two lines are the AML moments.",''),
("6. 'Deloitte' is said 25 times in total (Mohammed 5, Irin 4, Shobhita 4, Arijit 3, five others 1–2). Mohammed's 'first official Deloitte skill' is the best usable line.",''),
("7. Airtime in the current cut is uneven: Monesh 25.5 s, Riddhima 21.2 s, Arijit 20.8 s versus Shobhita 7.4 s, Malavikka 7.9 s, Mohammed 9.7 s, Ayush 10.8 s. Merges count for each person in them.",''),
("8. Best answers not yet in the cut: Riddhima Q3 (guesses songs from the first notes), Irin Q4 ('strangers became teammates'), Irin Q8 ('unstoppable'), Arijit Q6 ('five languages'), Irin Q1 ('Driven, committed, growing'), and new merges 'roller coaster' (Ananya+Ayush) and 'details' (Malavikka+Mohammed).",''),
("9. Delivery pace: Riddhima is by far the fastest talker (about 3.1 words/s, Arijit slowest at 1.4). Her clips need the most room if the cut is slowed down.",''),
("10. Data caveats: speech recognition is imperfect – Ananya's Q1 is garbled; song/book titles are best guesses; Arijit's answers run into the next question in 9 of 11 segments (word counts for him are inflated); Mohammed's Q6 is cut off.",''),
('','' ),("Per-person summary",'h')]
for text,k in lines:
    wi.append([text]); 
    if k=='h': wi.cell(row=wi.max_row,column=1).font=Font(bold=True,size=12)
    elif text: wi.merge_cells(start_row=wi.max_row,start_column=1,end_row=wi.max_row,end_column=7); wi.cell(row=wi.max_row,column=1).alignment=WRAP; wi.row_dimensions[wi.max_row].height=max(18,15*(-(-len(text)//150)))
wi.append(['Person','Answers found','Used in v14','On-screen answer time in v14 (s)','Speaking pace (words/s)','Suggested picks (✔) not yet in video','Observation'])
for c in range(1,8): cell=wi.cell(row=wi.max_row,column=c); cell.fill=HDR; cell.font=HF; cell.alignment=Alignment(wrap_text=True,vertical='center')
wi.row_dimensions[wi.max_row].height=44
obs={'Malavikka':'Low airtime. Strong short lines (Zindagi, dancing, let\'s connect). Candidates: Q3 advice/details, Q5 "love helping people".','Monesh':'Highest airtime and the AML voice; his answers are long (avg 26 words) – trim to the punchlines.',
'Riddhima':'Fastest speaker; very quotable (snacks, packing, song-title guessing). Q3 song-title answer is unused.','Mohammed':'Low airtime; best line is "first official Deloitte skill". Joins four merges.','Ananya':'Most versatile: appears in 5 merges plus 3 solo lines.',
'Irin':'Short, clean, quotable answers – several unused strong ones (Q1, Q4, Q8).','Arijit':'Slow, deliberate delivery; good pun (synergistic) and fun facts (spiders, cooking, five languages).','Ayush':'Very short answers (avg 7 words) – good for fast cuts and merges.','Shobhita':'Lowest airtime (7 s). Her best fun line is Shin Chan; the rest of her answers are long and generic.'}
for n in ORDER:
    rr=[r for r in R if r['n']==n]; used=sum(1 for r in rr if r['inv']); notyet=[f"Q{q}" for (q,nn),(s,_) in SUG.items() if nn==n and s==P and not INV.get((n,q))]
    wi.append([n,len(rr),used,air[n],pace[n],', '.join(notyet) or '–',obs[n]])
    for c in range(1,8): wi.cell(row=wi.max_row,column=c).alignment=WRAP; wi.cell(row=wi.max_row,column=c).border=BORD
    wi.row_dimensions[wi.max_row].height=48
wb.save(DST); print('saved',DST,'| sheets:',wb.sheetnames)
sg=[v for v in SUG.values()]; print('suggestions: Pick',sum(1 for s,_ in sg if s==P),'Merge',sum(1 for s,_ in sg if s==MG),'Maybe',sum(1 for s,_ in sg if s==M),'Skip',sum(1 for s,_ in sg if s==SK),'Check',sum(1 for s,_ in sg if s==CK),'| total',len(sg))
