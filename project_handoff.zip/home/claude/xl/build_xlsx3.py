import sys,re,json
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/xl')
import spans_all as S
from reedit_lib import orig_time
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
exec(open('/home/claude/xl/build_xlsx.py').read().split("def segment(n):")[0].split("INFO=")[0])  # QTXT only
QTXT={1:'Introduce yourself in 3 words',2:'Complete the sentence: "My Deloitte journey is going to be / has been…"',3:"What's something you're unexpectedly (or weirdly) good at?",4:'What surprised you about your first week?',
      5:'What is one thing the new team should know about you?',6:"What's your hidden talent?",7:'What are you looking forward to the most?',8:'Describe your new team in one word',
      9:'If your life had a theme song (book / movie title), what would it be?',10:'What is the most common phrase you have heard after joining Deloitte?',11:'Describe your project in one word'}
INFO=json.load(open('/home/claude/info.json')); R=json.load(open('/home/claude/xl/rows2.json'))['rows']
ORDER=['Malavikka','Monesh','Riddhima','Mohammed','Ananya','Irin','Arijit','Ayush','Shobhita']
def inf(n,k):
    d=INFO.get(n,[]); idx={'name':0,'role':1,'location':2,'client':3}[k]
    return d[idx] if len(d)>idx else ''
FULL={n:inf(n,'name') or n for n in ORDER}
def mmss(x): return f'{int(x//60)}:{x%60:04.1f}'
HDR=PatternFill('solid',fgColor='1F2A1F'); HF=Font(bold=True,color='FFFFFF',name='Calibri',size=11); GREEN=PatternFill('solid',fgColor='DCEFC0'); GREY=PatternFill('solid',fgColor='F3F3F3'); thin=Side(style='thin',color='D0D0D0'); BORD=Border(left=thin,right=thin,top=thin,bottom=thin)
WRAP=Alignment(wrap_text=True,vertical='top')
def header(ws,cols,widths):
    ws.append(cols)
    for c,w in enumerate(widths,1):
        cell=ws.cell(row=1,column=c); cell.fill=HDR; cell.font=HF; cell.alignment=Alignment(wrap_text=True,vertical='center'); ws.column_dimensions[get_column_letter(c)].width=w
    ws.row_dimensions[1].height=32; ws.freeze_panes='A2'
def fit_height(ws,row,texts_widths):
    lines=1
    for t,w in texts_widths: lines=max(lines,sum(max(1,-(-len(p)//max(1,int(w*1.1)))) for p in str(t).split('\n')))
    ws.row_dimensions[row].height=min(409,max(18,15*lines))
wb=Workbook(); ws=wb.active; ws.title='README'
for line in ["AML 'Share a Story' – transcripts of the 9 participant videos, split by question",'',
 'HOW TO USE',
 "• 'All answers' – one row per person per question (sorted by question so you can compare). Use the filter on 'In current video?' to see what the 2:31 cut already uses, and fill the blue 'Your pick' / 'Your notes' columns.",
 "• 'By question' – the same answers side by side (one row per question, one column per person) – quickest view for choosing the best answer.",
 "• One sheet per person – the complete transcript in time order, tagged with the question each sentence belongs to.",
 '',
 'THINGS TO KNOW',
 '• The transcripts are automatic speech recognition (not hand-corrected): names, song/book titles and Indian-English words can be wrong (e.g. "Shoe Dog", "Wake Up Sid", "Love You Zindagi", "7 Rings" are best guesses). Check against the video before using a title.',
 '• Not everyone read the questions aloud, and a few answered in a different order (Monesh, Shobhita). Questions were matched to answers from the content; where someone skipped a question the cell says so.',
 '• Where the question was read aloud it is shown in "Question as read aloud"; the answer column starts after it. Some answers run on into the next sentence – the per-person sheets show the full flow.',
 "• 'Video time' is the position in the original Teams recording you uploaded (mm:ss.s), not the position in the edited video.",
 "• 'In current video?' marks answers used in the latest cut (ShareAStory_QnA_v14). Split-screen merges are marked with the shared word."]:
    ws.append([line])
ws.column_dimensions['A'].width=140
for r in range(1,ws.max_row+1): ws.cell(row=r,column=1).alignment=Alignment(wrap_text=True,vertical='top')
ws['A1'].font=Font(bold=True,size=14); ws['A3'].font=Font(bold=True); ws['A9'].font=Font(bold=True)
# ---- All answers
wa=wb.create_sheet('All answers'); cols=['Q#','Question','Person','Location','Role','Client','Question as read aloud','Answer (transcript)','Video time','Length (s)','In current video?','Your pick (Y/N)','Your notes']
header(wa,cols,[5,34,20,13,17,16,30,80,16,9,22,13,30]); row=2
for q in range(1,12):
    for n in ORDER:
        rr=[r for r in R if r['n']==n and r['q']==q]
        if rr:
            r=rr[0]; vals=[q,QTXT[q],FULL[n],inf(n,'location'),inf(n,'role'),inf(n,'client'),r['qread'],r['ans'],f"{mmss(r['s'])} – {mmss(r['e'])}",round(r['e']-r['s'],1),r['inv'],'','']
        else: vals=[q,QTXT[q],FULL[n],inf(n,'location'),inf(n,'role'),inf(n,'client'),'','(no answer to this question found in this video)','','','','','']
        wa.append(vals)
        for c in range(1,14):
            cell=wa.cell(row=row,column=c); cell.alignment=WRAP; cell.border=BORD
        if vals[10]: wa.cell(row=row,column=11).fill=GREEN
        if not rr: 
            for c in range(1,14): wa.cell(row=row,column=c).fill=GREY
        for c in (12,13): wa.cell(row=row,column=c).fill=PatternFill('solid',fgColor='E3F0FF')
        fit_height(wa,row,[(vals[1],34),(vals[6],30),(vals[7],80)]); row+=1
wa.auto_filter.ref=f'A1:M{row-1}'
# ---- By question
wq=wb.create_sheet('By question'); header(wq,['Q#','Question']+[FULL[n] for n in ORDER],[5,30]+[38]*9); wq.freeze_panes='C2'
for q in range(1,12):
    vals=[q,QTXT[q]]; used=[]
    for n in ORDER:
        rr=[r for r in R if r['n']==n and r['q']==q]; vals.append(rr[0]['ans'] if rr else '— none —'); used.append(bool(rr and rr[0]['inv']))
    wq.append(vals); rw=q+1
    for c in range(1,12):
        cell=wq.cell(row=rw,column=c); cell.alignment=WRAP; cell.border=BORD
        if c>2 and used[c-3]: cell.fill=GREEN
    fit_height(wq,rw,[(vals[1],30)]+[(v,38) for v in vals[2:]])
wq.cell(row=14,column=1,value='Green = already used in the current video (v14).').font=Font(italic=True)
# ---- per person full transcripts
for n in ORDER:
    ws_=S.words(n); wp=wb.create_sheet(FULL[n].split()[0][:25]); header(wp,['Time','Q#','Question','What was said'],[9,5,36,120]); rows_=[r for r in R if r['n']==n]
    def tag(i):
        for r in rows_:
            if r['i0']<=i<=r['i1']: return r['q']
        return None
    sents=[];cur=[]
    for k,w in enumerate(ws_):
        if cur and ((w[1]-ws_[k-1][2])>0.9 or len(cur)>=30): sents.append(cur);cur=[]
        cur.append((k,w))
        if re.search(r'[.?!]$',w[0]): sents.append(cur);cur=[]
    if cur: sents.append(cur)
    r_=2
    for s_ in sents:
        q=tag(s_[0][0]); lab=('Intro' if q is None and s_[0][0]<min([x['i0'] for x in rows_] or [0]) else ('(between answers)' if q is None else ''))
        wp.append([mmss(orig_time(n,s_[0][1][1])),q if q else '',QTXT[q] if q else lab,' '.join(x[1][0] for x in s_)])
        for c in range(1,5): wp.cell(row=r_,column=c).alignment=WRAP
        if q and any(x['inv'] for x in rows_ if x['q']==q): wp.cell(row=r_,column=2).fill=GREEN
        fit_height(wp,r_,[(wp.cell(row=r_,column=4).value,120),(wp.cell(row=r_,column=3).value,36)]); r_+=1
import os
os.makedirs('/mnt/user-data/outputs/transcripts',exist_ok=True); p='/mnt/user-data/outputs/transcripts/AML_ShareAStory_transcripts.xlsx'; wb.save(p); print('saved',p)
