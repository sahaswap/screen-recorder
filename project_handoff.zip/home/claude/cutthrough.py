import json,re,subprocess,numpy as np
def aud(path,ss,dur):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',path,'-vn','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(r,np.int16).astype(float)/32768
def db(x): return 20*np.log10(np.sqrt((x**2).mean())+1e-6) if len(x)>10 else -99
def test(items,label):
    bad_end=[];bad_start=[]
    for (i,n,src,ss,dur) in items:
        body=aud(src,ss,dur); lv=[db(body[int(t*16000):int((t+0.1)*16000)]) for t in np.arange(0,max(0.2,dur-0.1),0.1)]; sp=np.percentile(lv,90)
        after=db(aud(src,ss+dur,0.20)); before=db(aud(src,ss-0.20,0.20))
        if after>sp-15: bad_end.append((i,n,round(after-sp,1)))
        if before>sp-15: bad_start.append((i,n,round(before-sp,1)))
    print(f'{label}: clips cut while speech continues right after the end: {len(bad_end)} {bad_end} | start cuts into speech: {len(bad_start)} {bad_start}')
new=json.load(open('/home/claude/cut2_info.json'))
test([(x['i'],x['n'],x['src'],x['ss'],x['dur']) for x in new],'NEW build')
old=[]
for k,l in enumerate([l for l in open('/home/claude/mont/cut_build.sh') if '-ss ' in l and '/mont/seq/c' in l],1):
    m=re.search(r'-ss ([\d.]+) -t ([\d.]+) -i "([^"]+)".*?/mont/seq/c\d+_(\w+)/',l); old.append((k,m.group(4),m.group(3),float(m.group(1)),float(m.group(2))))
test(old,'OLD build')
