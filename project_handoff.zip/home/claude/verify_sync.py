import subprocess,glob,json,numpy as np
SP=json.load(open('/home/claude/curated_spans.json'))
clips=sorted(c for c in glob.glob('/home/claude/mont/cut/[0-9][0-9]_*.mp4') if 'title' not in c)
def frames(c):
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-i',c,'-an','-vf','fps=16,crop=iw*0.6:ih*0.7:iw*0.2:ih*0.05,scale=96:64,format=gray','-f','rawvideo','-'],capture_output=True).stdout
    return np.frombuffer(raw,np.uint8).reshape(-1,64,96).astype(float)
def audio(c):
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-i',c,'-vn','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(raw,np.int16).astype(float)/32768
rows=[]
for i,(c,o) in enumerate(zip(clips,SP),1):
    f=frames(c); a=audio(c)
    mot=np.abs(np.diff(f,axis=0)).mean(axis=(1,2)); n=len(mot)
    env=np.array([np.sqrt((a[int(k*1000):int((k+1)*1000)]**2).mean()+1e-12) for k in range(n+1)])[:n+1]
    env=np.log(env[1:n+1]+1e-4)
    # skip first/last 0.3s (fades, tag animation)
    m=mot[5:-5]; e=env[5:-5]
    if len(m)<20: rows.append((i,o['n'],None,None)); continue
    m=(m-m.mean())/(m.std()+1e-9); e=(e-e.mean())/(e.std()+1e-9)
    best=None
    for lag in range(-10,11):   # lag in frames: positive = motion happens later than audio
        if lag>=0: x,y=m[lag:],e[:len(e)-lag]
        else: x,y=m[:lag],e[-lag:]
        r=float((x*y).mean())
        if best is None or r>best[1]: best=(lag,r)
    r0=float((m*e).mean())
    rows.append((i,o['n'],best[0],round(best[1],2),round(r0,2)))
lags=[r[2] for r in rows if r[2] is not None]
import collections
print('lag distribution (frames @16fps, 1 frame = 62 ms):',sorted(collections.Counter(lags).items()))
print('clips with peak lag beyond +/-3 frames AND a clear peak (corr>0.35):')
for r in rows:
    if r[2] is not None and abs(r[2])>3 and r[3]>0.35: print('  #%d %s lag=%+d frames corr=%.2f (corr at 0: %.2f)'%r)
print('median correlation at lag 0:',round(float(np.median([r[4] for r in rows if r[2] is not None])),2))
json.dump(rows,open('/home/claude/verify_sync.json','w'))
