import glob,subprocess,json,numpy as np
info=json.load(open('/home/claude/cut2_info.json'))
clips=sorted(c for c in glob.glob('/home/claude/mont/cut2/[0-9][0-9]_*.mp4') if 'title' not in c)
def aud(c):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-i',c,'-vn','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(r,np.int16).astype(float)/32768
def rms(a,t0,t1):
    x=a[int(t0*16000):int(t1*16000)]; return 20*np.log10(np.sqrt((x**2).mean())+1e-6) if len(x)>10 else -99
cut_end=[];cut_start=[]
for c,o in zip(clips,info):
    a=aud(c); d=len(a)/16000
    lv=[rms(a,t,t+0.1) for t in np.arange(0.3,d-0.3,0.1)]; speech=np.percentile(lv,90)
    e=rms(a,d-0.34,d-0.14)      # just before the closing fade
    s=rms(a,0.08,0.28)           # just after the opening fade
    if e>speech-14: cut_end.append((o['i'],o['n'],round(e,1),round(speech,1)))
    if s>speech-10: cut_start.append((o['i'],o['n'],round(s,1),round(speech,1)))
print('clips whose END is still loud:',len(cut_end),cut_end)
print('clips whose START is already loud:',len(cut_start),cut_start)
