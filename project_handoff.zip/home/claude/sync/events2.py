import sys,numpy as np,json,warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/home/claude/sync'); sys.path.insert(0,'/home/claude')
import lipsync_mp as L
from reedit_lib import UP,plans
def events(m,env,pause=0.25,rise=10):
    es=np.convolve(env,np.ones(5)/5,'same'); floor=np.percentile(es,15); thr=floor+rise; above=es>thr; res=[]; P=int(pause*100); k=P
    sm=np.convolve(np.nan_to_num(m,nan=np.nanmedian(m)),np.ones(3)/3,'same'); sd=np.nanstd(m)
    while k<len(es)-40:
        if above[k] and not above[k-P:k].any() and above[k:k+30].mean()>0.85:
            ta=k/100.0; i0=int((ta-0.5)*16); i1=int((ta+0.2)*16)
            if i0>=0 and i1<len(m) and not np.isnan(m[i0:i1]).any():
                d=np.diff(sm[i0:i1]); j=int(np.argmax(d))
                if d[j]>0.35*sd: res.append(ta-(i0+j+0.5)/16.0)
            k+=P
        else: k+=1
    return res
tab={}
for n in ['Malavikka','Ananya','Mohammed','Irin','Riddhima','Ayush','Shobhita','Arijit','Monesh']:
    m=np.load(f'/home/claude/sync/open_{n}.npy'); env=L.envelope(UP+plans[n]['file']); ev=np.array(events(m,env))
    ev=ev[(ev>-0.3)&(ev<0.7)]; tab[n]=ev.tolist()
    print(f"{n:10} onset-event offset {np.median(ev)*1000:+5.0f} ms from {len(ev):2d} events | middle half {np.percentile(ev,25)*1000:+.0f}..{np.percentile(ev,75)*1000:+.0f} ms" if len(ev)>=5 else f"{n:10} too few events ({len(ev)})")
json.dump(tab,open('/home/claude/sync/events2.json','w'))
allv=np.concatenate([np.array(v) for v in tab.values() if len(v)>=5]); print('all speakers pooled: median %+.0f ms from %d events'%(np.median(allv)*1000,len(allv)))
