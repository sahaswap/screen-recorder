import sys,subprocess,json,time,warnings,os
os.environ['GLOG_minloglevel']='3'; warnings.filterwarnings('ignore')
import numpy as np,cv2
import mediapipe as mp
sys.path.insert(0,'/home/claude')
from reedit_lib import UP,plans
FPS=16; W,H=640,360
fm=mp.solutions.face_mesh.FaceMesh(static_image_mode=False,max_num_faces=1,refine_landmarks=False,min_detection_confidence=0.5,min_tracking_confidence=0.5)
def openness(src,t0=0,dur=None):
    cmd=['ffmpeg','-nostdin','-v','error']+(['-ss',str(t0)] if t0 else [])+(['-t',str(dur)] if dur else [])+['-i',src,'-vf',f'fps={FPS},scale={W}:{H}','-f','rawvideo','-pix_fmt','rgb24','-']
    p=subprocess.Popen(cmd,stdout=subprocess.PIPE); o=[]
    while True:
        b=p.stdout.read(W*H*3)
        if len(b)<W*H*3: break
        im=np.frombuffer(b,np.uint8).reshape(H,W,3); r=fm.process(im)
        if r.multi_face_landmarks:
            L=r.multi_face_landmarks[0].landmark; fh=abs(L[152].y-L[10].y)*H; o.append(abs(L[14].y-L[13].y)*H/max(fh,1)*3.0 if fh>40 else np.nan)
        else: o.append(np.nan)
    return np.array(o)
def envelope(src,t0=0,dur=None):
    cmd=['ffmpeg','-nostdin','-v','error']+(['-ss',str(t0)] if t0 else [])+(['-t',str(dur)] if dur else [])+['-i',src,'-vn','-f','f32le','-ac','1','-ar','16000','-']
    a=np.frombuffer(subprocess.run(cmd,capture_output=True).stdout,np.float32); hop=160; n=len(a)//hop
    e=np.array([np.sqrt((a[i*hop:i*hop+400]**2).mean()) for i in range(n)]); return 20*np.log10(e+1e-6)       # dB at 100 Hz
def detrend(x,w):
    s=np.nan_to_num(x,nan=np.nanmedian(x)); k=np.ones(w)/w; tr=np.convolve(np.pad(s,(w//2,w//2),mode='edge'),k,'valid')[:len(s)]; return s-tr
def xcorr(m,env,lags):
    t=np.arange(len(m))/FPS; ok=~np.isnan(m); ms=detrend(m,FPS*3); ms=(ms-ms[ok].mean())/(ms[ok].std()+1e-9)
    ev=detrend(env,300); ev=np.convolve(ev,np.ones(5)/5,'same'); tt=np.arange(len(ev))/100.0; out=[]
    for L in lags:
        e=np.interp(t+L,tt,ev); e=(e-e[ok].mean())/(e[ok].std()+1e-9); out.append(float((ms[ok]*e[ok]).mean()))
    return np.array(out)
def estimate(m,env):
    lags=np.arange(-0.6,0.6001,0.01); r=xcorr(m,env,lags); k=int(np.argmax(r))
    if 0<k<len(r)-1:
        den=r[k-1]-2*r[k]+r[k+1]; off=0.5*(r[k-1]-r[k+1])/den if abs(den)>1e-9 else 0
    else: off=0
    tau=lags[k]+off*0.01; blocks=[]
    nb=len(m)//(FPS*30)
    for b in range(nb):
        sl=slice(b*FPS*30,(b+1)*FPS*30); mm=m[sl]
        if np.isnan(mm).mean()>0.3: continue
        rb=xcorr(mm,env[b*3000:(b+1)*3000+1000],lags); blocks.append(float(lags[int(np.argmax(rb))]))
    return float(tau),float(r[k]),blocks
if __name__=='__main__':
    names=sys.argv[1:] or ['Malavikka','Ananya','Mohammed','Irin','Riddhima','Ayush','Shobhita','Arijit','Monesh']
    res={}; log=open('/home/claude/sync/lipsync_mp.log','a')
    for n in names:
        t=time.time(); src=UP+plans[n]['file']; m=openness(src); env=envelope(src); T,r,bl=estimate(m,env)
        res[n]=dict(tau=T,peak=r,blocks=bl,face=float(1-np.isnan(m).mean()),frames=len(m))
        line=f"{n:10} audio-vs-picture offset {T*1000:+5.0f} ms | peak correlation {r:.2f} | face tracked on {100*(1-np.isnan(m).mean()):.0f}% of frames | per-30s blocks (ms): {[int(b*1000) for b in bl]} [{time.time()-t:.0f}s]"
        print(line,flush=True); log.write(line+'\n'); log.flush(); json.dump(res,open('/home/claude/sync/lipsync_mp.json','w'))
        np.save(f'/home/claude/sync/open_{n}.npy',m)
    log.write('DONE\n'); log.close()
