import sys,numpy as np,json,warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/home/claude/sync'); sys.path.insert(0,'/home/claude')
import lipsync_mp as L, lipsync_bp as B
from reedit_lib import UP,plans
def events(m,env):
    t=np.arange(len(m))/16.0; es=np.convolve(env,np.ones(5)/5,'same'); floor=np.percentile(es,15); thr=floor+14; above=es>thr; res=[]
    k=60
    while k<len(es)-60:
        if above[k] and not above[k-60:k].any() and above[k:k+50].mean()>0.8:
            ta=k/100.0; i0=int((ta-0.7)*16); i1=int((ta+0.3)*16)
            if i0>=0 and i1<len(m) and not np.isnan(m[i0:i1]).any():
                seg=np.convolve(m[i0:i1],np.ones(3)/3,'same'); d=np.diff(seg); j=int(np.argmax(d)); tm=(i0+j+0.5)/16.0
                if d[j]>0.25*np.std(m[~np.isnan(m)]): res.append(ta-tm)
            k+=60
        else: k+=1
    return res
out={}
for n in ['Malavikka','Ananya','Mohammed','Irin','Riddhima','Ayush','Shobhita','Arijit','Monesh']:
    m=np.load(f'/home/claude/sync/open_{n}.npy'); env=L.envelope(UP+plans[n]['file'])
    tau,pk,bl,lags,r=B.estimate(m,env); ev=events(m,env); evm=float(np.median(ev)) if len(ev)>=4 else None
    out[n]=dict(rhythm=tau,peak=pk,blocks=bl,event_median=evm,event_n=len(ev),event_q=[float(np.percentile(ev,25)),float(np.percentile(ev,75))] if len(ev)>=4 else None)
    print(f"{n:10} rhythm method {tau*1000:+5.0f} ms (r {pk:.2f}; blocks {[int(b*1000) for b in bl]}) | onset-event method "+(f"{evm*1000:+5.0f} ms from {len(ev)} events (middle half {out[n]['event_q'][0]*1000:+.0f}..{out[n]['event_q'][1]*1000:+.0f})" if evm is not None else f"too few events ({len(ev)})"),flush=True)
json.dump(out,open('/home/claude/sync/both.json','w'))
