import sys,json,subprocess,numpy as np,warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/home/claude/sync'); sys.path.insert(0,'/home/claude')
import lipsync_mp as L, lipsync_bp as B
from scipy.signal import butter,sosfiltfilt
def measure(video,timeline,who=None):
    T=json.load(open(timeline)); segs=[s for s in T['segs'] if s['type']=='single' and s['round']>=0]
    allenv=L.envelope(video); lags=np.arange(-0.5,0.5001,0.01); acc={}
    for s in segs:
        n=s['who']
        if who and n not in who: continue
        t0=s['start']/48.0; dur=s['frames']/48.0
        if dur<1.5: continue
        m=L.openness(video,t0,dur); a0=int(t0*100); env=allenv[a0:a0+int(dur*100)+10]
        if np.isnan(m).mean()>0.4 or len(m)<20: continue
        ok=~np.isnan(m); ms=np.nan_to_num(m,nan=np.nanmedian(m)); mb=sosfiltfilt(butter(2,[1.5,6.5],'bandpass',fs=16,output='sos'),ms) if len(ms)>40 else None
        eb=sosfiltfilt(butter(2,[1.5,6.5],'bandpass',fs=100,output='sos'),env) if len(env)>200 else None
        if mb is None or eb is None: continue
        c=int(0.3*16); tt=np.arange(len(m))/16.0; te=np.arange(len(eb))/100.0; sel=np.zeros(len(m),bool); sel[c:len(m)-c]=ok[c:len(m)-c]
        if sel.sum()<15: continue
        mz=mb-mb[sel].mean(); r=[]
        for lg in lags:
            e=np.interp(tt+lg,te,eb); e=e-e[sel].mean(); r.append(((mz[sel]*e[sel]).sum(),(mz[sel]**2).sum(),(e[sel]**2).sum()))
        a=acc.setdefault(n,[np.zeros(len(lags)),np.zeros(len(lags)),np.zeros(len(lags))])
        for i,(p,q,w) in enumerate(r): a[0][i]+=p; a[1][i]+=q; a[2][i]+=w
    res={}
    for n,(p,q,w) in acc.items():
        rr=p/np.sqrt(q*w+1e-12); k=int(np.argmax(rr)); off=0.0
        if 0<k<len(rr)-1:
            den=rr[k-1]-2*rr[k]+rr[k+1]; off=0.5*(rr[k-1]-rr[k+1])/den*0.01 if abs(den)>1e-9 else 0
        res[n]=(float(lags[k]+off),float(rr[k]))
    return res
if __name__=='__main__':
    res=measure(sys.argv[1],sys.argv[2]); print('residual sound-vs-picture offset in the finished video (output time; + = sound late):')
    for n,(o,r) in sorted(res.items()): print(f'  {n:10} {o*1000:+5.0f} ms   (peak r {r:.2f})')
    json.dump(res,open(sys.argv[3],'w'))
