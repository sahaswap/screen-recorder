import sys,numpy as np
sys.path.insert(0,'/home/claude/sync'); sys.path.insert(0,'/home/claude')
from scipy.signal import butter,sosfiltfilt
FPS=16
def bp(x,fs,lo,hi): sos=butter(2,[lo,hi],'bandpass',fs=fs,output='sos'); return sosfiltfilt(sos,x)
def features(m,env):
    ok=~np.isnan(m); ms=np.nan_to_num(m,nan=np.nanmedian(m)); mb=bp(ms,FPS,1.5,6.5)
    eb=bp(env,100,1.5,6.5); t=np.arange(len(m))/FPS; tt=np.arange(len(env))/100.0
    return ok,mb,eb,t,tt
def curve(m,env,lags,sl=None):
    ok,mb,eb,t,tt=features(m,env)
    if sl is not None: ok=ok&sl
    mb=(mb-mb[ok].mean())/(mb[ok].std()+1e-9); out=[]
    for L in lags:
        e=np.interp(t+L,tt,eb); e=(e-e[ok].mean())/(e[ok].std()+1e-9); out.append(float((mb[ok]*e[ok]).mean()))
    return np.array(out)
def estimate(m,env,span=0.5):
    lags=np.arange(-span,span+0.001,0.01); r=curve(m,env,lags); k=int(np.argmax(r))
    off=0.0
    if 0<k<len(r)-1:
        den=r[k-1]-2*r[k]+r[k+1]; off=0.5*(r[k-1]-r[k+1])/den*0.01 if abs(den)>1e-9 else 0.0
    # block consistency: 30 s blocks
    blocks=[]; nb=len(m)//(FPS*30)
    for b in range(nb):
        sl=np.zeros(len(m),bool); sl[b*FPS*30:(b+1)*FPS*30]=True
        if np.isnan(m[sl]).mean()>0.3: continue
        rb=curve(m,env,lags,sl); blocks.append(float(lags[int(np.argmax(rb))]))
    return float(lags[k]+off),float(r[k]),blocks,lags,r
if __name__=='__main__':
    import lipsync_mp as L
    from reedit_lib import UP,plans
    for n in sys.argv[1:]:
        m=np.load(f'/home/claude/sync/open_{n}.npy'); env=L.envelope(UP+plans[n]['file']); tau,pk,bl,lags,r=estimate(m,env)
        print(f"{n:10} offset {tau*1000:+5.0f} ms | peak r {pk:.2f} | blocks(ms) {[int(b*1000) for b in bl]} | curve ms:r  "+' '.join(f'{int(l*1000)}:{x:.2f}' for l,x in zip(lags[::5],r[::5])))
