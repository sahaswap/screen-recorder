import json,sys,subprocess,os,re,math
sys.path.insert(0,'/home/claude')
from montage_lib import *
from PIL import Image
BOX=json.load(open('/home/claude/det/boxes.json'))
SPANS=json.load(open('/home/claude/all_spans.json'))
ENC='-c:v libx264 -preset fast -crf 21 -profile:v high -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 -c:a aac -b:a 64k -ar 16000 -ac 1'
UP='/mnt/user-data/uploads/'; OUT='/mnt/user-data/outputs/montage/'
NAMEQ={1:'Introduce_yourself_in_3_words',2:'My_Deloitte_journey',3:'Unexpectedly_good_at',4:'First_week_surprise',5:'One_thing_your_team_should_know',6:'Hidden_talent',7:'Looking_forward_to',8:'One_word_for_your_team',9:'Theme_song',10:'Most_common_phrase',11:'Project_in_one_word'}
def vol(src,ss,dur,key):
    r=subprocess.run(['ffmpeg','-nostdin','-v','info','-ss',f'{ss:.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-af','volumedetect','-f','null','-'],capture_output=True,text=True).stderr
    m=re.search(key+r': (-?[\d.]+) dB',r); return float(m.group(1)) if m else -91.0
def extend_short(n,s,e,minlen=3.0):
    m=seg_map(n); mid=(s+e)/2
    i=next((k for k,(a,b,o) in enumerate(m) if a<=mid<=b),min(range(len(m)),key=lambda k:abs((m[k][0]+m[k][1])/2-mid)))
    S_i,E_i,a=m[i]; os_=a+(s-S_i); oe=a+(e-S_i); src=UP+plans[n]['file']
    for dur in (minlen,2.7,2.4):
        ss=os_-0.15
        if vol(src,oe,max(0.2,ss+dur-oe),'max_volume')<-32: return src,ss,dur
    return None
def make_seq(n,cid,dur):
    N=int(round(dur*48)); d=f'/home/claude/mont/seq/{cid}'; os.makedirs(d,exist_ok=True)
    c=f'/home/claude/mont/cache/{n}'; blank=f'/home/claude/mont/cache/blank_{n}.png'
    if not os.path.exists(blank): Image.new('RGBA',Image.open(f'{c}/hold.png').size,(0,0,0,0)).save(blank)
    n_in=54; n_ex=31; ex=max(n_in,N-46)
    for k in range(N):
        if k<n_in: t=f'{c}/in_{k:04d}.png'
        elif k>=ex+n_ex: t=blank
        elif k>=ex: t=f'{c}/out_{k-ex:04d}.png'
        else: t=f'{c}/hold.png'
        lk=f'{d}/{k:04d}.png'
        if os.path.lexists(lk): os.remove(lk)
        os.symlink(t,lk)
    return d
sh=['cd /home/claude','rm -f mont/all_build.log']; lists={}
def add(cmd): sh.append(cmd+' && echo ok >> mont/all_build.log || echo FAIL >> mont/all_build.log')
lists[1]=['/home/claude/mont/clips/00_title.mp4']+[f'/home/claude/mont/clips/{i:02d}_{n}.mp4' for i,n in enumerate(['Malavikka','Monesh','Riddhima','Mohammed','Ananya','Irin','Arijit','Ayush','Shobhita'],1)]
notes=[]
for q in range(2,12):
    os.makedirs(f'/home/claude/mont/q{q:02d}',exist_ok=True)
    tf=f'/home/claude/mont/q{q:02d}/00_title.mp4'
    add(f'ffmpeg -y -nostdin -v error -framerate 48 -i /home/claude/mont/title_q{q}/%04d.png -f lavfi -i anullsrc=r=16000:cl=mono -t 3.0 -vf "fade=t=out:st=2.75:d=0.25,format=yuv420p" {ENC} -shortest {tf}')
    lists[q]=[tf]
    for i,o in enumerate(SPANS[str(q)],1):
        n=o['n']; ln=o['e']-o['s']; bx=BOX[n]
        if ln<3.0:
            ex=extend_short(n,o['s'],o['e'])
            if ex: src,ss,dur=ex; notes.append(f'Q{q} {n}: short answer ({ln:.1f}s) padded to {dur:.1f}s using the original footage')
            else:
                src=f'/mnt/user-data/outputs/softcut/{NAMES[n]}_softcut.mp4'; ss=o['s']+SHIFT.get(n,0); dur=ln; notes.append(f'Q{q} {n}: short answer ({ln:.1f}s) could not be padded')
        elif o['kind']=='orig': src=UP+plans[n]['file']; ss=o['so']; dur=ln
        else: src=f'/mnt/user-data/outputs/softcut/{NAMES[n]}_softcut.mp4'; ss=o['s']+SHIFT.get(n,0); dur=ln
        mean=vol(src,ss,dur,'mean_volume'); gain=max(-12,min(15,-18.5-mean))
        seq=make_seq(n,f'q{q:02d}_{i:02d}_{n}',dur)
        vf=(f'[0:v]fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:877:shortest=1,fade=t=in:st=0:d=0.12,fade=t=out:st={dur-0.12:.3f}:d=0.12[v]')
        af=(f'[0:a]aresample=16000,aformat=channel_layouts=mono,volume={gain:.2f}dB,alimiter=limit=0.89,afade=t=in:st=0:d=0.10,afade=t=out:st={dur-0.14:.3f}:d=0.14[a]')
        out=f'/home/claude/mont/q{q:02d}/{i:02d}_{n}.mp4'
        add(f'ffmpeg -y -nostdin -v error -ss {ss:.3f} -t {dur:.3f} -i "{src}" -framerate 48 -i {seq}/%04d.png -filter_complex "{vf};{af}" -map "[v]" -map "[a]" -t {dur:.3f} {ENC} {out}')
        lists[q].append(out)
sh.append(f'mkdir -p {OUT}')
for q in range(1,12):
    lf=f'/home/claude/mont/list_q{q:02d}.txt'; open(lf,'w').write(''.join(f"file '{f}'\n" for f in lists[q]))
    sh.append(f'ffmpeg -y -nostdin -v error -f concat -safe 0 -i {lf} -c copy -movflags +faststart {OUT}Q{q:02d}_{NAMEQ[q]}.mp4 && echo "Q{q} OK" >> mont/all_build.log')
open('/home/claude/mont/list_master.txt','w').write(''.join(f"file '{f}'\n" for q in range(1,12) for f in lists[q]))
sh.append(f'ffmpeg -y -nostdin -v error -f concat -safe 0 -i /home/claude/mont/list_master.txt -c copy -movflags +faststart {OUT}All_questions_montage.mp4 && echo "MASTER OK" >> mont/all_build.log')
sh.append('echo ALLDONE >> mont/all_build.log')
open('/home/claude/mont/all_build.sh','w').write('\n'.join(sh)+'\n')
print(len(sh),'steps;',sum(len(v) for v in lists.values())-1,'files;')
print('\n'.join(notes))
