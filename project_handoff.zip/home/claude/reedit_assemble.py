import sys,json,subprocess,os
sys.path.insert(0,'/home/claude')
ROOT='/home/claude/mont/re'; XD=0.30
ENC_I='-c:v libx264 -preset fast -crf 16 -profile:v high -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 -c:a aac -b:a 128k -ar 16000 -ac 1'
ENC_S='-c:v libx264 -preset fast -crf 17 -profile:v high -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 -c:a aac -b:a 128k -ar 16000 -ac 1'
ENC_F='-c:v libx264 -preset fast -crf 21 -profile:v high -pix_fmt yuv420p -r 48 -x264-params scenecut=0 -c:a aac -b:a 64k -ar 16000 -ac 1 -movflags +faststart'
def vdur(p): return float(subprocess.check_output(['ffprobe','-v','error','-select_streams','v','-show_entries','stream=duration','-of','csv=p=0',p]).decode())
def chain(files,out,enc,first_fade=0.0,last_fade=0.0):
    vd=[vdur(f) for f in files]; starts=[]; cum=0.0
    for i,d in enumerate(vd): starts.append(0.0 if i==0 else cum-XD); cum=d if i==0 else cum-XD+d
    inp=' '.join(f'-itsoffset {s:.3f} -i "{f}"' for s,f in zip(starts,files)); fc=''
    for i,d in enumerate(vd): fc+=f'[{i}:a]aresample=16000,aformat=channel_layouts=mono,apad=whole_dur={d:.4f},atrim=0:{d:.4f},asetpts=PTS-STARTPTS[a{i}];'
    cv='[0:v]'; ca='[a0]'; T=vd[0]
    for i in range(1,len(files)):
        fc+=f'{cv}[{i}:v]xfade=transition=fade:duration={XD}:offset={T-XD:.3f}[x{i}];{ca}[a{i}]acrossfade=d={XD}:c1=tri:c2=tri[c{i}];'
        cv=f'[x{i}]'; ca=f'[c{i}]'; T=T-XD+vd[i]
    vf=''; af=''
    if first_fade: vf+=f'fade=t=in:st=0:d={first_fade},'; af+=f'afade=t=in:st=0:d={first_fade},'
    if last_fade: vf+=f'fade=t=out:st={T-last_fade:.3f}:d={last_fade},'; af+=f'afade=t=out:st={T-last_fade:.3f}:d={last_fade},'
    fc+=f'{cv}{vf}format=yuv420p[vo];{ca}{af}anull[ao]'
    return f'ffmpeg -y -nostdin -v error {inp} -filter_complex "{fc}" -map "[vo]" -map "[ao]" {enc} {out}',T
stage=sys.argv[1]; man=json.load(open(ROOT+'/manifest.json'))['sections']
os.makedirs(ROOT+'/sec',exist_ok=True); os.makedirs(ROOT+'/ttl',exist_ok=True)
if stage=='titles':
    L=[]
    for i in range(10):
        L.append(f'ffmpeg -y -nostdin -v error -framerate 48 -i /home/claude/mont/ntitle_{i}/%04d.png -f lavfi -i anullsrc=r=16000:cl=mono -t 2.4 -vf format=yuv420p {ENC_I} -shortest {ROOT}/ttl/title_{i}.mp4')
    L.append(f'ffmpeg -y -nostdin -v error -loop 1 -framerate 48 -i /home/claude/mont/pause_bg.png -f lavfi -i anullsrc=r=16000:cl=mono -t 1.4 -vf format=yuv420p {ENC_I} -shortest {ROOT}/ttl/pause.mp4')
    open(ROOT+'/titles.sh','w').write('\n'.join(L)+'\n')
elif stage=='sections':
    L=[]; info={}
    for q,row in man:
        files=([ROOT+'/ttl/pause.mp4'] if q==2 else [])+[f'{ROOT}/ttl/title_{q-1}.mp4']+[o for o,d in row]
        c,T=chain(files,f'{ROOT}/sec/S{q:02d}.mp4',ENC_S); L.append(c); info[q]=(len(files),round(T,1))
    open(ROOT+'/sections.sh','w').write('\n'.join(L)+'\n'); print(info)
elif stage=='final':
    files=[f'{ROOT}/sec/S{q:02d}.mp4' for q,row in man]
    c,T=chain(files,'/home/claude/mont/Curated_QnA_reedit.mp4',ENC_F,first_fade=0.8,last_fade=1.5)
    open(ROOT+'/final.sh','w').write(c+'\n'); print('final length',round(T,1),'s')
