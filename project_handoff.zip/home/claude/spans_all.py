import sys,re,json
sys.path.insert(0,'/home/claude')
src=open('/home/claude/captions.py').read().split("if __name__")[0]
ns={}; exec(src,ns); build=ns['build']
from montage_lib import plans,to_source,SHIFT
ORDER=['Malavikka','Monesh','Riddhima','Mohammed','Ananya','Irin','Arijit','Ayush','Shobhita']
def norm(t): return re.sub(r"\s+"," ",re.sub(r"[^a-z0-9' ]"," ",t.lower())).strip()
W={}
def words(n):
    if n not in W:
        w,_=build(n,SHIFT.get(n,0.0)); W[n]=w
    return W[n]
def locate(ws,phrase,after=0):
    toks=[norm(w[0]) for w in ws]; pos=[];s=''
    for t in toks: pos.append(len(s)+ (1 if s else 0)); s=(s+' '+t).strip() if s else t
    p=norm(phrase); i=s.find(p,pos[after] if after<len(pos) else 0)
    if i<0: raise ValueError(f'not found: {phrase}')
    a=max(k for k,x in enumerate(pos) if x<=i); j=i+len(p)-1; b=max(k for k,x in enumerate(pos) if x<=j)
    return a,b
def span(n,sp,ep,lead=0.30,tail=0.45):
    ws=words(n); a,_=locate(ws,sp); _,b=locate(ws,ep,a)
    s=ws[a][1]-lead; e=ws[b][2]+tail
    if b+1<len(ws): e=min(e,ws[b+1][1]-0.05)
    if a>0: s=max(s,ws[a-1][2]+0.05)
    return max(0,round(s,3)),round(e,3),' '.join(w[0] for w in ws[a:b+1])
SPEC={
2:{'Malavikka':("My Deloitte journey is going to be exciting","full of growth"),'Monesh':("It's close to nine months at Deloitte","continuing to grow"),
   'Riddhima':("My Deloitte journey so far has been full","learning more"),'Mohammed':("My Deloitte journey is going to be an exciting ride","lots of growth"),
   'Ananya':("My Deloitte journey so far has been like a roller coaster","good friendships and memories"),'Irin':("My Deloitte journey has been challenging me","excellent every day"),
   'Arijit':("So I would say my Deloitte journey has been awesome","awesome so far"),'Ayush':("A roller coaster of learning","and opportunities"),
   'Shobhita':("My Deloitte journey has been an exciting chapter","new opportunities")},
3:{'Malavikka':("I'm surprisingly good at giving advice","tiniest details"),'Riddhima':("Something that I am unexpectedly or weirdly good at","notes of the song"),
   'Mohammed':("So I would say I'm surprisingly good at remembering","expect me to remember"),'Ananya':("Something that I'm unexpectedly good at","read minds"),
   'Irin':("I am unexpectedly good at making Excel","do magic"),'Arijit':("So I would say I am good at cooking","made the best"),
   'Ayush':("Turning spontaneous ideas","actual plans"),'Shobhita':("I'm surprisingly good at networking","unexpected situations")},
4:{'Malavikka':("the amount of support","settling in so much easier"),'Monesh':("the first week was really amazing","our dear colleagues"),
   'Mohammed':("Honestly how welcoming","a lot easier for me"),'Ananya':("One thing that surprised me the most","remember them all"),
   'Irin':("What surprised me was how quickly","became teammates"),'Arijit':("So it was like there was no target","surprised me the most"),
   'Ayush':("Like how many people","help you settle in"),'Shobhita':("What surprised me the most during the first week","learn and explore")},
5:{'Malavikka':("I take a little time to open up","love helping people"),'Monesh':("On the personal note","making work enjoyable"),
   'Riddhima':("that I'm always up to learn something new","feeling down"),'Mohammed':("So I'm always up for learning something new","learn and grow"),
   'Ananya':("Something my new team should know about me","share my ideas"),'Irin':("One thing my team should know","I'll do it"),
   'Arijit':("that I'm very terrified about","bit fun"),'Ayush':("I'm always curious","learning something new"),
   'Shobhita':("One thing that my team should know about me","opportunities exist")},
6:{'Malavikka':("my hidden talent","good to go"),'Monesh':("As of my hidden talent","minimal preparation"),
   'Riddhima':("My hidden talent is","able to do that"),'Mohammed':("So I would say I'm pretty good at keeping calm","little chaotic"),
   'Ananya':("As for my hidden talent","and drawing"),'Irin':("My hidden talent is I can dance","know these steps"),
   'Arijit':("I would say I can speak five languages","problem-solving skills"),'Ayush':("Turning random ideas","exciting plans"),
   'Shobhita':("Now my hidden talent is making connections","comfortable around me")},
7:{'Malavikka':("I'm looking forward to learning new things","memories along the way"),'Monesh':("Looking forward I'm excited to learn more","energetic crowd"),
   'Riddhima':("What am I looking forward to most","across domains"),'Mohammed':("I'm really looking forward to learn","memories along the way"),
   'Ananya':("Going forward I'm looking forward to growth","with you guys"),'Irin':("What I look forward to most","can depend on"),
   'Arijit':("Well at this time of the year","forward to the most"),'Ayush':("Meeting new people","great memories")},
8:{'Malavikka':("one word to describe my new team","very supportive"),'Monesh':("I would like to call this team","terrorist financing"),
   'Riddhima':("One word that I'd like to use","valued here"),'Mohammed':("I would say welcoming","welcoming"),
   'Ananya':("If I had to describe my team","supportive and fun"),'Irin':("One word for my new team","unstoppable"),
   'Arijit':("that I used synergistic","completely synergistic"),'Ayush':("Welcoming","Welcoming"),
   'Shobhita':("If I had to describe my team in one word","supportive")},
9:{'Malavikka':("I think Love You Zindagi","my vibe pretty well"),'Monesh':("After all life is like","having fun"),
   'Riddhima':("If my life had a theme song","hustle I'm facing"),'Mohammed':("I would go with Shoe Dog","from ground up"),
   'Ananya':("If my life had a theme song that would be","goes with my life"),'Irin':("My theme song would be 7 Rings","I got it"),
   'Arijit':("so I'd say the theme song of my life would be","by Queen"),'Ayush':("The Nights by Avicii","gets better"),
   'Shobhita':("I would definitely choose Shin Chan's","get things done")},
10:{'Malavikka':("I think it's let's connect","quite a lot"),'Riddhima':("what's the more common phrase","everyone has heard that"),
    'Mohammed':("It is networking networking","official Deloitte skill"),'Ananya':("the most common phrase that I have heard since joining","never ends so quickly"),
    'Irin':("What I heard after joining Deloitte","fill your timesheet"),'Arijit':("There is only two words","and delighted"),
    'Shobhita':("The phrase that I've heard the most","welcome to Deloitte")},
11:{'Malavikka':("I think it's dynamic","dynamic"),'Monesh':("I would also call the project","expect the unexpected"),
    'Riddhima':("to describe my project in one word","interesting and unique"),'Mohammed':("I would say my project is dynamic","figure out"),
    'Ananya':("If I had to describe my work","understanding things"),'Irin':("My project in one word","detectives"),
    'Arijit':("I would say it's awesome","awesome"),'Ayush':("Intriguing","Intriguing"),
    'Shobhita':("if I had to describe my project in one word","work without phone")}}

OVERRIDE={(2,'Monesh'):("It's close to nine months at Deloitte","really incredible"),
 (4,'Monesh'):("And I was also surprised","our dear colleagues"),
 (5,'Monesh'):("I would say I'm a fun person","keep things lively"),
 (5,'Shobhita'):("One thing that my team should know about me","open to new challenges"),
 (6,'Monesh'):("As of my hidden talent","think on my feet"),
 (7,'Monesh'):("Looking forward I'm excited to learn more","practical expertise"),
 (9,'Monesh'):("After all life is like","ups and downs"),
 (10,'Ananya'):("the most common phrase that I have heard since joining","agree on that"),
 (11,'Ananya'):("If I had to describe my work","digging up things"),
 (11,'Shobhita'):("if I had to describe my project in one word","ODC project")}
for (q,n),v in OVERRIDE.items(): SPEC[q][n]=v
if __name__=='__main__':
    out={}; bad=0
    for q in sorted(SPEC):
        out[q]=[]
        for n in ORDER:
            if n not in SPEC[q]: continue
            sp,ep=SPEC[q][n]
            try: s,e,txt=span(n,sp,ep)
            except Exception as ex: print(f'Q{q} {n}: ERROR {ex}'); bad+=1; continue
            kind,so=to_source(n,s,e); out[q].append(dict(n=n,s=s,e=e,kind=kind,so=so))
            flag=' <-- SHORT' if e-s<2.4 else (' <-- LONG' if e-s>11 else '')
            print(f'Q{q:<2} {n:10} {s:6.2f}-{e:6.2f} {e-s:4.1f}s {kind:8}{flag} | {txt[:95]}')
    json.dump(out,open('/home/claude/all_spans.json','w'))
    print('errors',bad,'| total clips',sum(len(v) for v in out.values()),'| total seconds',round(sum(o['e']-o['s'] for v in out.values() for o in v)))
