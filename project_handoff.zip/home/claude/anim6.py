import json, math, sys, os, shutil
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
INFO=json.load(open('/home/claude/info.json'))
B='/home/claude/fonts_ttf/OpenSans-Bold.ttf'; R='/home/claude/fonts_ttf/OpenSans-Regular.ttf'
GREEN=(134,188,37); WHITE=(244,247,242); SOFT=(190,206,184); BG=(3,10,11)
S=3; P=16; LM=57; FPS=48; TS=0.70
def clamp(x): return max(0.0,min(1.0,x))
def eo3(p): return 1-(1-p)**4
def eio(p): return p*p*p*(p*(6*p-15)+10)
def sm(p): p=clamp(p); return p*p*(3-2*p)
class Tag3:
    def __init__(s,n,key):
        s.key=key; name,role,loc,client=INFO[n]
        fn=ImageFont.truetype(B,34*S); fi=ImageFont.truetype(R,23*S); fc=ImageFont.truetype(R,21*S)
        s.fonts=[fn,fi,fc]; s.cols=[WHITE,GREEN,SOFT]
        s.texts=[name,f'{role}  ·  {loc}',f'Client: {client}'] if role else [name,'','']
        d=ImageDraw.Draw(Image.new('RGBA',(10,10)))
        s.tw=max(d.textlength(t,font=f) for t,f in zip(s.texts,s.fonts)); s.hs=[sum(f.getmetrics()) for f in s.fonts]
        g1=7*S; g2=3*S
        if key=='N': s.bar=3*S; s.pad=18*S; vp=15*S; s.tx=s.bar+s.pad; s.W=int(s.tx+s.tw+s.pad); s.extra=70*S; top0=vp; s.Hpad=vp
        elif key=='G': s.bar=0; s.pad=22*S; vp=16*S; s.tx=s.pad; s.W=int(s.pad+s.tw+s.pad); s.extra=0; top0=vp; s.Hpad=vp
        else: s.bar=0; s.pad=0; vp=0; s.tx=0; s.W=int(s.tw); s.extra=0; top0=22*S; s.Hpad=0
        s.tops=[top0,top0+s.hs[0]+g1,top0+s.hs[0]+g1+s.hs[1]+g2]; s.H=int(s.tops[2]+s.hs[2]+s.Hpad)
        s.CX=LM*S; s.CY=P*S; s.CW=s.CX+s.W+s.extra+P*S; s.CH=s.H+2*s.CY
        s.layers=[]
        for t,f,c,h in zip(s.texts,s.fonts,s.cols,s.hs):
            im=Image.new('RGBA',(s.W,h),(0,0,0,0)); ImageDraw.Draw(im).text((s.tx,0),t,font=f,fill=c+(255,))
            if key in ('N','L'):   # soft dark shadow so the text never fights the footage
                big=Image.new('RGBA',(s.W+16*S,h+16*S),(0,0,0,0)); sh=Image.new('RGBA',big.size,(0,0,0,0)); ImageDraw.Draw(sh).text((s.tx+8*S,8*S+2*S),t,font=f,fill=(0,0,0,210))
                sh=sh.filter(ImageFilter.GaussianBlur(3.5*S)); big=Image.alpha_composite(big,sh); big.alpha_composite(im,(8*S,8*S)); im=big
            s.layers.append(im)
        s.off=8*S if key in ('N','L') else 0
        s.overlay_y=1080-48-s.H//S-P
        if key=='N': s.scrim=s._scrim()
        if key=='G': s.glass=s._glass()
    def _scrim(s):
        w=s.W+s.extra; h=s.H; xs=np.linspace(0,1,w)[None,:]; ys=np.arange(h)[:,None]; f=20*S
        a=0.80*(1-xs)**1.5; v=np.minimum(np.minimum(ys/f,(h-ys)/f),1.0); v=v*v*(3-2*v)
        al=(a*v*255).clip(0,255).astype(np.uint8); arr=np.zeros((h,w,4),np.uint8); arr[...,0],arr[...,1],arr[...,2]=BG; arr[...,3]=al
        return Image.fromarray(arr,'RGBA')
    def _glass(s):
        im=Image.new('RGBA',(s.W,s.H),(0,0,0,0)); d=ImageDraw.Draw(im); r=10*S
        d.rounded_rectangle([0,0,s.W-1,s.H-1],radius=r,fill=(4,14,16,168))
        # hairline border: brighter green at the top-left corner, fading around
        bd=Image.new('RGBA',(s.W,s.H),(0,0,0,0)); ImageDraw.Draw(bd).rounded_rectangle([0,0,s.W-1,s.H-1],radius=r,outline=GREEN+(90,),width=max(1,S))
        im.alpha_composite(bd); return im
    def put(s,base,layer,x,y,alpha,clip):
        if alpha<=0: return
        l=layer.copy()
        if alpha<1: l.putalpha(l.getchannel('A').point(lambda v:int(v*alpha)))
        tmp=Image.new('RGBA',base.size,(0,0,0,0)); tmp.paste(l,(int(x),int(y)))
        m=Image.new('L',base.size,0); ImageDraw.Draw(m).rectangle([int(clip[0]),int(clip[1]),int(clip[2])-1,int(clip[3])-1],fill=255)
        tmp.putalpha(Image.composite(tmp.getchannel('A'),Image.new('L',base.size,0),m)); base.alpha_composite(tmp)
    def glow(s,base,draw_fn,radius,strength):
        g=Image.new('RGBA',base.size,(0,0,0,0)); draw_fn(ImageDraw.Draw(g)); g=g.filter(ImageFilter.GaussianBlur(radius*S))
        g.putalpha(g.getchannel('A').point(lambda v:int(min(255,v*strength)))); base.alpha_composite(g)
    def frame(s,tv): return {'N':s.fN,'G':s.fG,'L':s.fL}[s.key](tv/TS)
    def tclip(s,i,x1,x0=None): return ((s.CX if x0 is None else x0),s.CY+s.tops[i]-4*S,x1,s.CY+s.tops[i]+s.hs[i]+4*S)
    # ---- N: gradient scrim that melts into the background + glowing green line
    def fN(s,tv):
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0)); bp=eo3(clamp(tv/0.35)); bh=int(s.H*bp)
        if bh<=0: return base
        y0=s.CY+(s.H-bh)//2; y1=y0+bh; gp=eo3(clamp((tv-0.15)/0.60)); rw=int((s.W+s.extra)*gp)
        if rw>0: s.put(base,s.scrim,s.CX,s.CY,1,(s.CX,y0,s.CX+rw,y1))
        s.glow(base,lambda d:d.rectangle([s.CX,y0,s.CX+s.bar-1,y1-1],fill=GREEN+(255,)),7,1.4)
        ImageDraw.Draw(base).rectangle([s.CX,y0,s.CX+s.bar-1,y1-1],fill=GREEN+(255,))
        for i,dl in enumerate((0.45,0.60,0.75)):
            p=eo3(clamp((tv-dl)/0.40)); s.put(base,s.layers[i],s.CX-s.off,s.CY+s.tops[i]-s.off+(1-p)*s.hs[i],p,s.tclip(i,s.CX+s.bar+rw,s.CX+s.bar))
        return base
    # ---- G: smoked-glass card, green hairline, rises and fades in
    def fG(s,tv):
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0)); pa=eo3(clamp(tv/0.5))
        if pa<=0: return base
        dy=(1-pa)*14*S; lay=Image.new('RGBA',base.size,(0,0,0,0))
        sh=Image.new('L',base.size,0); ImageDraw.Draw(sh).rounded_rectangle([s.CX,s.CY+3*S,s.CX+s.W,s.CY+s.H+3*S],radius=10*S,fill=int(110*pa)); sh=sh.filter(ImageFilter.GaussianBlur(7*S))
        blk=Image.new('RGBA',base.size,(0,0,0,255)); blk.putalpha(sh); lay.alpha_composite(blk)
        gl=s.glass.copy(); gl.putalpha(gl.getchannel('A').point(lambda v:int(v*pa))); lay.alpha_composite(gl,(s.CX,s.CY))
        ap=eo3(clamp((tv-0.25)/0.45)); aw=int(48*S*ap)
        if aw>0:
            s.glow(lay,lambda d:d.rectangle([s.CX+16*S,s.CY,s.CX+16*S+aw,s.CY+2*S],fill=GREEN+(255,)),4,1.2)
            ImageDraw.Draw(lay).rectangle([s.CX+16*S,s.CY-1*S,s.CX+16*S+aw,s.CY+2*S-1],fill=GREEN+(255,))
        for i,dl in enumerate((0.35,0.48,0.61)):
            p=eo3(clamp((tv-dl)/0.35)); s.put(lay,s.layers[i],s.CX,s.CY+s.tops[i]+(1-p)*6*S,p,(0,0,s.CW,s.CH))
        base.paste(lay,(0,int(dy)),lay); return base
    # ---- L: a glowing node (like the network art) with a line that draws out; text sits straight on the footage
    def fL(s,tv):
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0)); np_=eo3(clamp(tv/0.25)); r=int(5*S*np_)
        cx,cy=s.CX+6*S,s.CY+7*S
        if r>0:
            s.glow(base,lambda d:d.ellipse([cx-r*2,cy-r*2,cx+r*2,cy+r*2],fill=GREEN+(255,)),6,1.6)
            ImageDraw.Draw(base).ellipse([cx-r,cy-r,cx+r,cy+r],fill=GREEN+(255,))
        lp=eio(clamp((tv-0.15)/0.50)); x0=cx+10*S; lw=int((s.CX+s.W-x0)*lp)
        if lw>0:
            s.glow(base,lambda d:d.rectangle([x0,cy-S,x0+lw,cy+S],fill=GREEN+(255,)),3,1.0)
            d=ImageDraw.Draw(base)
            for k in range(lw):   # line fades out toward its far end like the connecting curves in the artwork
                a=int(255*(1-0.85*(k/max(1,(s.CX+s.W-x0)))**1.2)); d.rectangle([x0+k,cy-S//2,x0+k,cy+S//2],fill=GREEN+(a,))
        for i,dl in enumerate((0.35,0.50,0.65)):
            p=eo3(clamp((tv-dl)/0.40)); s.put(base,s.layers[i],s.CX-s.off,s.CY+s.tops[i]-s.off+(1-p)*s.hs[i],p,(s.CX,s.CY+s.tops[i]-4*S,s.CX+s.W+8*S,s.CY+s.tops[i]+s.hs[i]+4*S))
        return base
LEN={'N':1.25*TS,'G':1.15*TS,'L':1.15*TS}
def vtime(t,t0,L,te):
    if t<t0: return 0.0
    if t<t0+L: return t-t0
    if te is None or t<te: return L
    if t<te+L*0.8: return L-(t-te)/0.8
    return 0.0
def render_seq(n,key,outdir,T,t0=0.6,te=None):
    tag=Tag3(n,key); L=LEN[key]
    shutil.rmtree(outdir,ignore_errors=True); os.makedirs(outdir)
    for k in range(int(math.ceil(T*FPS))):
        im=tag.frame(vtime(k/FPS,t0,L,te)); im.resize((im.width//S,im.height//S),Image.LANCZOS).save(f'{outdir}/{k:04d}.png')
    return tag.overlay_y
if __name__=='__main__':
    n=sys.argv[1]; T=float(sys.argv[2])
    for key in 'NGL': print(key,render_seq(n,key,f'/home/claude/anim/{n}_{key}4',T,t0=0.6,te=8.2))
