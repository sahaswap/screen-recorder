import json
D=0.25; FPSO=48
p=json.load(open('/home/claude/plans.json'))
BOX=json.load(open('/home/claude/det/boxes.json'))
UP='/mnt/user-data/uploads/'; OUT='/mnt/user-data/outputs/final_node_line/'
order=['Shobhita','Ananya','Riddhima','Malavikka','Ayush','Irin','Monesh','Mohammed','Arijit']
OY=877
lines=['#!/bin/sh','cd /home/claude']
for n in order:
    v=p[n]; segs=v['segs']; inputs=''; fc=''
    for i,(a,b) in enumerate(segs):
        inputs+=f' -ss {a:.4f} -t {b-a:.4f} -i "{UP}{v["file"]}"'
        fc+=f'[{i}:v]setpts=PTS-STARTPTS,fps={FPSO},format=yuv420p[v{i}];[{i}:a]asetpts=PTS-STARTPTS[a{i}];'
    K=len(segs)
    inputs+=f' -framerate {FPSO} -i "/home/claude/anim/{n}_L4/%04d.png"'
    T=segs[0][1]-segs[0][0]; cv='v0'; ca='a0'
    for i in range(1,len(segs)):
        L=segs[i][1]-segs[i][0]
        fc+=f'[{cv}][v{i}]xfade=transition=fade:duration={D}:offset={T-D:.4f}[x{i}];'
        fc+=f'[{ca}][a{i}]acrossfade=d={D}:c1=tri:c2=tri[c{i}];'
        cv=f'x{i}'; ca=f'c{i}'; T+=L-D
    bx=BOX[n]
    fc+=f'[{cv}]delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]}[dl];[dl][{K}:v]overlay=0:{OY}:eof_action=repeat:shortest=1[sub];'
    fc+=f'[sub]fade=t=in:st=0:d=0.25,fade=t=out:st={T-0.5:.4f}:d=0.5[vout];[{ca}]afade=t=in:st=0:d=0.25,afade=t=out:st={T-0.5:.4f}:d=0.5[aout]'
    name=v['file'].replace('.mp4','_final.mp4')
    if n=='Riddhima':
        enc=f'-c:v libx265 -preset fast -x265-params "crf=21:vbv-maxrate=2300:vbv-bufsize=4600:log-level=error" -tag:v hvc1 -c:a aac -b:a 96k'
    else:
        mr=int(min(1100, 24.0e6*8/T/1000-70))
        enc=f'-c:v libx264 -preset fast -crf 22 -maxrate {mr}k -bufsize {2*mr}k -profile:v high -c:a aac -b:a 64k'
    lines.append(f'echo START {n} >> progress_nl.log')
    lines.append(f'ffmpeg -y -nostdin -v error -stats{inputs} -filter_complex "{fc}" -map "[vout]" -map "[aout]" {enc} -r {FPSO} -pix_fmt yuv420p -movflags +faststart "{OUT}{name}" 2> logn2_{n}.txt')
    lines.append(f'echo END {n} rc=$? >> progress_nl.log')
lines.append('echo ALLDONE >> progress_nl.log')
open('/home/claude/run_nl.sh','w').write('\n'.join(lines)+'\n')
print('ok',round(sum(p[n]['out_len'] for n in order)),'s total output')
