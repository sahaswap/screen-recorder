import json,sys,subprocess,os,re,shutil
sys.path.insert(0,'/home/claude')
import numpy as np
from montage_lib import plans,seg_map,D
from spans_all import words,locate
from curated_spec import ROUNDS
from PIL import Image
BOX=json.load(open('/home/claude/det/boxes.json'))
ENC='-c:v libx264 -preset fast -crf 21 -profile:v high -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 -c:a aac -b:a 64k -ar 16000 -ac 1'
UP='/mnt/user-data/uploads/'; SPEED={'Riddhima':0.92}
SEL={0:['Mohammed','Riddhima','Shobhita','Ayush','Malavikka'],1:['Ananya','Irin','Riddhima','Arijit','Shobhita'],2:['Ananya','Malavikka','Irin','Riddhima'],
     3:['Arijit','Riddhima','Monesh','Irin'],4:['Irin','Mohammed','Ananya','Malavikka','Shobhita'],5:['Malavikka','Irin','Monesh'],6:['Arijit','Ayush','Ananya'],
     7:['Ananya','Mohammed','Ayush'],8:['Mohammed','Ayush','Arijit','Monesh','Shobhita'],9:['Ananya','Malavikka','Irin','Riddhima','Shobhita','Ayush','Mohammed','Monesh','Arijit']}
def aud(path,ss,dur):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',path,'-vn','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(r,np.int16).astype(float)/32768
def env_db(x,win=160): # 10 ms frames
    n=len(x)//win; return 20*np.log10(np.sqrt((x[:n*win].reshape(n,win)**2).mean(axis=1))+1e-6)
def orig_time(n,t):
    m=seg_map(n); best=None
    for i,(S,E,a) in enumerate(m):
        if S-1e-6<=t<=E+1e-6:
            if best is None or t>=S+D/2: best=(S,a)
    if best is None:   # outside every segment: clamp to nearest
        i=min(range(len(m)),key=lambda k:min(abs(t-m[k][0]),abs(t-m[k][1]))); best=(m[i][0],m[i][2])
    return best[1]+(t-best[0])
def refine_end(src,core_end,next_start):
    w=aud(src,core_end-2.0,2.0+1.8); sr=16000
    pre=env_db(w[:2*sr]); L=np.percentile(pre,90); T=L-20
    e=env_db(w[int((2.0-0.15)*sr):]); t0=core_end-0.15
    k=0
    while k<len(e)-12:
        if (e[k:k+12]<T).all(): end=t0+k*0.01+0.20; break
        k+=1
    else: end=core_end+0.35
    end=max(end,core_end+0.15)
    if next_start is not None: end=min(end,next_start-0.05)
    return end
def vol(src,ss,dur,key):
    r=subprocess.run(['ffmpeg','-nostdin','-v','info','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-af','volumedetect','-f','null','-'],capture_output=True,text=True).stderr
    m=re.search(key+r': (-?[\d.]+) dB',r); return float(m.group(1)) if m else -91.0
def pad_short(src,ss,dur,minlen):
    for T in (minlen,minlen-0.2,minlen-0.4):
        for l in (0.0,0.4,0.8,1.2):
            s2=ss-l; tail=s2+T-(ss+dur)
            if l>0.05 and vol(src,s2,l,'max_volume')>=-32: continue
            if tail>0.05 and vol(src,ss+dur,tail,'max_volume')>=-32: continue
            return s2,T
    return ss,dur
def make_seq(n,cid,dur):
    N=int(round(dur*48)); d=f'/home/claude/mont/seq/{cid}'; os.makedirs(d,exist_ok=True)
    c=f'/home/claude/mont/cache/{n}'; blank=f'/home/claude/mont/cache/blank_{n}_full.png'
    n_in=54; n_ex=31; ex=max(n_in,N-46) if N>=100 else N+99; off=12 if N<130 else 0
    for k in range(N):
        if k<n_in-off: t=f'{c}/in_{k+off:04d}.png'
        elif k>=ex+n_ex: t=blank
        elif k>=ex: t=f'{c}/out_{k-ex:04d}.png'
        else: t=f'{c}/hold.png'
        lk=f'{d}/{k:04d}.png'
        if os.path.lexists(lk): os.remove(lk)
        os.symlink(t,lk)
    return d
shutil.rmtree('/home/claude/mont/seq',ignore_errors=True); os.makedirs('/home/claude/mont/cut2',exist_ok=True)
for f in os.listdir('/home/claude/mont/cut2'): os.remove('/home/claude/mont/cut2/'+f)
sh=['cd /home/claude','rm -f mont/cut2_build.log']; files=[]; info=[]
def add(cmd): sh.append(cmd+' && echo ok >> mont/cut2_build.log || echo FAIL >> mont/cut2_build.log')
idx=0; notes_sq=[]
for ri,(label,q,lines) in enumerate(ROUNDS):
    tf=f'/home/claude/mont/cut2/{ri:02d}_title.mp4'
    add(f'ffmpeg -y -nostdin -v error -framerate 48 -i /home/claude/mont/ctitle_{ri}/%04d.png -f lavfi -i anullsrc=r=16000:cl=mono -t 2.4 -vf "fade=t=out:st=2.2:d=0.2,format=yuv420p" {ENC} -shortest {tf}')
    files.append(tf); seen=set()
    for (n,sp,ep) in lines:
        if n not in SEL[ri]: continue
        if (n in seen) and not (ri==3 and n=='Monesh'): continue
        seen.add(n)
        ws=words(n); a,_=locate(ws,sp); _,b=locate(ws,ep,a)
        k=b
        while not re.search(r'[.?!:]["\u201d\']?$',ws[k][0]) and k+1<len(ws) and ws[k+1][1]-ws[k][2]<0.7 and k-b<30: k+=1
        if k>b and re.search(r'[.?!:]["\u201d\']?$',ws[k][0]) and ws[k][2]-ws[b][2]<=2.6: b=k
        src=UP+plans[n]['file']
        ws0=orig_time(n,ws[a][1]); we=orig_time(n,ws[b][2])
        prev_end=orig_time(n,ws[a-1][2]) if a>0 else None; nxt=orig_time(n,ws[b+1][1]) if b+1<len(ws) else None
        sq=None
        for k in range(a,b):
            g0=orig_time(n,ws[k][2]); g1=orig_time(n,ws[k+1][1])
            if g1-g0>1.5: sq=(g0,g1)
        lead=0.25 if prev_end is None else max(0.05,min(0.25,ws0-prev_end-0.04))
        ss=ws0-lead; end=refine_end(src,we,nxt); dur=end-ss
        sp_=SPEED.get(n,1.0); minlen=2.6
        if dur/sp_<minlen:
            ss,dur=pad_short(src,ss,dur,minlen*sp_)
        dur_eff=dur-(sq[1]-sq[0])+0.45 if sq else dur
        out_dur=dur_eff/sp_; idx+=1
        bx=BOX[n]; mean=vol(src,ss,dur,'mean_volume'); gain=max(-12,min(15,-18.5-mean))
        seq=make_seq(n,f'c{idx:02d}_{n}',out_dur)
        tail_v=(f'setpts=PTS/{sp_},fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:877:shortest=1,fade=t=in:st=0:d=0.08,fade=t=out:st={out_dur-0.10:.3f}:d=0.10[v]')
        tail_a=(f'volume={gain:.2f}dB,alimiter=limit=0.89,afade=t=in:st=0:d=0.06,afade=t=out:st={out_dur-0.12:.3f}:d=0.12[a]')
        sp_f=(f'atempo={sp_},' if sp_!=1.0 else '')
        if sq:
            p1=(sq[0]-ss)+0.35; p2=(sq[1]-ss)-0.25
            vf=(f'[0:v]split=2[s0][s1];[s0]trim=0:{p1:.3f},setpts=PTS-STARTPTS[va];[s1]trim={p2:.3f}:{dur:.3f},setpts=PTS-STARTPTS[vb];[va][vb]xfade=transition=fade:duration=0.15:offset={p1-0.15:.3f}[vs];[vs]'+tail_v)
            af=(f'[0:a]aresample=16000,aformat=channel_layouts=mono,asplit=2[b0][b1];[b0]atrim=0:{p1:.3f},asetpts=PTS-STARTPTS[aa];[b1]atrim={p2:.3f}:{dur:.3f},asetpts=PTS-STARTPTS[ab];[aa][ab]acrossfade=d=0.15,'+sp_f+tail_a)
            notes_sq.append((idx,n,round(sq[1]-sq[0],2)))
        else:
            vf='[0:v]'+tail_v
            af='[0:a]aresample=16000,aformat=channel_layouts=mono,'+sp_f+tail_a
        out=f'/home/claude/mont/cut2/{idx:02d}_{n}.mp4'
        add(f'ffmpeg -y -nostdin -v error -ss {ss:.3f} -t {dur:.3f} -i "{src}" -framerate 48 -i {seq}/%04d.png -filter_complex "{vf};{af}" -map "[v]" -map "[a]" -t {out_dur:.3f} {ENC} {out}')
        files.append(out); info.append(dict(i=idx,round=ri,n=n,ss=round(ss,3),dur=round(dur,3),out=round(out_dur,3),text=' '.join(w[0] for w in ws[a:b+1]),src=src,speed=sp_))
open('/home/claude/mont/list_cut2.txt','w').write(''.join(f"file '{f}'\n" for f in files))
json.dump(info,open('/home/claude/cut2_info.json','w'))
sh.append('echo ALLDONE >> mont/cut2_build.log'); open('/home/claude/mont/cut2_build.sh','w').write('\n'.join(sh)+'\n')
print('pauses squeezed:',notes_sq); print(len(files),'files;',idx,'clips; total clip seconds',round(sum(x['out'] for x in info),1))
