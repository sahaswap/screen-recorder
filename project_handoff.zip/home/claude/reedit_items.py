import sys,json,os,shutil,subprocess
sys.path.insert(0,'/home/claude')
from reedit_lib import *
ROOT='/home/claude/mont/re'; shutil.rmtree(ROOT,ignore_errors=True); os.makedirs(ROOT+'/items'); os.makedirs(ROOT+'/seq')
def S(n,sp,ep,**o): return ('single',n,sp,ep,o)
def SP(mode,A,B,kw=None): return ('split',mode,A,B,kw)
def C(n,sp,ep,**o): return (n,sp,ep,o)
SECTIONS=[
 (1,[S('Malavikka','quiet caring','ambitious'),S('Mohammed','I am curious proactive','adaptable'),S('Riddhima','I am curious thoughtful','dependable'),
     S('Shobhita','ambitious adaptable','curious'),S('Ayush','curious adventurous','challenges')]),
 (2,[S('Shobhita','networking and building meaningful connections','unexpected situations'),S('Ananya','I can read minds','read minds'),
     S('Irin','making Excel do magic','do magic'),S('Riddhima','I can still guess the song title','notes of the song'),
     S('Arijit','good at cooking and I like to cook Italian','made the best',buf=2.0)]),
 (3,[S('Ananya','I would proudly say','and drawing',buf=1.5),S('Malavikka',"I'd say dancing",'good to go'),
     S('Riddhima','very efficient at packing','able to do that',buf=1.5),S('Monesh','experience has taught me how to connect dots','minimal preparation',buf=1.5)]),
 (4,[S('Irin','If I say I will do it',"I'll do it"),S('Arijit','terrified about spiders','bit fun'),S('Riddhima',"I'm always up to learn something new",'feeling down'),
     S('Monesh',"I'm a fun person to work with",'work with'),S('Monesh','I always get my deliverables done','hook or crook')]),
 (5,[S('Irin','Did you fill your timesheet','timesheet'),S('Mohammed','networking networking and more networking','official Deloitte skill'),
     S('Ananya','that quick connect never ends','so quickly'),S('Malavikka',"let's connect",'quite a lot'),S('Shobhita',"The phrase that I've heard the most",'in Deloitte',buf=1.5)]),
 (6,[SP('chorus',C('Malavikka',"I think it's dynamic",'dynamic'),C('Mohammed','I would say my project is dynamic','figure out'),kw='dynamic'),
     SP('sequential',C('Irin','My project in one word','detectives'),C('Ananya','If I had to describe my work','something to investigate')),
     SP('sequential',C('Ayush','Intriguing','Intriguing'),C('Riddhima','to describe my project in one word','interesting and unique',buf=1.5)),
     S('Arijit',"I would say it's awesome",'awesome'),S('Monesh','I would also call the project','expect the unexpected'),S('Shobhita','the term disconnect','offline from others')]),
 (7,[S('Arijit','Is the disconnect that I am looking forward','to the most'),S('Ayush','Meeting new people','great memories'),S('Monesh',"I'm excited to learn more",'energetic crowd',buf=1.5)]),
 (8,[S('Ananya','so many passwords','remember them all'),S('Mohammed','how welcoming','easier for me'),S('Ayush','how many people are genuinely willing','settle in')]),
 (9,[S('Malavikka','one word to describe my new team is supportive','very supportive',buf=1.5),
     SP('chorus',C('Mohammed','I would say welcoming','welcoming'),C('Ayush','Welcoming','Welcoming'),kw='welcoming'),
     S('Arijit','that I used synergistic','completely synergistic'),S('Monesh','financial superheroes','terrorist financing',buf=1.5)]),
 (10,[SP('sequential',C('Ananya','Love You Zindagi','goes with my life'),C('Malavikka','Love You Zindagi','my vibe pretty well')),
     S('Irin','My theme song would be 7 Rings by Ariana','7 Rings by Ariana',buf=1.5),S('Riddhima','Wake Up Sid',"hustle I'm facing",buf=1.5,complete=False),
     S('Shobhita',"Shin Chan's theme song",'get things done',buf=1.5),S('Ayush','The Nights by Avicii','gets better'),
     S('Mohammed','Shoe Dog by phil knight','from ground up',buf=1.5),S('Monesh','life is like Kabhi Khushi Kabhie Gham','ups and downs'),
     S("Arijit","Don't Stop Me Now by Queen",'by Queen',buf=1.5)]),
]
TAILS=['-framerate 48']; idx=0; cmds=[]; manifest=[]; notes=[]
def addcmd(c,out): cmds.append(c+f' && echo ok >> {ROOT}/items.log || echo FAIL {out} >> {ROOT}/items.log')
def make_clip(spec):
    n,sp,ep,o=spec; c=clip_def(n,sp,ep,complete=o.get('complete',True)); add_buffer(c,o.get('buf',0.0)); c['opts']=o; return c
def single(i,spec):
    c=make_clip(spec[1:5] if spec[0]=='single' else spec); n=c['n']; out_dur=clip_len(c); gain=gain_for(c); seg=c['real_end']-c['ss']
    seq=make_seq(n,f'i{i:02d}_{n}',out_dur); bx=BOX[n]
    v0=('[0:v]'+squeeze_video(c)+'[vs];[vs]') if c['sq'] else '[0:v]'
    tp=f'tpad=stop_mode=clone:stop_duration={c["freeze"]:.3f},' if c['freeze']>0.01 else ''
    vf=f'{v0}{tp}fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:877:shortest=1[v]'
    af='[0:a]aresample=16000,aformat=channel_layouts=mono,'+v_audio_chain(c,out_dur,gain)+'[a]'
    out=f'{ROOT}/items/{i:02d}_{n}.mp4'
    addcmd(f'ffmpeg -y -nostdin -v error -ss {c["ss"]:.3f} -t {seg:.3f} -i "{c["src"]}" -framerate 48 -i {seq}/%04d.png -filter_complex "{vf};{af}" -map "[v]" -map "[a]" -t {out_dur:.3f} {ENC_I} {out}',out)
    notes.append(f'  {n:9} {out_dur:5.1f}s buffer={c["opts"].get("buf",0)} (real footage {c["real_end"]-c["end"]:.1f}s + held frame {c["freeze"]:.1f}s) | {c["text"][:60]}')
    return out,out_dur
def logo_png():
    p='/home/claude/mont/re/logo.png'
    if not os.path.exists(p):
        im=Image.open('/home/claude/det/Arijit_Sarkar.png').convert('RGB').crop((40,25,300,125)); a=np.array(im).astype(float)
        al=np.clip((a.max(axis=2)-45)/90,0,1)*255; rgba=np.dstack([a,al]).astype(np.uint8); Image.fromarray(rgba,'RGBA').save(p)
    return p
def split(i,spec):
    _,mode,A,B,kw=spec; cA=make_clip(A); cB=make_clip(B); lenA=clip_len(cA); lenB=clip_len(cB); XT=0.25
    segA=cA['real_end']-cA['ss']; segB=cB['real_end']-cB['ss']; inputs=[]; fc=[]
    def addin(s): inputs.append(s); return len(inputs)-1
    iA=addin(f'-ss {cA["ss"]:.3f} -t {segA:.3f} -i "{cA["src"]}"'); iB=addin(f'-ss {cB["ss"]:.3f} -t {segB:.3f} -i "{cB["src"]}"')
    if mode=='sequential':
        sA=0.0; sB=lenA+0.15; T=sB+lenB; preA=None; preB=('listen',sB+XT); postA=('listen',T-lenA+XT); postB=None; dimB=True
    else:
        lA=keyword_time(cA,kw)-cA['ss']; lB=keyword_time(cB,kw)-cB['ss']; sA=max(0.0,lB-lA); sB=max(0.0,lA-lB)
        T=max(sA+lenA,sB+lenB); preA=('hold',sA) if sA>0.01 else None; preB=('hold',sB) if sB>0.01 else None
        rA=T-(sA+lenA); rB=T-(sB+lenB); postA=('listen',rA+XT) if rA>0.8 else (('hold',rA) if rA>0.01 else None); postB=('listen',rB+XT) if rB>0.8 else (('hold',rB) if rB>0.01 else None); dimB=False
    def tile(name,c,iclip,seg,clen,pre,post,start,dim):
        cl=f'[{iclip}:v]'+(f'tpad=stop_mode=clone:stop_duration={c["freeze"]:.3f},' if c['freeze']>0.01 else '')+f'fps=16,crop=960:1080:480:0,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[{name}c];'
        cur=f'{name}c'; curlen=clen; res=cl
        def lis(need):
            ls,avail=find_listen(c['n'],need)
            if ls is None: return None
            k=addin(f'-ss {ls:.3f} -t {min(need,avail)+0.05:.3f} -i "{c["src"]}"'); got=min(need,avail)
            extra=max(0.0,need-got)
            return k,extra
        if pre and pre[0]=='hold': res+=f'[{cur}]tpad=start_mode=clone:start_duration={pre[1]:.3f}[{name}p];'; cur=f'{name}p'; curlen+=pre[1]
        elif pre and pre[0]=='listen':
            r=lis(pre[1])
            if r:
                k,extra=r; res+=f'[{k}:v]'+(f'tpad=stop_mode=clone:stop_duration={extra:.3f},' if extra>0.01 else '')+f'fps=16,crop=960:1080:480:0,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[{name}l0];'
                res+=f'[{name}l0][{cur}]xfade=transition=fade:duration={XT}:offset={pre[1]-XT:.3f}[{name}p];'; cur=f'{name}p'; curlen=pre[1]+curlen-XT
            else: res+=f'[{cur}]tpad=start_mode=clone:start_duration={pre[1]-XT:.3f}[{name}p];'; cur=f'{name}p'; curlen+=pre[1]-XT
        if post and post[0]=='hold': res+=f'[{cur}]tpad=stop_mode=clone:stop_duration={post[1]:.3f}[{name}q];'; cur=f'{name}q'; curlen+=post[1]
        elif post and post[0]=='listen':
            r=lis(post[1])
            if r:
                k,extra=r; res+=f'[{k}:v]'+(f'tpad=stop_mode=clone:stop_duration={extra:.3f},' if extra>0.01 else '')+f'fps=16,crop=960:1080:480:0,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[{name}l1];'
                res+=f'[{cur}][{name}l1]xfade=transition=fade:duration={XT}:offset={curlen-XT:.3f}[{name}q];'; cur=f'{name}q'; curlen=curlen+post[1]-XT
            else: res+=f'[{cur}]tpad=stop_mode=clone:stop_duration={post[1]-XT:.3f}[{name}q];'; cur=f'{name}q'; curlen+=post[1]-XT
        res+=f'[{cur}]trim=duration={T:.3f},setpts=PTS-STARTPTS'
        res+=dim+f'[{name}];'
        return res
    dimA=''; dimBx=''
    if mode=='sequential':
        dimA=f",eq=brightness='-0.30*clip((t-({sB}-0.1))/0.25,0,1)':eval=frame"; dimBx=f",eq=brightness='-0.30*(1-clip((t-({sB}-0.1))/0.25,0,1))':eval=frame"
    fc.append(tile('ta',cA,iA,segA,lenA,preA,postA,sA,dimA)); fc.append(tile('tb',cB,iB,segB,lenB,preB,postB,sB,dimBx))
    seqA=make_seq(cA['n'],f'i{i:02d}_{cA["n"]}_L',T); seqB=make_seq(cB['n'],f'i{i:02d}_{cB["n"]}_R',T)
    kA=addin(f'-framerate 48 -i {seqA}/%04d.png'); kB=addin(f'-framerate 48 -i {seqB}/%04d.png'); kL=addin(f'-loop 1 -framerate 48 -i {logo_png()}')
    fc.append(f'[ta][tb]hstack=inputs=2,fps=48,drawbox=x=958:y=0:w=4:h=1080:color=0x86BC25@0.35:t=fill[st];[{kA}:v]format=rgba[tgA];[{kB}:v]format=rgba[tgB];[{kL}:v]format=rgba[lg];[st][tgA]overlay=0:877:shortest=1[o1];[o1][tgB]overlay=960:877:shortest=1[o2];[o2][lg]overlay=40:25:shortest=1,format=yuv420p[v];')
    gA=gain_for(cA); gB=gain_for(cB); extra=-3 if mode=='chorus' else 0
    fc.append(f'[{iA}:a]aresample=16000,aformat=channel_layouts=mono,'+v_audio_chain(cA,lenA,gA+extra)+f',adelay={int(sA*1000)}:all=1,apad=whole_dur={T:.3f}[aA];')
    fc.append(f'[{iB}:a]aresample=16000,aformat=channel_layouts=mono,'+v_audio_chain(cB,lenB,gB+extra)+f',adelay={int(sB*1000)}:all=1,apad=whole_dur={T:.3f}[aB];')
    fc.append(f'[aA][aB]amix=inputs=2:normalize=0:duration=longest,atrim=0:{T:.3f}[a]')
    out=f'{ROOT}/items/{i:02d}_{cA["n"]}+{cB["n"]}.mp4'
    addcmd('ffmpeg -y -nostdin -v error '+' '.join(inputs)+f' -filter_complex "{"".join(fc)}" -map "[v]" -map "[a]" -t {T:.3f} {ENC_I} {out}',out)
    notes.append(f'  SPLIT {mode:10} {cA["n"]}+{cB["n"]} {T:5.1f}s | {cA["text"][:30]} / {cB["text"][:30]}')
    return out,T
sections_out=[]
for (q,items) in SECTIONS:
    row=[]
    notes.append(f'Q{q}:')
    for spec in items:
        idx+=1
        row.append(single(idx,spec) if spec[0]=='single' else split(idx,spec))
    sections_out.append((q,row))
json.dump(dict(sections=[(q,[(o,d) for o,d in row]) for q,row in sections_out]),open(ROOT+'/manifest.json','w'))
open(ROOT+'/items.sh','w').write('#!/bin/sh\ncd /home/claude\nrm -f '+ROOT+'/items.log\n'+'\n'.join(cmds)+f'\necho ALLDONE >> {ROOT}/items.log\n')
print('\n'.join(notes)); print(idx,'items;',sum(d for q,r in sections_out for o,d in r),'s of item footage')
