import sys,math,os,shutil
sys.argv=['x']
exec(open('/home/claude/anim5.py').read().split("if __name__")[0])
import numpy as np
W,H=1920,1080; FPSO=48
def make_title(qno,qtot,text,outdir,T=2.8):
    shutil.rmtree(outdir,ignore_errors=True); os.makedirs(outdir)
    # background in the video's own palette: near-black with a soft green/teal glow on the right
    yy,xx=np.mgrid[0:H,0:W]; r=np.sqrt(((xx-1450)/900.0)**2+((yy-380)/700.0)**2); g=np.clip(1-r,0,1)**2
    base=np.zeros((H,W,3),np.float32); base[...]=(3,9,10)
    base+=g[...,None]*np.array([10,34,28],np.float32)
    bg=Image.fromarray(base.clip(0,255).astype(np.uint8)).convert('RGBA')
    fl=ImageFont.truetype(B,26*S); fq=ImageFont.truetype(B,70*S)
    X=160*S; Y=360*S
    # wrap question
    d=ImageDraw.Draw(Image.new('RGBA',(10,10))); words=text.split(); lines=[]; cur=''
    for w in words:
        t=(cur+' '+w).strip()
        if d.textlength(t,font=fq)>1250*S and cur: lines.append(cur); cur=w
        else: cur=t
    lines.append(cur)
    label=f'QUESTION {qno:02d}  /  {qtot:02d}'
    lw=sum(d.textlength(c,font=fl)+3*S for c in label)
    lab=Image.new('RGBA',(int(lw)+10,fl.getmetrics()[0]+fl.getmetrics()[1]+8*S),(0,0,0,0)); ld=ImageDraw.Draw(lab); x=0
    for c in label: ld.text((x,0),c,font=fl,fill=GREEN+(255,)); x+=d.textlength(c,font=fl)+3*S
    qh=sum(fq.getmetrics()); qlayers=[]
    for ln in lines:
        im=Image.new('RGBA',(int(d.textlength(ln,font=fq))+20*S,qh),(0,0,0,0)); ImageDraw.Draw(im).text((0,0),ln,font=fq,fill=WHITE+(255,)); qlayers.append(im)
    N=int(T*FPSO)
    for k in range(N):
        t=k/FPSO; lay=Image.new('RGBA',(W*S,H*S),(0,0,0,0))
        # label
        p=eo3(clamp((t-0.15)/0.5)); 
        if p>0:
            l2=lab.copy(); l2.putalpha(l2.getchannel('A').point(lambda v:int(v*p))); lay.alpha_composite(l2,(X,int(Y-70*S+(1-p)*10*S)))
        # node + line (like the tags)
        cx,cy=X+6*S,Y-18*S; np_=eo3(clamp((t-0.25)/0.3)); r_=int(7*S*np_)
        if r_>0:
            gl=Image.new('RGBA',lay.size,(0,0,0,0)); ImageDraw.Draw(gl).ellipse([cx-r_*2,cy-r_*2,cx+r_*2,cy+r_*2],fill=GREEN+(255,)); gl=gl.filter(ImageFilter.GaussianBlur(8*S)); lay.alpha_composite(gl)
            ImageDraw.Draw(lay).ellipse([cx-r_,cy-r_,cx+r_,cy+r_],fill=GREEN+(255,))
        lp=eio(clamp((t-0.4)/0.7)); lwid=int(700*S*lp); dd=ImageDraw.Draw(lay)
        for q in range(0,lwid,2): dd.rectangle([cx+16*S+q,cy-S,cx+16*S+q+1,cy+S],fill=GREEN+(int(255*(1-0.9*(q/(700*S)))),))
        # question text: rises out of a mask line by line
        for i,im in enumerate(qlayers):
            pp=eo3(clamp((t-0.6-0.14*i)/0.6)); y=Y+i*(qh+8*S)
            if pp>0:
                tmp=Image.new('RGBA',lay.size,(0,0,0,0)); l3=im.copy(); l3.putalpha(l3.getchannel('A').point(lambda v:int(v*pp))); tmp.alpha_composite(l3,(X,int(y+(1-pp)*qh)))
                m=Image.new('L',lay.size,0); ImageDraw.Draw(m).rectangle([X-4*S,y-4*S,X+im.width,y+qh+4*S],fill=255); tmp.putalpha(Image.composite(tmp.getchannel('A'),Image.new('L',lay.size,0),m)); lay.alpha_composite(tmp)
        lay=lay.resize((W,H),Image.LANCZOS); fr=bg.copy(); fr.alpha_composite(lay); fr.convert('RGB').save(f'{outdir}/{k:04d}.png')
    return N
if __name__=='__main__':
    print(make_title(1,11,'Introduce yourself in 3 words','/home/claude/mont/title_q1'),'title frames')
