import json,sys,subprocess,os
sys.path.insert(0,'/home/claude')
from montage_lib import *
BOX=json.load(open('/home/claude/det/boxes.json'))
spans=json.load(open('/home/claude/q1_spans.json'))
ENC='-c:v libx264 -preset fast -crf 21 -profile:v high -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 -c:a aac -b:a 64k -ar 16000 -ac 1'
cmds=[]; files=[]
# title card (silent)
cmds.append(f'ffmpeg -y -nostdin -v error -framerate 48 -i /home/claude/mont/title_q1/%04d.png -f lavfi -i anullsrc=r=16000:cl=mono -t 2.8 -vf "fade=t=out:st=2.55:d=0.25,format=yuv420p" {ENC} -shortest /home/claude/mont/clips/00_title.mp4')
files.append('/home/claude/mont/clips/00_title.mp4')
for i,o in enumerate(spans,1):
    n=o['n']; ln=o['e']-o['s']; bx=BOX[n]
    if o['kind']=='orig': src='/mnt/user-data/uploads/'+plans[n]['file']; ss=o['so']
    else: src=f'/mnt/user-data/outputs/softcut/{NAMES[n]}_softcut.mp4'; ss=o['s']+SHIFT.get(n,0)
    vf=(f'[0:v]fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:877:shortest=1,'
        f'fade=t=in:st=0:d=0.12,fade=t=out:st={ln-0.12:.3f}:d=0.12[v]')
    af=(f'[0:a]aresample=16000,aformat=channel_layouts=mono,loudnorm=I=-17:TP=-2:LRA=7,'
        f'afade=t=in:st=0:d=0.10,afade=t=out:st={ln-0.14:.3f}:d=0.14[a]')
    out=f'/home/claude/mont/clips/{i:02d}_{n}.mp4'
    cmds.append(f'ffmpeg -y -nostdin -v error -ss {ss:.3f} -t {ln:.3f} -i "{src}" -framerate 48 -i /home/claude/mont/tag_{n}/%04d.png -filter_complex "{vf};{af}" -map "[v]" -map "[a]" -t {ln:.3f} {ENC} {out}')
    files.append(out)
open('/home/claude/mont/list.txt','w').write(''.join(f"file '{f}'\n" for f in files))
sh=['cd /home/claude','rm -f mont/build.log']
for c in cmds: sh.append(c+' && echo ok >> mont/build.log || echo FAIL >> mont/build.log')
sh.append("ffmpeg -y -nostdin -v error -f concat -safe 0 -i mont/list.txt -c copy -movflags +faststart /mnt/user-data/outputs/montage_demo/Q01_Introduce_yourself_in_3_words.mp4 && echo CONCAT_OK >> mont/build.log")
open('/home/claude/mont/build.sh','w').write('\n'.join(sh)+'\n'); print(len(cmds),'clips queued')
