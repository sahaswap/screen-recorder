import json,re,subprocess,os,sys,shutil
import numpy as np
sys.path.insert(0,'/home/claude')
from montage_lib import plans,seg_map,D as PLAN_D
from spans_all import words,locate
from PIL import Image
UP='/mnt/user-data/uploads/'; BOX=json.load(open('/home/claude/det/boxes.json'))
ENC_I='-c:v libx264 -preset fast -crf 16 -profile:v high -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 -c:a aac -b:a 128k -ar 16000 -ac 1'
XD=0.30      # dissolve length between clips
def aud(path,ss,dur):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',path,'-vn','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(r,np.int16).astype(float)/32768
def env_db(x,win=160):
    n=len(x)//win; return 20*np.log10(np.sqrt((x[:n*win].reshape(n,win)**2).mean(axis=1))+1e-6)
def vol(src,ss,dur,key):
    r=subprocess.run(['ffmpeg','-nostdin','-v','info','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-af','volumedetect','-f','null','-'],capture_output=True,text=True).stderr
    m=re.search(key+r': (-?[\d.]+) dB',r); return float(m.group(1)) if m else -91.0
def orig_time(n,t):
    m=seg_map(n); best=None
    for i,(S,E,a) in enumerate(m):
        if S-1e-6<=t<=E+1e-6 and (best is None or t>=S+PLAN_D/2): best=(S,a)
    if best is None:
        i=min(range(len(m)),key=lambda k:min(abs(t-m[k][0]),abs(t-m[k][1]))); best=(m[i][0],m[i][2])
    return best[1]+(t-best[0])
def refine_end(src,core_end,next_start):
    w=aud(src,core_end-2.0,3.8); sr=16000
    L=np.percentile(env_db(w[:2*sr]),90); T=L-20
    e=env_db(w[int((2.0-0.15)*sr):]); t0=core_end-0.15; k=0
    while k<len(e)-12:
        if (e[k:k+12]<T).all(): end=t0+k*0.01+0.20; break
        k+=1
    else: end=core_end+0.35
    end=max(end,core_end+0.15)
    if next_start is not None: end=min(end,next_start-0.05)
    return end
def clip_def(n,sp,ep,complete=True):
    ws=words(n); a,_=locate(ws,sp); _,b=locate(ws,ep,a)
    if complete:
        k=b
        while not re.search(r'[.?!:]["\u201d\']?$',ws[k][0]) and k+1<len(ws) and ws[k+1][1]-ws[k][2]<0.7 and k-b<30: k+=1
        if k>b and re.search(r'[.?!:]["\u201d\']?$',ws[k][0]) and ws[k][2]-ws[b][2]<=2.6: b=k
    src=UP+plans[n]['file']
    w0=orig_time(n,ws[a][1]); we=orig_time(n,ws[b][2])
    prev_end=orig_time(n,ws[a-1][2]) if a>0 else None; nxt=orig_time(n,ws[b+1][1]) if b+1<len(ws) else None
    lead=0.25 if prev_end is None else max(0.05,min(0.25,w0-prev_end-0.04))
    sq=None
    for k in range(a,b):
        g0=orig_time(n,ws[k][2]); g1=orig_time(n,ws[k+1][1])
        if g1-g0>1.5: sq=(g0,g1)
    end=refine_end(src,we,nxt)
    return dict(n=n,src=src,ss=w0-lead,w0=w0,we=we,end=end,nxt=nxt,sq=sq,ws=ws,a=a,b=b,text=' '.join(w[0] for w in ws[a:b+1]))
def keyword_time(c,kw):
    ws=c['ws']; i,_=locate(ws,kw,c['a']); return orig_time(c['n'],ws[i][1])
def add_buffer(c,B):
    """extend with real silent footage after the speech (up to B s); whatever is missing is covered by holding the last frame"""
    if B<=0: c['real_end']=c['end']; c['freeze']=0.0; return c
    avail=(c['nxt']-0.06-c['end']) if c['nxt'] is not None else 3.0
    real=max(0.0,min(B,avail))
    while real>0.3 and vol(c['src'],c['end'],real,'max_volume')>=-32: real-=0.3
    if real<0.3: real=0.0
    c['real_end']=c['end']+real; c['freeze']=max(0.0,B-real); return c
def clip_len(c):
    L=c['real_end']-c['ss']
    if c['sq']: L=L-(c['sq'][1]-c['sq'][0])+0.45
    return L+c['freeze']+c.get('ext',0.0)
_listen={}
def find_listen(n,need,mind=1.5,margins=(0.3,0.2)):
    """a silent stretch with the person on camera (natural idle footage for buffers and waiting tiles)"""
    src=UP+plans[n]['file']; key=(n,mind)
    if key not in _listen:
        r=subprocess.run(['ffmpeg','-nostdin','-v','info','-i',src,'-vn','-af',f'silencedetect=noise=-35dB:d={mind}','-f','null','-'],capture_output=True,text=True).stderr
        s_=[max(0.0,float(x)) for x in re.findall(r'silence_start: (-?[\d.]+(?:e[-+]?\d+)?)',r)]; e_=[float(x) for x in re.findall(r'silence_end: ([\d.]+)',r)]
        _listen[key]=[(a,(e_[i] if i<len(e_) else 9999)) for i,a in enumerate(s_)]
    best=None
    for (a,b) in _listen[key]:
        a2=max(a+margins[0],2.6); avail=min(b,a2+60)-a2-margins[1]
        if avail<=0.5: continue
        t=a2+min(need,avail)/2
        f=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{t:.2f}','-i',src,'-frames:v','1','-vf','crop=900:700:1000:100,scale=64:48,format=gray','-f','rawvideo','-'],capture_output=True).stdout
        if len(f)<64*48 or np.frombuffer(f,np.uint8).mean()<9: continue
        if avail>=need+0.3: return a2,avail
        if best is None or avail>best[1]: best=(a2,avail)
    return best if best else (None,0)
def make_seq(n,cid,dur,root='/home/claude/mont/re/seq'):
    N=int(round(dur*48)); d=f'{root}/{cid}'; os.makedirs(d,exist_ok=True)
    c=f'/home/claude/mont/cache/{n}'; blank=f'/home/claude/mont/cache/blank_{n}_full.png'
    n_in=54; n_ex=31; ex=max(n_in,N-46) if N>=100 else N+99; off=12 if N<130 else 0
    for k in range(N):
        if k<n_in-off: t=f'{c}/in_{k+off:04d}.png'
        elif k>=ex+n_ex: t=blank
        elif k>=ex: t=f'{c}/out_{k-ex:04d}.png'
        else: t=f'{c}/hold.png'
        lk=f'{d}/{k:04d}.png'
        if os.path.lexists(lk): os.remove(lk)
        os.symlink(t,lk)
    return d
def gain_for(c):
    m=vol(c['src'],c['ss'],c['end']-c['ss'],'mean_volume'); return max(-12,min(15,-18.5-m))
def v_audio_chain(c,out_dur,gain):
    """audio for one clip: squeeze (if any), gain, pad/trim to exactly out_dur"""
    base='aresample=16000,aformat=channel_layouts=mono'
    if c['sq']:
        p1=(c['sq'][0]-c['ss'])+0.35; p2=(c['sq'][1]-c['ss'])-0.25; seg=c['real_end']-c['ss']
        return (f'asplit=2[b0][b1];[b0]atrim=0:{p1:.3f},asetpts=PTS-STARTPTS[aa];[b1]atrim={p2:.3f}:{seg:.3f},asetpts=PTS-STARTPTS[ab];[aa][ab]acrossfade=d=0.15,'
                f'volume={gain:.2f}dB,alimiter=limit=0.89,apad=whole_dur={out_dur:.3f},atrim=0:{out_dur:.3f},afade=t=in:st=0:d=0.03,afade=t=out:st={out_dur-0.06:.3f}:d=0.06')
    return (f'volume={gain:.2f}dB,alimiter=limit=0.89,apad=whole_dur={out_dur:.3f},atrim=0:{out_dur:.3f},afade=t=in:st=0:d=0.03,afade=t=out:st={out_dur-0.06:.3f}:d=0.06')
def squeeze_video(c):
    p1=(c['sq'][0]-c['ss'])+0.35; p2=(c['sq'][1]-c['ss'])-0.25; seg=c['real_end']-c['ss']
    return (f'split=2[s0][s1];[s0]trim=0:{p1:.3f},setpts=PTS-STARTPTS[va];[s1]trim={p2:.3f}:{seg:.3f},setpts=PTS-STARTPTS[vb];[va][vb]xfade=transition=fade:duration=0.15:offset={p1-0.15:.3f}')
