import sys,math,os,shutil
sys.argv=['x']
exec(open('/home/claude/anim5.py').read().split("if __name__")[0])
import numpy as np
QS={2:'Complete the sentence: My Deloitte journey is going to be… / has been…',3:"What’s something you’re unexpectedly / weirdly good at?",
 4:'What surprised you about your first week?',5:"What’s one thing your new team should know about you?",6:"What’s your hidden talent?",
 7:'What are you looking forward to the most?',8:"What’s one word you’d use to describe your new team?",
 9:'If your life had a theme song, what would it be?',10:"What’s the most common phrase you heard after joining?",11:'Describe your project in 1 word'}
W,H=1920,1080; ST=2; X0,Y0,RW,RH=100,200,1750,640
yy,xx=np.mgrid[0:H,0:W]; r=np.sqrt(((xx-1450)/900.0)**2+((yy-380)/700.0)**2); g=np.clip(1-r,0,1)**2
base=np.zeros((H,W,3),np.float32); base[...]=(3,9,10); base+=g[...,None]*np.array([10,34,28],np.float32)
BG=Image.fromarray(base.clip(0,255).astype(np.uint8)).convert('RGBA')
def make(qno,text,outdir,T=3.0):
    shutil.rmtree(outdir,ignore_errors=True); os.makedirs(outdir)
    fl=ImageFont.truetype(B,26*ST); fq=ImageFont.truetype(B,70*ST); d=ImageDraw.Draw(Image.new('RGBA',(10,10)))
    lines=[];cur=''
    for w in text.split():
        t=(cur+' '+w).strip()
        if d.textlength(t,font=fq)>1300*ST and cur: lines.append(cur); cur=w
        else: cur=t
    lines.append(cur)
    if len(lines)==2:   # balance the two lines so no single word is left on its own
        ws=text.split(); best=None
        for k in range(1,len(ws)):
            a=' '.join(ws[:k]); b=' '.join(ws[k:]); m=max(d.textlength(a,font=fq),d.textlength(b,font=fq))
            if best is None or m<best[0]: best=(m,a,b)
        lines=[best[1],best[2]]
    label=f'QUESTION {qno:02d}  /  11'; lab=Image.new('RGBA',(int(sum(d.textlength(c,font=fl)+3*ST for c in label))+10,sum(fl.getmetrics())+8*ST),(0,0,0,0)); ld=ImageDraw.Draw(lab); x=0
    for c in label: ld.text((x,0),c,font=fl,fill=GREEN+(255,)); x+=d.textlength(c,font=fl)+3*ST
    qh=sum(fq.getmetrics()); ql=[]
    for ln in lines:
        im=Image.new('RGBA',(int(d.textlength(ln,font=fq))+20*ST,qh),(0,0,0,0)); ImageDraw.Draw(im).text((0,0),ln,font=fq,fill=WHITE+(255,)); ql.append(im)
    X=(160-X0)*ST; Y=(360-Y0)*ST; N=int(T*FPS)
    for k in range(N):
        t=k/FPS; lay=Image.new('RGBA',(RW*ST,RH*ST),(0,0,0,0))
        p=eo3(clamp((t-0.15)/0.5))
        if p>0:
            l2=lab.copy(); l2.putalpha(l2.getchannel('A').point(lambda v:int(v*p))); lay.alpha_composite(l2,(X,int(Y-70*ST+(1-p)*10*ST)))
        cx,cy=X+6*ST,Y-18*ST; npop=eo3(clamp((t-0.25)/0.3)); r_=int(7*ST*npop)
        if r_>0:
            bx0,by0=cx-r_*3,cy-r_*3; gl=Image.new('RGBA',(r_*6,r_*6),(0,0,0,0)); ImageDraw.Draw(gl).ellipse([r_*2,r_*2,r_*4,r_*4],fill=GREEN+(255,)); gl=gl.filter(ImageFilter.GaussianBlur(8*ST)); lay.alpha_composite(gl,(bx0,by0))
            ImageDraw.Draw(lay).ellipse([cx-r_,cy-r_,cx+r_,cy+r_],fill=GREEN+(255,))
        lp=eio(clamp((t-0.4)/0.7)); lw=int(700*ST*lp); dd=ImageDraw.Draw(lay)
        for q in range(0,lw,2): dd.rectangle([cx+16*ST+q,cy-ST,cx+16*ST+q+1,cy+ST],fill=GREEN+(int(255*(1-0.9*(q/(700*ST)))),))
        for i,im in enumerate(ql):
            pp=eo3(clamp((t-0.6-0.14*i)/0.6)); y=Y+i*(qh+8*ST)
            if pp>0:
                tmp=Image.new('RGBA',lay.size,(0,0,0,0)); l3=im.copy(); l3.putalpha(l3.getchannel('A').point(lambda v:int(v*pp))); tmp.alpha_composite(l3,(X,int(y+(1-pp)*qh)))
                m=Image.new('L',lay.size,0); ImageDraw.Draw(m).rectangle([X-4*ST,y-4*ST,X+im.width,y+qh+4*ST],fill=255); tmp.putalpha(Image.composite(tmp.getchannel('A'),Image.new('L',lay.size,0),m)); lay.alpha_composite(tmp)
        lay=lay.resize((RW,RH),Image.LANCZOS); fr=BG.copy(); fr.alpha_composite(lay,(X0,Y0)); fr.convert('RGB').save(f'{outdir}/{k:04d}.png')
    return N,len(lines)
for q,t in QS.items(): print(q,make(q,t,f'/home/claude/mont/title_q{q}'),flush=True)
print('TITLES DONE')
