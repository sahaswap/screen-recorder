import sys; sys.argv=['x']
exec(open('/home/claude/anim4.py').read().split("if __name__")[0])
ys=set()
for n in INFO:
    y=render_seq(n,'L',f'/home/claude/anim/{n}_L4',2.6,t0=0.6,te=None); ys.add(y); print(n,y,flush=True)
print('overlay_y values:',ys)
