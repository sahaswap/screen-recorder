cd /home/claude/compress; SRC=/mnt/user-data/outputs/final_video/ShareAStory_QnA_v23.mp4
for f in hevc_1080p h264_720p; do
 ffmpeg -nostdin -v error -i $f.mp4 -i $SRC -filter_complex "[0:v]select='not(mod(n,24))',scale=1280:720:flags=bicubic,setpts=N/FRAME_RATE/TB,split[a1][a2];[1:v]select='not(mod(n,24))',scale=1280:720:flags=bicubic,setpts=N/FRAME_RATE/TB,split[b1][b2];[a1][b1]ssim=stats_file=ssim_$f.log[s];[a2][b2]psnr=stats_file=psnr_$f.log[p]" -map "[s]" -f null - -map "[p]" -f null - 2> q_$f.err
 echo $f DONE >> qstatus.txt
done
