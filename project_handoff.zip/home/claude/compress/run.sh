cd /home/claude/compress; SRC=/mnt/user-data/outputs/final_video/ShareAStory_QnA_v23.mp4
ffmpeg -y -nostdin -v error -i $SRC -c:v libx265 -preset fast -crf 26 -x265-params "vbv-maxrate=900:vbv-bufsize=2250:log-level=error" -pix_fmt yuv420p -tag:v hvc1 -c:a aac -b:a 96k -ac 1 -movflags +faststart hevc_1080p.mp4 && echo HEVC_DONE > status.txt
ffmpeg -y -nostdin -v error -i $SRC -vf scale=1280:720:flags=lanczos -c:v libx264 -preset medium -crf 24 -maxrate 900k -bufsize 2250k -pix_fmt yuv420p -c:a aac -b:a 96k -ac 1 -movflags +faststart h264_720p.mp4 && echo H264_DONE >> status.txt
