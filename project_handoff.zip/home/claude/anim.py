import json, math, sys, os, shutil
from PIL import Image, ImageDraw, ImageFont, ImageFilter
INFO=json.load(open('/home/claude/info.json'))
B='/home/claude/fonts_ttf/OpenSans-Bold.ttf'; R='/home/claude/fonts_ttf/OpenSans-Regular.ttf'
GREEN=(134,188,37); DARK=(40,39,40)
S=2; P=14; LM=57; FPS=16; NAME_PX=34; INFO_PX=23
def clamp(x): return max(0.0,min(1.0,x))
def eo3(p): return 1-(1-p)**3
def eio(p): return 3*p*p-2*p**3
def eback(p,c=0.8): c3=c+1; return 1+c3*(p-1)**3+c*(p-1)**2

class Tag:
    def __init__(s,n,mode):           # mode: 'card' or 'line'
        name,role,loc,client=INFO[n]; s.mode=mode
        fn=ImageFont.truetype(B,NAME_PX*S); fi=ImageFont.truetype(R,INFO_PX*S)
        s.lines=[name,f'{role}  ·  {loc}',f'Client: {client}']; s.fonts=[fn,fi,fi]
        d=ImageDraw.Draw(Image.new('RGBA',(10,10)))
        s.tw=max(d.textlength(t,font=f) for t,f in zip(s.lines,s.fonts))
        asc=[f.getmetrics() for f in s.fonts]; s.hs=[a+b for a,b in asc]
        s.pad=20*S; s.bar=5*S; gap1=7*S; gap2=3*S
        if mode=='card':
            s.W=int(s.bar+s.pad+s.tw+s.pad); s.tx=s.bar+s.pad; vp=14*S
            s.tops=[vp, vp+s.hs[0]+gap1, vp+s.hs[0]+gap1+s.hs[1]+gap2]
            s.H=int(s.tops[2]+s.hs[2]+vp)
        else:
            s.W=int(s.tw); s.tx=0; s.lineh=3*S; gl=11*S
            s.tops=[s.lineh+gl, s.lineh+gl+s.hs[0]+gap1, s.lineh+gl+s.hs[0]+gap1+s.hs[1]+gap2]
            s.H=int(s.tops[2]+s.hs[2])
        s.CX=LM*S; s.CY=P*S; s.CW=s.CX+s.W+P*S; s.CH=s.H+2*s.CY
        s.layers=[]
        for t,f,h in zip(s.lines,s.fonts,s.hs):
            im=Image.new('RGBA',(s.W,h),(0,0,0,0)); ImageDraw.Draw(im).text((s.tx,0),t,font=f,fill=GREEN+(255,))
            if mode=='line':   # soft shadow for legibility without a card
                sh=Image.new('RGBA',(s.W+16*S,h+16*S),(0,0,0,0)); ImageDraw.Draw(sh).text((s.tx+8*S,8*S+2*S),t,font=f,fill=(0,0,0,200))
                sh=sh.filter(ImageFilter.GaussianBlur(3*S)); big=Image.new('RGBA',(s.W+16*S,h+16*S),(0,0,0,0)); big=Image.alpha_composite(big,sh)
                big.alpha_composite(im,(8*S,8*S)); im=big
            s.layers.append(im)
        s.overlay_y=1080-48-s.H//S-P
    # --- helpers
    def put(s,base,layer,x,y,alpha,clip):
        if alpha<=0: return
        l=layer.copy()
        if alpha<1: l.putalpha(l.getchannel('A').point(lambda v:int(v*alpha)))
        tmp=Image.new('RGBA',base.size,(0,0,0,0)); tmp.alpha_composite(l,(int(x),int(y))) if (x>=0 and y>=0) else tmp.paste(l,(int(x),int(y)))
        m=Image.new('L',base.size,0); ImageDraw.Draw(m).rectangle([int(clip[0]),int(clip[1]),int(clip[2])-1,int(clip[3])-1],fill=255)
        tmp.putalpha(Image.composite(tmp.getchannel('A'),Image.new('L',base.size,0),m)); base.alpha_composite(tmp)
    def shadow(s,base,rect,strength=130):
        sh=Image.new('L',base.size,0); ImageDraw.Draw(sh).rectangle([rect[0],rect[1]+3*S,rect[2],rect[3]+3*S],fill=strength)
        sh=sh.filter(ImageFilter.GaussianBlur(6*S)); blk=Image.new('RGBA',base.size,(0,0,0,255)); blk.putalpha(sh); base.alpha_composite(blk)
    def textclip(s,i): return (s.CX+(s.bar if s.mode=='card' else 0), s.CY+s.tops[i]-4*S, s.CX+s.W+(0 if s.mode=='card' else 0)+2*S, s.CY+s.tops[i]+s.hs[i]+4*S)
    def tx_off(s): return -8*S if s.mode=='line' else 0
    # --- styles: intro(tv) -> RGBA at S scale ; L = intro length
    def A(s,tv):   # "Reveal": accent bar grows, card wipes open, text rises out of masks, staggered
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0))
        bp=eo3(clamp(tv/0.30)); bh=int(s.H*bp); gp=eo3(clamp((tv-0.15)/0.55)); bw=int((s.W-s.bar)*gp)
        if bh<=0: return base
        y0=s.CY+(s.H-bh)//2; y1=y0+bh
        s.shadow(base,(s.CX,y0,s.CX+s.bar+bw,y1))
        d=ImageDraw.Draw(base)
        if bw>0: d.rectangle([s.CX+s.bar,y0,s.CX+s.bar+bw-1,y1-1],fill=DARK+(222,))
        d.rectangle([s.CX,y0,s.CX+s.bar-1,y1-1],fill=GREEN+(255,))
        for i,dl in enumerate((0.45,0.60,0.75)):
            p=eo3(clamp((tv-dl)/0.40)); dy=(1-p)*s.hs[i]
            c=s.textclip(i); c=(c[0],c[1],min(c[2],s.CX+s.bar+bw),c[3])
            s.put(base,s.layers[i],s.CX,s.CY+s.tops[i]+dy,p,c)
        return base
    def B_(s,tv):  # "Slide": card glides in from the screen edge with a soft settle; text lags slightly
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0)); span=s.CX+s.W
        p0=eback(clamp(tv/0.55)); x0=s.CX+(p0-1)*span
        if tv<=0: return base
        a=clamp(tv/0.15)
        s.shadow(base,(x0,s.CY,x0+s.W,s.CY+s.H),int(130*a))
        d=ImageDraw.Draw(base); d.rectangle([x0+s.bar,s.CY,x0+s.W-1,s.CY+s.H-1],fill=DARK+(int(222*a),)); d.rectangle([x0,s.CY,x0+s.bar-1,s.CY+s.H-1],fill=GREEN+(255,))
        for i in range(3):
            pi=eback(clamp((tv-0.06*(i+1))/0.55)); xi=s.CX+(pi-1)*span
            s.put(base,s.layers[i],xi,s.CY+s.tops[i],a,(x0+s.bar,s.CY,x0+s.W,s.CY+s.H))
        return base
    def C(s,tv):   # "Line & rise": thin green line draws across, text rises from a mask, no card
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0))
        lp=eio(clamp(tv/0.50)); lw=int(s.W*lp)
        if lw>0: ImageDraw.Draw(base).rectangle([s.CX,s.CY,s.CX+lw-1,s.CY+s.lineh-1],fill=GREEN+(255,))
        for i,dl in enumerate((0.30,0.45,0.60)):
            p=eo3(clamp((tv-dl)/0.40)); dy=(1-p)*s.hs[i]
            c=(s.CX,s.CY+s.tops[i]-4*S,s.CX+s.W+8*S,s.CY+s.tops[i]+s.hs[i]+4*S)
            s.put(base,s.layers[i],s.CX-8*S if False else s.CX+s.tx_off(),s.CY+s.tops[i]-8*S+dy,p,c)
        return base
LEN={'A':1.2,'B':0.75,'C':1.15}
def virtual_time(t,t0,L,te):
    if t<t0: return 0.0
    if t<t0+L: return t-t0
    if te is None or t<te: return L
    ex=L*0.8
    if t<te+ex: return L-(t-te)/0.8
    return 0.0
def render_seq(n,style,outdir,T,t0=0.6,te=None):
    tag=Tag(n,'line' if style=='C' else 'card'); fn={'A':tag.A,'B':tag.B_,'C':tag.C}[style]; L=LEN[style]
    shutil.rmtree(outdir,ignore_errors=True); os.makedirs(outdir)
    N=int(math.ceil(T*FPS))
    for k in range(N):
        im=fn(virtual_time(k/FPS,t0,L,te)); im=im.resize((im.width//S,im.height//S),Image.LANCZOS); im.save(f'{outdir}/{k:04d}.png')
    return tag.overlay_y,N
if __name__=='__main__':
    n=sys.argv[1]; T=float(sys.argv[2])
    for st in 'ABC':
        y,N=render_seq(n,st,f'/home/claude/anim/{n}_{st}',T,t0=0.6,te=8.2); print(st,'frames',N,'overlay_y',y)
