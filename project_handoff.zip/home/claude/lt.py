from PIL import Image, ImageDraw, ImageFont
F='/home/claude/fonts/package/files/open-sans-latin-%s-normal.woff'
GREEN=(134,188,37); DARK=(40,39,40)
PEOPLE={  # key: (display name, designation, location)
 'Malavikka':('Malavikka Subash','Analyst','Bengaluru'),
 'Monesh':('Monesh M C','Senior Consultant','Bengaluru'),
 'Riddhima':('Riddhima Gupta','Associate Analyst','Pune'),
 'Mohammed':('Mohammed Maqsood','Associate Analyst','Bengaluru'),
 'Ananya':('Ananya K','Associate Analyst','Hyderabad'),
 'Irin':('Irin Winona S','Associate Analyst','Hyderabad'),
 'Arijit':('Arijit Sarkar','Consultant','Kolkata'),
 'Ayush':('Ayush Bhalotia','Associate Analyst','Pune'),
 'Shobhita':('Shobhita P Hegde','Analyst','Bengaluru'),
}
def make(key,scale=1.0):
    name,role,city=PEOPLE[key]
    fn=ImageFont.truetype(F%'700',int(54*scale)); fr=ImageFont.truetype(F%'400',int(33*scale))
    sep='   |   '
    d=ImageDraw.Draw(Image.new('RGBA',(10,10)))
    w1=d.textlength(name,font=fn); w2=d.textlength(role,font=fr); ws=d.textlength(sep,font=fr); w3=d.textlength(city,font=fr)
    pad=int(30*scale); bar=int(9*scale); gap=int(10*scale)
    W=int(max(w1,w2+ws+w3))+pad*2+bar+int(8*scale)
    a1=fn.getmetrics(); a2=fr.getmetrics()
    H=pad+a1[0]+a1[1]+gap+a2[0]+a2[1]+pad
    im=Image.new('RGBA',(W,H),DARK+(228,))
    d=ImageDraw.Draw(im)
    d.rectangle([0,0,bar-1,H],fill=GREEN+(255,))
    x=bar+pad; y=pad
    d.text((x,y),name,font=fn,fill=(255,255,255,255))
    y2=y+a1[0]+a1[1]+gap
    d.text((x,y2),role,font=fr,fill=(235,235,235,255))
    d.text((x+w2,y2),sep,font=fr,fill=(150,150,150,255))
    d.text((x+w2+ws,y2),city,font=fr,fill=GREEN+(255,))
    out=f'/home/claude/lt/{key}.png'; im.save(out); return out,W,H
if __name__=='__main__':
    for k in PEOPLE: print(k,make(k))
