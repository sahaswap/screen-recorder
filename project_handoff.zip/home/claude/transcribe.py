import sys, subprocess, re, json, numpy as np, sherpa_onnx, time
M='/home/claude/models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8/'
rec=sherpa_onnx.OfflineRecognizer.from_transducer(
    encoder=M+'encoder.int8.onnx',decoder=M+'decoder.int8.onnx',joiner=M+'joiner.int8.onnx',
    tokens=M+'tokens.txt',num_threads=1,decoding_method='greedy_search',model_type='nemo_transducer')
def load(path):
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-i',path,'-vn','-ac','1','-ar','16000','-f','f32le','-'],capture_output=True).stdout
    return np.frombuffer(raw,dtype=np.float32)
def silences(path):
    out=subprocess.run(['ffmpeg','-nostdin','-v','info','-i',path,'-vn','-af','silencedetect=noise=-35dB:d=0.25','-f','null','-'],capture_output=True,text=True).stderr
    s=[float(x) for x in re.findall(r'silence_start: ([\d.]+)',out)]
    e=[float(x) for x in re.findall(r'silence_end: ([\d.]+)',out)]
    return [((a+b)/2) for a,b in zip(s,e)]
def chunks(total,mids,maxlen=25.0,minlen=8.0):
    out=[];start=0.0
    while total-start>maxlen:
        c=[m for m in mids if start+minlen<=m<=start+maxlen]
        cut=c[-1] if c else start+maxlen
        out.append((start,cut)); start=cut
    out.append((start,total)); return out
def words_from(res,off):
    words=[];cur=None
    n=len(res.tokens)
    durs=list(res.durations) if len(res.durations)==n else [0.08]*n
    lp=list(res.ys_log_probs) if len(res.ys_log_probs)==n else [0.0]*n
    for tok,ts,du,p in zip(res.tokens,res.timestamps,durs,lp):
        if tok.startswith(' ') or cur is None:
            if cur: words.append(cur)
            cur=[tok.strip(),ts+off,ts+off+max(du,0.08),[p]]
        else:
            cur[0]+=tok; cur[3].append(p)
            if tok.strip(',.?!;:'): cur[2]=ts+off+max(du,0.08)
    if cur: words.append(cur)
    for w in words: w[3]=sum(w[3])/len(w[3])
    return words
if __name__=='__main__':
    path,outjson=sys.argv[1],sys.argv[2]
    a=load(path); total=len(a)/16000
    t0=time.time(); allw=[]
    for s,e in chunks(total,silences(path)):
        seg=a[int(s*16000):int(e*16000)]
        st=rec.create_stream(); st.accept_waveform(16000,seg); rec.decode_stream(st)
        allw+=words_from(st.result,s)
    json.dump({'duration':total,'words':allw},open(outjson,'w'))
    print(path.split('/')[-1],'words',len(allw),'time',round(time.time()-t0),'s for',round(total),'s audio')
