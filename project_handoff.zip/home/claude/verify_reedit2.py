import json,subprocess,sys,numpy as np
sys.argv=['x']
exec(open('/home/claude/transcribe.py').read().split("if __name__")[0])
ROOT='/home/claude/mont/re2'; c=json.load(open(ROOT+'/mix_counts.json')); order=c['order']; counts=c['counts']
FPS=48; X=14; SR=16000; Xs=int(round(X/FPS*SR))
def pcm(path,ss=0,dur=None):
    cmd=['ffmpeg','-v','error']+(['-ss',f'{ss:.3f}'] if ss else [])+(['-t',f'{dur:.3f}'] if dur else [])+['-i',path,'-vn','-ac','1','-ar','16000','-f','s16le','-']
    return np.frombuffer(subprocess.run(cmd,capture_output=True).stdout,np.int16).astype(np.float32)/32768
def xcorr(x,y):
    n=len(y)+len(x); F=1<<(n-1).bit_length()
    X_=np.fft.rfft(x[::-1]-x.mean(),F); Y=np.fft.rfft(y-y.mean(),F); cc=np.fft.irfft(X_*Y,F)[len(x)-1:len(y)]
    cs=np.cumsum(np.concatenate([[0],(y-y.mean())**2])); en=np.sqrt(np.maximum(cs[len(x):len(y)+1]-cs[:len(y)-len(x)+1],1e-9))
    return cc[:len(en)]/(en*np.sqrt(((x-x.mean())**2).sum())+1e-9)
final=pcm('/home/claude/mont/Curated_QnA_reedit2.mp4'); lens=[int(round(n/FPS*SR)) for n in counts]
pos=0; rows=[]; heard=[]
for i,p in enumerate(order):
    a=pcm(p)
    st=rec.create_stream(); st.accept_waveform(SR,a.astype(np.float32)); rec.decode_stream(st); heard.append(st.result.text.strip())
    # sync: where does the middle of this item's audio sit inside the final audio, compared with where it should be?
    L=len(a)
    if L>2.5*SR and np.abs(a).max()>0.02:
        m0=int(L*0.35); seg=a[m0:m0+int(1.2*SR)]; w0=max(0,pos+m0-2*SR); win=final[w0:pos+m0+int(1.2*SR)+2*SR]
        if len(win)>len(seg)+10:
            pk=int(np.argmax(xcorr(seg,win))); off=(w0+pk-(pos+m0))/SR; rows.append((i,p.split('/')[-1],round(off,3)))
    pos+=lens[i]-Xs
json.dump(dict(heard=heard,rows=rows),open('/home/claude/verify_reedit2.json','w'))
off=[r[2] for r in rows]; print('sync offsets of',len(off),'pieces: worst %.3f s, median %.3f s'%(max(off,key=abs),float(np.median(off))))
print('pieces more than 0.05 s off:',[r for r in rows if abs(r[2])>0.05])
print('DONE')
