import json, math, sys, os, shutil
from PIL import Image, ImageDraw, ImageFont, ImageFilter
INFO=json.load(open('/home/claude/info.json'))
INTER_R='/usr/share/fonts/opentype/inter/Inter-Regular.otf'; INTER_M='/usr/share/fonts/opentype/inter/Inter-Medium.otf'; INTER_B='/usr/share/fonts/opentype/inter/Inter-Bold.otf'
BASK='/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf'; LORA='/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf'
S=2; P=14; LM=57; FPS=16
def clamp(x): return max(0.0,min(1.0,x))
def eo3(p): return 1-(1-p)**3
def eio(p): return 3*p*p-2*p**3
def font(path,px,var=None):
    f=ImageFont.truetype(path,int(px*S))
    if var:
        try: f.set_variation_by_name(var)
        except Exception: pass
    return f
THEMES={
 # McKinsey-style: high contrast (deep navy on white), characterful serif name over a clean sans, one electric-blue accent
 'M':dict(panel=(255,255,255,246),accent=(34,81,255,255),bar=5,pad=22,vp=15,
          lines=[dict(f=(LORA,35,'Bold'),c=(5,28,44),up=False,tr=0),dict(f=(INTER_R,22,None),c=(5,28,44),up=False,tr=0),dict(f=(INTER_R,21,None),c=(98,106,112),up=False,tr=0)],gaps=(6,3),L=1.2),
 # BCG-style: warm-gray editorial panel, light Baskerville-type serif name, small tracked uppercase sans label, vivid-green accent
 'B':dict(panel=(241,238,234,246),accent=(150,248,120,255),bar=6,pad=22,vp=15,
          lines=[dict(f=(BASK,38,None),c=(33,36,39),up=False,tr=0),dict(f=(INTER_M,17,None),c=(29,95,69),up=True,tr=1.6),dict(f=(INTER_R,20,None),c=(105,105,105),up=False,tr=0)],gaps=(8,4),L=1.0),
 # Bain-style: strict white square panel, assertive bold black sans, a single red rule
 'R':dict(panel=(255,255,255,246),accent=(204,0,0,255),bar=0,pad=22,vp=15,rule=4,
          lines=[dict(f=(INTER_B,33,None),c=(17,17,17),up=False,tr=0),dict(f=(INTER_R,22,None),c=(51,51,51),up=False,tr=0),dict(f=(INTER_R,21,None),c=(102,102,102),up=False,tr=0)],gaps=(6,3),L=1.1),
}
def tracked_width(d,text,f,tr): return sum(d.textlength(ch,font=f)+tr*S for ch in text)-tr*S if tr else d.textlength(text,font=f)
class Tag2:
    def __init__(s,n,key):
        s.th=THEMES[key]; s.key=key; th=s.th
        name,role,loc,client=INFO[n]
        texts=[name,f'{role}  ·  {loc}',f'Client: {client}']
        s.fonts=[font(*l['f']) for l in th['lines']]
        s.texts=[t.upper() if l['up'] else t for t,l in zip(texts,th['lines'])]
        d=ImageDraw.Draw(Image.new('RGBA',(10,10)))
        s.tw=max(tracked_width(d,t,f,l['tr']) for t,f,l in zip(s.texts,s.fonts,th['lines']))
        s.hs=[sum(f.getmetrics()) for f in s.fonts]
        bar=th['bar']*S; pad=th['pad']*S; vp=th['vp']*S; rule=th.get('rule',0)*S; g1=th['gaps'][0]*S; g2=th['gaps'][1]*S
        s.bar=bar; s.rule=rule; s.tx=bar+pad
        s.W=int(bar+pad+s.tw+pad)
        t0=rule+vp; s.tops=[t0,t0+s.hs[0]+g1,t0+s.hs[0]+g1+s.hs[1]+g2]; s.H=int(s.tops[2]+s.hs[2]+vp)
        s.CX=LM*S; s.CY=P*S; s.CW=s.CX+s.W+P*S; s.CH=s.H+2*s.CY
        s.layers=[]
        for t,f,l,h in zip(s.texts,s.fonts,th['lines'],s.hs):
            im=Image.new('RGBA',(s.W,h),(0,0,0,0)); dr=ImageDraw.Draw(im); x=s.tx
            if l['tr']:
                for ch in t: dr.text((x,0),ch,font=f,fill=l['c']+(255,)); x+=dr.textlength(ch,font=f)+l['tr']*S
            else: dr.text((x,0),t,font=f,fill=l['c']+(255,))
            s.layers.append(im)
        s.overlay_y=1080-48-s.H//S-P
    def put(s,base,layer,x,y,alpha,clip):
        if alpha<=0: return
        l=layer.copy()
        if alpha<1: l.putalpha(l.getchannel('A').point(lambda v:int(v*alpha)))
        tmp=Image.new('RGBA',base.size,(0,0,0,0)); tmp.paste(l,(int(x),int(y)))
        m=Image.new('L',base.size,0); ImageDraw.Draw(m).rectangle([int(clip[0]),int(clip[1]),int(clip[2])-1,int(clip[3])-1],fill=255)
        tmp.putalpha(Image.composite(tmp.getchannel('A'),Image.new('L',base.size,0),m)); base.alpha_composite(tmp)
    def shadow(s,base,rect,strength=120):
        sh=Image.new('L',base.size,0); ImageDraw.Draw(sh).rectangle([rect[0],rect[1]+3*S,rect[2],rect[3]+3*S],fill=int(strength))
        sh=sh.filter(ImageFilter.GaussianBlur(6*S)); blk=Image.new('RGBA',base.size,(0,0,0,255)); blk.putalpha(sh); base.alpha_composite(blk)
    def lineclip(s,i,x1): return (s.CX+s.bar,s.CY+s.tops[i]-4*S,x1,s.CY+s.tops[i]+s.hs[i]+4*S)
    def frame(s,tv):
        return {'M':s.fM,'B':s.fB,'R':s.fR}[s.key](tv)
    def fM(s,tv):   # accent grows -> panel wipes open -> text rises from masks
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0)); th=s.th
        bp=eo3(clamp(tv/0.30)); bh=int(s.H*bp); gp=eo3(clamp((tv-0.15)/0.55)); bw=int((s.W-s.bar)*gp)
        if bh<=0: return base
        y0=s.CY+(s.H-bh)//2; y1=y0+bh
        s.shadow(base,(s.CX,y0,s.CX+s.bar+bw,y1),110); d=ImageDraw.Draw(base)
        if bw>0: d.rectangle([s.CX+s.bar,y0,s.CX+s.bar+bw-1,y1-1],fill=th['panel'])
        d.rectangle([s.CX,y0,s.CX+s.bar-1,y1-1],fill=th['accent'])
        for i,dl in enumerate((0.45,0.60,0.75)):
            p=eo3(clamp((tv-dl)/0.40)); s.put(base,s.layers[i],s.CX,s.CY+s.tops[i]+(1-p)*s.hs[i],p,s.lineclip(i,s.CX+s.bar+bw))
        return base
    def fB(s,tv):   # panel eases up and fades in, accent grows, text fades in with a small lift
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0)); th=s.th
        pa=eo3(clamp(tv/0.50)); dy=(1-pa)*16*S
        if pa<=0: return base
        pn=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0)); d=ImageDraw.Draw(pn)
        d.rectangle([s.CX+s.bar,s.CY,s.CX+s.W-1,s.CY+s.H-1],fill=th['panel'][:3]+(int(th['panel'][3]*pa),))
        ap=eo3(clamp((tv-0.2)/0.4)); ah=int(s.H*ap)
        if ah>0: d.rectangle([s.CX,s.CY+s.H-ah,s.CX+s.bar-1,s.CY+s.H-1],fill=th['accent'])
        base2=Image.new('RGBA',base.size,(0,0,0,0)); s.shadow(base2,(s.CX,s.CY,s.CX+s.W,s.CY+s.H),90*pa); base2.alpha_composite(pn)
        for i,dl in enumerate((0.35,0.50,0.65)):
            p=eo3(clamp((tv-dl)/0.35)); s.put(base2,s.layers[i],s.CX,s.CY+s.tops[i]+(1-p)*6*S,p,(0,0,s.CW,s.CH))
        base.alpha_composite(base2,(0,int(dy))) if False else base.paste(base2,(0,int(dy)),base2)
        return base
    def fR(s,tv):   # single red rule draws across, white panel opens downward from it, text fades in
        base=Image.new('RGBA',(s.CW,s.CH),(0,0,0,0)); th=s.th
        rp=eio(clamp(tv/0.45)); rw=int(s.W*rp)
        if rw<=0: return base
        pp=eo3(clamp((tv-0.25)/0.50)); ph=int((s.H-s.rule)*pp)
        s.shadow(base,(s.CX,s.CY,s.CX+rw,s.CY+s.rule+ph),100); d=ImageDraw.Draw(base)
        if ph>0: d.rectangle([s.CX,s.CY+s.rule,s.CX+rw-1,s.CY+s.rule+ph-1],fill=th['panel'])
        d.rectangle([s.CX,s.CY,s.CX+rw-1,s.CY+s.rule-1],fill=th['accent'])
        for i,dl in enumerate((0.55,0.65,0.75)):
            p=clamp((tv-dl)/0.30); s.put(base,s.layers[i],s.CX,s.CY+s.tops[i],p,(s.CX,s.CY+s.rule,s.CX+rw,s.CY+s.rule+ph))
        return base
def vtime(t,t0,L,te):
    if t<t0: return 0.0
    if t<t0+L: return t-t0
    if te is None or t<te: return L
    if t<te+L*0.8: return L-(t-te)/0.8
    return 0.0
def render_seq(n,key,outdir,T,t0=0.6,te=None):
    tag=Tag2(n,key); L=tag.th['L']
    shutil.rmtree(outdir,ignore_errors=True); os.makedirs(outdir)
    for k in range(int(math.ceil(T*FPS))):
        im=tag.frame(vtime(k/FPS,t0,L,te)); im.resize((im.width//S,im.height//S),Image.LANCZOS).save(f'{outdir}/{k:04d}.png')
    return tag.overlay_y
if __name__=='__main__':
    n=sys.argv[1]; T=float(sys.argv[2])
    for key in 'MBR': print(key,render_seq(n,key,f'/home/claude/anim/{n}_{key}2',T,t0=0.6,te=8.2))
