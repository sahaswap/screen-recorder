import re,sys,subprocess
f,sil_args=sys.argv[1],sys.argv[2]
sil=[tuple(map(float,s.split('-'))) for s in sil_args.split(',')]
subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-i',f,'-an','-vf','crop=500:300:700:250,signalstats,metadata=print:key=lavfi.signalstats.YDIF:file=/home/claude/m.txt','-f','null','-'])
vals=[];t=None
for line in open('/home/claude/m.txt'):
    m=re.search(r'pts_time:([\d.]+)',line)
    if m: t=float(m.group(1))
    m=re.search(r'YDIF=([\d.]+)',line)
    if m: vals.append((t,float(m.group(1))))
ins=[v for t,v in vals if any(a<=t<=b for a,b in sil)]
out=[v for t,v in vals if not any(a<=t<=b for a,b in sil)]
print(sys.argv[1].split('/')[-1],'silent:',round(sum(ins)/len(ins),2),'speech:',round(sum(out)/len(out),2))
