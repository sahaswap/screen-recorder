import subprocess,re,glob,json,os
NAMES={'Ananya':'AML_ShareAStory_Ananya_K','Ayush':'AML_ShareAstory_Ayush_Bhalotia','Irin':'AML_ShareAStory_Irin_WinonaS','Malavikka':'AML_ShareAStory_Malavikka_Subash','Mohammed':'AML_ShareAStory_Mohammed_Maqsood','Shobhita':'AML_ShareAStory_Shobhita_Hegde','Monesh':'AML_ShareStory_MONESH_MC','Arijit':'AML_ShareAStory_Arijit_Sarkar','Riddhima':'AML_ShareAStory_Riddhima_Gupta'}
out={}
for n,b in NAMES.items():
    f=f'/mnt/user-data/uploads/{b}.mp4'
    t=subprocess.run(['ffmpeg','-nostdin','-v','info','-i',f,'-an','-vf','freezedetect=n=-50dB:d=0.30','-f','null','-'],capture_output=True,text=True).stderr
    s=[float(x) for x in re.findall(r'freeze_start: ([\d.]+)',t)]; e=[float(x) for x in re.findall(r'freeze_end: ([\d.]+)',t)]
    out[n]=[(a,(e[i] if i<len(e) else None)) for i,a in enumerate(s)]
    print(n,len(out[n]),'stalls >=0.3s; total frozen %.1fs'%sum((b-a) for a,b in out[n] if b),flush=True)
json.dump(out,open('/home/claude/src_freeze.json','w'))
print('DONE')
