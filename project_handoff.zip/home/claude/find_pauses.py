import json,sys
sys.path.insert(0,'/home/claude')
from montage_lib import plans,seg_map,D
from spans_all import words,locate
from curated_spec import ROUNDS
def orig_time(n,t):
    m=seg_map(n); best=None
    for i,(S,E,a) in enumerate(m):
        if S-1e-6<=t<=E+1e-6 and (best is None or t>=S+D/2): best=(S,a)
    if best is None:
        i=min(range(len(m)),key=lambda k:min(abs(t-m[k][0]),abs(t-m[k][1]))); best=(m[i][0],m[i][2])
    return best[1]+(t-best[0])
info=json.load(open('/home/claude/cut2_info.json')); hits=[]
for x in info:
    n=x['n']
    for (nn,sp,ep) in ROUNDS[x['round']][2]:
        if nn!=n: continue
        ws=words(n)
        try: a,_=locate(ws,sp); _,b=locate(ws,ep,a)
        except Exception: continue
        if ' '.join(w[0] for w in ws[a:b+1])!=x['text']: continue
        gaps=[(orig_time(n,ws[k+1][1])-orig_time(n,ws[k][2]),ws[k][0],ws[k+1][0]) for k in range(a,b)]
        big=[g for g in gaps if g[0]>=0.7]
        if big: hits.append((x['i'],n,[(round(g[0],2),g[1],g[2]) for g in big]))
        break
print('clips with an internal pause >= 0.7 s in the original footage:')
for h in hits: print(' #%d %s %s'%h)
