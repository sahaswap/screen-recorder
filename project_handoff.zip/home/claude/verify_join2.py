import subprocess,json,numpy as np
exec(open('/home/claude/verify_sync2.py').read().split("out=[]")[0].split("cmds=")[0])  # imports only
def aud(path,ss,dur):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',path,'-vn','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(r,np.int16).astype(float)/32768
def vid(path,ss,dur):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,ss):.3f}','-t',f'{dur:.3f}','-i',path,'-an','-vf','fps=16,crop=iw*0.62:ih*0.72:iw*0.19:ih*0.04,scale=64:48,format=gray','-f','rawvideo','-'],capture_output=True).stdout
    return np.frombuffer(r,np.uint8).reshape(-1,48,64).astype(float)
def xcorr(x,y):
    n=len(y)+len(x); F=1<<(n-1).bit_length()
    X=np.fft.rfft(x[::-1]-x.mean(),F); Y=np.fft.rfft(y-y.mean(),F); c=np.fft.irfft(X*Y,F)[len(x)-1:len(y)]
    cs=np.cumsum(np.concatenate([[0],(y-y.mean())**2])); en=np.sqrt(np.maximum(cs[len(x):len(y)+1]-cs[:len(y)-len(x)+1],1e-9))
    return c[:len(en)]/(en*np.sqrt(((x-x.mean())**2).sum())+1e-9)
def sdur(p):
    j=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,duration','-of','json',p]).decode()); d={s['codec_type']:float(s['duration']) for s in j['streams']}; return d['video'],d['audio']
files=[l.split("'")[1] for l in open('/home/claude/mont/list_cut.txt')]; F='/mnt/user-data/outputs/curated_cut/Curated_QnA.mp4'
T=[];t=0
for p in files: T.append(t); t+=max(sdur(p))
rows=[]; W=2.5
for k,(p,t0) in enumerate(zip(files,T)):
    d=max(sdur(p)); 
    if 'title' in p: continue
    seg=min(1.4,d*0.7); ts=max(0.35,(d-seg)/2)
    ca=aud(p,ts,seg); fa=aud(F,t0+ts-W,seg+2*W)
    if len(fa)<len(ca)+10 or np.abs(ca).max()<1e-3: continue
    pk=int(np.argmax(xcorr(ca,fa))); a_off=(max(0,t0+ts-W)+pk/16000)-(t0+ts)
    cv=vid(p,ts,seg); fv=vid(F,t0+ts-W,seg+2*W); n=len(cv); best=None
    for s0 in range(0,len(fv)-n+1):
        e=np.mean((fv[s0:s0+n]-cv)**2)
        if best is None or e<best[1]: best=(s0,e)
    v_off=(max(0,t0+ts-W)+best[0]/16)-(t0+ts)
    rows.append((k,p.split('/')[-1],round(t0,1),round(a_off,3),round(v_off,3)))
json.dump(rows,open('/home/claude/verify_join2.json','w')); print('DONE',len(rows))
