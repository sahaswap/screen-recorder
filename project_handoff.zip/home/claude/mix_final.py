import subprocess,json,sys,os,collections
import numpy as np
ROOT='/home/claude/mont/re'; W,H=1920,1080; FS=W*H*3//2; X=14; FPS=48; SR=16000; Xs=int(round(X/FPS*SR)); K=72
FADE_IN=38; OUTV='/home/claude/mont/re/final_video.mp4'
man=json.load(open(ROOT+'/manifest.json'))['sections']
order=[]
for q,row in man:
    if q==2: order.append(ROOT+'/ttl/pause.mp4')
    order.append(f'{ROOT}/ttl/title_{q-1}.mp4'); order+=[o for o,d in row]
log=open(ROOT+'/mix.log','w')
enc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','yuv420p','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-c:v','libx264','-preset','fast','-crf','21','-profile:v','high','-pix_fmt','yuv420p','-x264-params','scenecut=0','-an','-movflags','+faststart',OUTV],stdin=subprocess.PIPE)
fi=0
def fade(b,f):
    a=np.frombuffer(b,np.uint8).astype(np.float32); y=a[:W*H]; a[:W*H]=16+(y-16)*f; a[W*H:]=128+(a[W*H:]-128)*f; return a.astype(np.uint8).tobytes()
def write(b,fadeout=None):
    global fi
    if fi<FADE_IN: b=fade(b,(fi+1)/FADE_IN)
    if fadeout is not None: b=fade(b,fadeout)
    enc.stdin.write(b); fi+=1
    if fi%1000==0: log.write(f'frames {fi}\n'); log.flush()
def frames(path):
    p=subprocess.Popen(['ffmpeg','-v','error','-i',path,'-an','-f','rawvideo','-pix_fmt','yuv420p','-'],stdout=subprocess.PIPE)
    while True:
        b=p.stdout.read(FS)
        if len(b)<FS: break
        yield b
    p.wait()
def blend(p,c,a):
    x=np.frombuffer(p,np.uint8).astype(np.float32)*(1-a)+np.frombuffer(c,np.uint8).astype(np.float32)*a; return x.astype(np.uint8).tobytes()
counts=[]; pending=None
for i,path in enumerate(order):
    it=frames(path); head=[]
    for _ in range(X):
        b=next(it,None)
        if b is None: break
        head.append(b)
    n=len(head)
    if pending is not None:
        for k,(p,c) in enumerate(zip(pending,head)): write(blend(p,c,(k+1)/(X+1)))
    else:
        for c in head: write(c)
    tail=collections.deque()
    for b in it:
        n+=1; tail.append(b)
        if len(tail)>K: write(tail.popleft())
    counts.append(n)
    if i<len(order)-1:
        while len(tail)>X: write(tail.popleft())
        pending=list(tail)
    else:
        L=len(tail)
        for j,b in enumerate(tail): write(b,fadeout=max(0.0,(L-1-j)/L))
    log.write(f'clip {i+1}/{len(order)} {os.path.basename(path)} frames={n}\n'); log.flush()
enc.stdin.close(); enc.wait(); total_frames=fi; log.write(f'VIDEO_DONE {total_frames} frames\n'); log.flush()
# ---- audio on the same timeline
def pcm(path): return np.frombuffer(subprocess.run(['ffmpeg','-v','error','-i',path,'-vn','-ac','1','-ar',str(SR),'-f','s16le','-'],capture_output=True).stdout,np.int16).astype(np.float32)
lens=[int(round(n/FPS*SR)) for n in counts]; total=sum(lens)-(len(order)-1)*Xs; out=np.zeros(total+SR,np.float32); pos=0
w=np.linspace(0,1,Xs,endpoint=False).astype(np.float32)
for i,path in enumerate(order):
    a=pcm(path)[:lens[i]]
    if len(a)<lens[i]: a=np.concatenate([a,np.zeros(lens[i]-len(a),np.float32)])
    if i>0: a[:Xs]*=w
    if i<len(order)-1: a[-Xs:]*=(1-w)
    out[pos:pos+lens[i]]+=a; pos+=lens[i]-Xs
want=int(round(total_frames/FPS*SR)); out=out[:want] if len(out)>=want else np.concatenate([out,np.zeros(want-len(out),np.float32)])
fi_s=int(0.8*SR); fo_s=int(1.5*SR); out[:fi_s]*=np.linspace(0,1,fi_s); out[-fo_s:]*=np.linspace(1,0,fo_s)
import wave
with wave.open(ROOT+'/final_audio.wav','wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR); f.writeframes(np.clip(out,-32768,32767).astype(np.int16).tobytes())
subprocess.run(['ffmpeg','-y','-v','error','-i',OUTV,'-i',ROOT+'/final_audio.wav','-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','64k','-ar','16000','-ac','1','-movflags','+faststart','/home/claude/mont/Curated_QnA_reedit.mp4'])
json.dump(dict(order=order,counts=counts),open(ROOT+'/mix_counts.json','w')); log.write('ALLDONE\n'); log.close()
