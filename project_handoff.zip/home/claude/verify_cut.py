import sys,json,glob,re,difflib
sys.argv=['x']
exec(open('/home/claude/transcribe.py').read().split("if __name__")[0])
SP=json.load(open('/home/claude/curated_spans.json'))
clips=sorted(c for c in glob.glob('/home/claude/mont/cut/[0-9][0-9]_*.mp4') if 'title' not in c)
assert len(clips)==len(SP),(len(clips),len(SP))
def norm(t): return re.sub(r"[^a-z0-9' ]"," ",t.lower()).split()
res=[]
for i,(c,o) in enumerate(zip(clips,SP),1):
    a=load(c); st=rec.create_stream(); st.accept_waveform(16000,a); rec.decode_stream(st)
    got=st.result.text.strip(); exp=o['text']
    e=norm(exp); g=norm(got)
    hit=sum(1 for w in e if w in g)/max(1,len(e))
    ratio=difflib.SequenceMatcher(None,e,g).ratio()
    res.append(dict(i=i,file=c.split('/')[-1],person=o['n'],round=o['round'],expected=exp,heard=got,cov=round(hit,2),ratio=round(ratio,2)))
json.dump(res,open('/home/claude/verify_cut.json','w'),indent=1)
bad=[r for r in res if r['cov']<0.7]
print('clips',len(res),'| low match (<70% of expected words heard):',len(bad))
for r in bad: print(f"\n#{r['i']} R{r['round']+1} {r['person']} cov={r['cov']}\n  expected: {r['expected'][:110]}\n  heard   : {r['heard'][:110]}")
print('\nmean coverage',round(sum(r['cov'] for r in res)/len(res),2))
