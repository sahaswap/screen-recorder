import sys,json,re
sys.path.insert(0,'/home/claude')
from reedit_lib import *
src=open('/home/claude/reedit_items.py').read(); blk=src[src.index('SECTIONS=['):src.index('TAILS=')]
def S(n,sp,ep,**o): return ('single',n,sp,ep,o)
def SP(mode,A,B,kw=None): return ('split',mode,A,B,kw)
def C(n,sp,ep,**o): return (n,sp,ep,o)
ns={'S':S,'SP':SP,'C':C}; exec(blk,ns); SECTIONS=ns['SECTIONS']
fr=json.load(open('/home/claude/src_freeze.json'))
specs=[]
for q,items in SECTIONS:
    for it in items:
        if it[0]=='single': specs.append((q,it[1:5]))
        else: specs += [(q,it[2]),(q,it[3])]
# plus Riddhima's Q6 answer already in the specs; check every clip
rows=[]
for q,(n,sp,ep,o) in specs:
    c=clip_def(n,sp,ep,complete=o.get('complete',True))
    a,b=c['ss'],c['end']
    for (s,e) in fr[n]:
        if e is None: continue
        lo,hi=max(a,s),min(b,e)
        if hi-lo>=0.3:
            x=aud(c['src'],lo,hi-lo); lv=20*np.log10(np.sqrt((x**2).mean())+1e-6)
            if lv>-32: rows.append((q,n,round(lo-a,2),round(hi-lo,2),round(lv,1),c['text'][:48]))
print('stalls overlapping SPEECH inside a clip (clip-relative start, length s, speech level dB):')
for r in rows: print('  Q%d %-9s starts %.2fs into clip, %.2fs long, level %.1f dB | %s'%r)
print('total',len(rows))
