import subprocess,time,sys
exec(open('/home/claude/memtest.py').read().split("lines=open")[0])
lines=open('/home/claude/run_nl2.sh').read().split('\n')
base=[l for l in lines if l.startswith('ffmpeg') and 'Shobhita' in l][0].split(' 2> ')[0].replace('/mnt/user-data/outputs/final_node_line/','/tmp/')
def lim(c,t): return c.replace('-movflags +faststart',f'-t {t} -movflags +faststart')
# V4: tag sequence extended with tpad (clone last frame) instead of overlay EOF handling
v4=base.replace('[dl][2:v]overlay=0:877:eof_action=repeat:shortest=1[sub];','[2:v]format=rgba,tpad=stop_mode=clone:stop_duration=400[tg];[dl][tg]overlay=0:877:shortest=1[sub];')
assert v4!=base
run(lim(v4,50),'V4 tpad extension, 50s of output',limit=150)
