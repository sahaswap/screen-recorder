import sys,json
sys.path.insert(0,'/home/claude')
from spans_all import span,words,locate
# (person, start phrase, end phrase, [optional second clip])
ROUNDS=[
 ("ROUND 01 / 09","Introduce yourself in 3 words",[
  ("Mohammed","I am curious proactive","adaptable"),("Arijit","calm passionate","curious"),("Riddhima","I am curious thoughtful","dependable"),
  ("Shobhita","ambitious adaptable","curious"),("Ayush","curious adventurous","challenges"),("Malavikka","quiet caring","ambitious")]),
 ("ROUND 02 / 09","What’s something you’re unexpectedly / weirdly good at?",[
  ("Ananya","I can read minds","read minds"),("Irin","making Excel do magic","do magic"),("Riddhima","I can still guess the song title","notes of the song"),
  ("Mohammed","remembering the smallest details","expect me to remember"),("Malavikka","giving advice and noticing","tiniest details"),
  ("Shobhita","networking and building meaningful connections","unexpected situations"),("Arijit","good at cooking and I like to cook Italian","cook Italian")]),
 ("ROUND 03 / 09","What’s your hidden talent?",[
  ("Ananya","I would proudly say","overthinker"),("Malavikka","I'd say dancing","good to go"),("Irin","I can dance to any song","know these steps"),
  ("Riddhima","very efficient at packing","entire new city"),("Monesh","experience has taught me how to connect dots","think on my feet")]),
 ("ROUND 04 / 09","What’s one thing your new team should know about you?",[
  ("Arijit","terrified about spiders","bit fun"),("Riddhima","I'm always up to learn something new","feeling down"),
  ("Monesh","I'm a fun person to work with","work with"),("Monesh","I always get my deliverables done","hook or crook"),("Irin","If I say I will do it","I'll do it")]),
 ("ROUND 05 / 09","What’s the most common phrase you heard after joining?",[
  ("Irin","Did you fill your timesheet","timesheet"),("Mohammed","networking networking and more networking","official Deloitte skill"),
  ("Ananya","that quick connect never ends","so quickly"),("Malavikka","let's connect","quite a lot"),("Riddhima","delighted to meet you","meet you"),("Shobhita","welcome to Deloitte","welcome to Deloitte")]),
 ("ROUND 06 / 09","Describe your project in 1 word",[
  ("Malavikka","I think it's dynamic","dynamic"),("Mohammed","My project is dynamic","figure out"),("Irin","My project in one word detectives","detectives"),
  ("Ananya","more like a detective work","something to investigate"),("Monesh","comprehensive challenging","expect the unexpected"),("Monesh","follow the money","analyze and report"),
  ("Shobhita","the term disconnect","work without phone")]),
 ("ROUND 07 / 09","What are you looking forward to the most?",[
  ("Arijit","Is the disconnect that I am looking forward","to the most"),("Ayush","Meeting new people","great memories"),
  ("Monesh","I'm excited to learn more","practical expertise"),("Ananya","I'm looking forward to growth","with you guys")]),
 ("ROUND 08 / 09","What surprised you about your first week?",[
  ("Ananya","so many passwords","remember them all"),("Arijit","there was no target","surprised me the most"),("Irin","how quickly strangers","became teammates"),
  ("Ayush","how many people are genuinely willing","settle in"),("Mohammed","how welcoming","easier for me")]),
 ("ROUND 09 / 09","What’s one word you’d use to describe your new team?",[
  ("Malavikka","one word to describe my new team is supportive","very supportive"),("Mohammed","I would say welcoming","welcoming"),("Ayush","Welcoming","Welcoming"),
  ("Riddhima","would be fostering","understanding for each other"),("Shobhita","If I had to describe my team in one word","supportive"),("Arijit","that I used synergistic","completely synergistic"),("Monesh","financial superheroes","terrorist financing")]),
 ("FINALE","If your life had a theme song, what would it be?",[
  ("Ananya","Love You Zindagi","goes with my life"),("Malavikka","Love You Zindagi","my vibe pretty well"),("Irin","My theme song would be 7 Rings by Ariana","7 Rings by Ariana"),
  ("Riddhima","Wake Up Sid","hustle I'm facing"),("Shobhita","Shin Chan's theme song","get things done"),("Ayush","The Nights by Avicii","gets better"),
  ("Mohammed","Shoe Dog by phil knight","from ground up"),("Monesh","life is like Kabhi Khushi Kabhie Gham","ups and downs"),("Arijit","Don't Stop Me Now by Queen","by Queen")]),
]
if __name__=='__main__':
    from montage_lib import to_source
    out=[]; seen=set(); counts={}
    for ri,(label,q,lines) in enumerate(ROUNDS):
        for (n,sp,ep) in lines:
            try: s,e,txt=span(n,sp,ep,lead=0.22,tail=0.32)
            except Exception as ex: print('ERROR',label,n,ex); continue
            kind,so=to_source(n,s,e); first=n not in seen; seen.add(n); counts[n]=counts.get(n,0)
            out.append(dict(round=ri,n=n,s=s,e=e,kind=kind,so=so,first=first,text=txt))
            flag=' SHORT' if e-s<2.4 else (' LONG' if e-s>10 else '')
            print(f'{label[:8]:8} {n:9} {e-s:4.1f}s {"FULL" if first else "name"}{flag} | {txt[:88]}')
    json.dump(out,open('/home/claude/curated_spans.json','w'))
    per={}
    for lines in [r[2] for r in ROUNDS]:
        for l in lines: per[l[0]]=per.get(l[0],0)+1
    print('clips',len(out),'total sec',round(sum(o["e"]-o["s"] for o in out)))
