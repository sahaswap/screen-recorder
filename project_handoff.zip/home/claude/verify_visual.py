import subprocess,glob,json,re,os
import numpy as np
from PIL import Image
NAMES={'Ananya':'AML_ShareAStory_Ananya_K','Ayush':'AML_ShareAstory_Ayush_Bhalotia','Irin':'AML_ShareAStory_Irin_WinonaS','Malavikka':'AML_ShareAStory_Malavikka_Subash','Mohammed':'AML_ShareAStory_Mohammed_Maqsood','Shobhita':'AML_ShareAStory_Shobhita_Hegde','Monesh':'AML_ShareStory_MONESH_MC','Arijit':'AML_ShareAStory_Arijit_Sarkar','Riddhima':'AML_ShareAStory_Riddhima_Gupta'}
def feat(im):
    a=np.array(im.convert('RGB').resize((96,54))).astype(float)
    a[40:,:25]=0; a[:8,:25]=0                      # ignore logo + tag corners
    h=[]
    for ch in range(3):
        hist,_=np.histogram(a[...,ch],bins=16,range=(0,255)); h.append(hist/hist.sum())
    # coarse spatial colour layout of the lower half (clothing) and middle (face)
    lay=np.array(Image.fromarray(a.astype(np.uint8)).resize((8,6))).astype(float).ravel()/255
    return np.concatenate(h+[lay])
refs={}
for n,b in NAMES.items():
    f=[p for p in glob.glob(f'/mnt/user-data/uploads/{b}.mp4')][0]
    fs=[]
    for t in (25,45,65,85):
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-ss',str(t),'-i',f,'-frames:v','1','/home/claude/r.png'])
        if os.path.exists('/home/claude/r.png'): fs.append(feat(Image.open('/home/claude/r.png'))); os.remove('/home/claude/r.png')
    refs[n]=fs
SP=json.load(open('/home/claude/curated_spans.json'))
clips=sorted(c for c in glob.glob('/home/claude/mont/cut/[0-9][0-9]_*.mp4') if 'title' not in c)
wrong=[]
for i,(c,o) in enumerate(zip(clips,SP),1):
    d=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',c]).decode())
    ds=[]
    for t in (d*0.35,d*0.6):
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-ss',f'{t:.2f}','-i',c,'-frames:v','1','/home/claude/v.png']); ds.append(feat(Image.open('/home/claude/v.png')))
    score={n:min(np.abs(x-r).sum() for x in ds for r in fs) for n,fs in refs.items()}
    best=min(score,key=score.get)
    if best!=o['n']: wrong.append((i,o['n'],best,round(score[o['n']],2),round(score[best],2)))
print('clips checked',len(clips),'| picture looks like a DIFFERENT person than the tag:',len(wrong))
for w in wrong: print('  clip #%d tagged %s but picture closest to %s (dist %.2f vs %.2f)'%w)
