import sherpa_onnx,wave,numpy as np,sys,time
D='/home/claude/tts/kokoro-multi-lang-v1_0/'
cfg=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(kokoro=sherpa_onnx.OfflineTtsKokoroModelConfig(
    model=D+'model.onnx',voices=D+'voices.bin',tokens=D+'tokens.txt',data_dir=D+'espeak-ng-data',dict_dir=D+'dict',lexicon=D+'lexicon-us-en.txt,'+D+'lexicon-zh.txt'),num_threads=2,provider='cpu'),max_num_sentences=1)
tts=sherpa_onnx.OfflineTts(cfg); print('sample rate',tts.sample_rate,'speakers',tts.num_speakers)
def say(text,sid,speed,out):
    t=time.time(); a=tts.generate(text,sid=sid,speed=speed); s=np.array(a.samples,np.float32)
    with wave.open(out,'wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(a.sample_rate); f.writeframes((np.clip(s,-1,1)*32767).astype(np.int16).tobytes())
    return len(s)/a.sample_rate,time.time()-t
if __name__=='__main__':
    for name,sid in (('af_heart',3),('af_bella',2),('am_michael',16),('am_eric',13)):
        d,t=say('Introduce yourself in three words.',sid,1.0,f'/home/claude/tts/s_{name}.wav'); print(f'{name:10} sid {sid:2d}: {d:.2f}s long (took {t:.1f}s)')
