import subprocess, re, json, math, sys
FR=1/16.0; D=0.25; PAD=0.375   # crossfade length, kept silence each side of a cut
MIN_CUT=0.9                    # only shorten pauses >= this
UP='/mnt/user-data/uploads/'
vids={
 'Ananya':'AML_ShareAStory_Ananya_K.mp4','Ayush':'AML_ShareAstory_Ayush_Bhalotia.mp4',
 'Irin':'AML_ShareAStory_Irin_WinonaS.mp4','Malavikka':'AML_ShareAStory_Malavikka_Subash.mp4',
 'Mohammed':'AML_ShareAStory_Mohammed_Maqsood.mp4','Shobhita':'AML_ShareAStory_Shobhita_Hegde.mp4',
 'Monesh':'AML_ShareStory_MONESH_MC.mp4','Arijit':'AML_ShareAStory_Arijit_Sarkar.mp4',
 'Riddhima':'AML_ShareAStory_Riddhima_Gupta.mp4'}
CARD_END={'Riddhima':2.0}   # Teams title card ends here (others 2.125)
def snap(x): return round(x/FR)*FR
def dur(f):
    return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',UP+f]).decode())
def silences(f):
    out=subprocess.run(['ffmpeg','-nostdin','-v','info','-i',UP+f,'-vn','-af','silencedetect=noise=-35dB:d=0.1','-f','null','-'],capture_output=True,text=True).stderr
    s=[float(x) for x in re.findall(r'silence_start: ([\d.]+)',out)]
    e=[float(x) for x in re.findall(r'silence_end: ([\d.]+)',out)]
    res=[]
    for i,a in enumerate(s):
        res.append([a, e[i] if i<len(e) else None])
    return res
plans={}
for n,f in vids.items():
    d=dur(f); sil=silences(f)
    for x in sil:
        if x[1] is None: x[1]=d
    # merge adjacent
    m=[]
    for a,b in sil:
        if m and a-m[-1][1]<0.05: m[-1][1]=b
        else: m.append([a,b])
    # lead: merge through tiny blips <0.15s
    while len(m)>1 and m[0][0]<0.05 and m[1][0]-m[0][1]<0.15: m[0][1]=m[1][1]; m.pop(1)
    m=[x for x in m if x[1]-x[0]>=0.4]
    speech_start=m[0][1] if m and m[0][0]<0.05 else 0.0
    card=CARD_END.get(n,2.125)
    start=snap(max(card, speech_start-0.5)); start=max(start,card)
    trail=None
    if m and d-m[-1][1]<0.1: trail=m[-1][0]
    end=d if trail is None else min(d, snap(trail+0.6))
    end=math.floor(end/FR)*FR
    cuts=[(a,b) for a,b in m if b-a>=MIN_CUT and a>start+PAD and b<end-PAD-0.5 and not (a<0.05) and not (trail is not None and a==trail)]
    segs=[]; cur=start; removed=0
    for a,b in cuts:
        co=snap(a+PAD); ci=snap(b-PAD)
        if ci<=co: continue
        segs.append((cur,co)); cur=ci
    segs.append((cur,end))
    plans[n]=dict(file=f,dur=d,start=start,end=end,cuts=cuts,segs=segs,speech_start=speech_start)
    L=sum(b-a for a,b in segs)-D*(len(segs)-1)
    plans[n]['out_len']=L
    print(f"{n}: dur {d:.1f} -> {L:.1f}s  (saved {d-L:.1f}s) start={start:.2f} end={end:.2f} cuts={len(cuts)}")
json.dump(plans,open('/home/claude/plans.json','w'),indent=1)
