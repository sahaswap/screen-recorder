import sys,os,json,math,subprocess
MODE=sys.argv[1]
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3')
from reedit_lib import *
import numpy as np, wave
from PIL import Image,ImageDraw,ImageFilter
ROOT='/home/claude/final4/w'; FPS=48
BEAT=60/118; B=[BEAT*k for k in range(9)]; T=(B[4]+0.80*BEAT) if MODE=='open' else B[7]; N=int(round(T*FPS))        # ends the moment the lockup has left the screen
WM=Image.open('/home/claude/final3/tpl/wordmark.png'); TG=Image.open('/home/claude/final3/tpl/tagline.png'); DOT=np.load('/home/claude/final3/tpl/dot.npy'); LW=WM.width
def clamp(x): return max(0.0,min(1.0,x))
def eo(p): return 1-(1-p)**3
def eio(p): return p*p*p*(p*(6*p-15)+10)
def eback(p,c=1.3): c3=c+1; return 1+c3*(p-1)**3+c*(p-1)**2
def lerp(a,b,p): return a+(b-a)*p
VIG=Image.new('RGBA',(1920,1080),(0,0,0,0)); _m=Image.new('L',(1920,1080),0); ImageDraw.Draw(_m).ellipse([960-860,540-330,960+860,540+330],fill=150); VIG.putalpha(_m.filter(ImageFilter.GaussianBlur(120)))
W0=1420                                    # lockup width on screen at rest
def frame(t,mode='open'):
    f=Image.new('RGBA',(1920,1080),(0,0,0,0))
    u=clamp((t-B[4])/BEAT) if mode=='open' else 0.0
    # no black at all: a gentle dim while the lockup is up, plus a soft dark pool behind it so white text stays legible
    k=0.0 if t<B[1] else (eo(clamp((t-B[1])/0.35)) if (t<B[4] or mode!='open') else 1-eo(u))
    if k>0.002:
        f.alpha_composite(Image.new('RGBA',(1920,1080),(0,0,0,int(255*0.20*k))))
        v=VIG.copy(); v.putalpha(v.getchannel('A').point(lambda x:int(x*k))); f.alpha_composite(v)
    if t>=B[1]:
        pop=clamp((t-B[1])/0.42); s=lerp(0.86,1.0,eback(pop,1.3)); pulse=sum(math.exp(-((t-tb)/0.11)**2) for tb in (B[2],B[3])); s*=1+0.045*pulse
        tp=clamp((t-B[3])/BEAT*1.0); ta=eo(tp); zoom=1+0.38*eio(u); alock=1-eo(clamp(u/0.75)); sc=W0/LW*s*zoom
        def put(img,cy_off,alpha):
            im=img.resize((int(img.width*sc),int(img.height*sc)),Image.LANCZOS)
            if alpha<0.999: im.putalpha(im.getchannel('A').point(lambda v:int(v*alpha)))
            x=int(960-im.width/2); y=int(520*1.0+cy_off*sc*0+cy_off-im.height/2); f.alpha_composite(im,(x,y)) if (x>=0 and y>=0) else f.paste(im,(x,y),im)
        # wordmark sits low while it is alone, then lifts as the tagline arrives
        put(WM,lerp(58,0,eo(tp))*zoom,alock*clamp((t-B[1])/0.12))
        if ta>0.002: put(TG,(1-ta)*26,alock*ta)
        # one thin green ring leaves the green dot on each beat (single circle at a time)
        cx=960+(DOT[0]-LW/2)*sc; cy=(520+lerp(58,0,eo(tp))*zoom)+(DOT[1]-WM.height/2)*sc
        g=ImageDraw.Draw(f)
        for tb in (B[1],B[2],B[3]):
            q=(t-tb)/0.52
            if 0<=q<=1 and alock>0.05:
                r=lerp(DOT[2]*sc*1.2,420,eo(q)); a=int(200*(1-q)*alock); gl=Image.new('RGBA',f.size,(0,0,0,0)); ImageDraw.Draw(gl).ellipse([cx-r,cy-r,cx+r,cy+r],outline=(134,188,37,a),width=5); f.alpha_composite(gl)
        glow=sum(math.exp(-((t-tb)/0.13)**2) for tb in (B[1],B[2],B[3]))
        if glow>0.02 and alock>0.05:
            gl=Image.new('RGBA',f.size,(0,0,0,0)); r=DOT[2]*sc*(1.5+0.8*glow); ImageDraw.Draw(gl).ellipse([cx-r,cy-r,cx+r,cy+r],fill=(134,235,34,int(150*glow*alock))); f.alpha_composite(gl.filter(ImageFilter.GaussianBlur(14)))
    if mode=='close':
        fb=eo(clamp((t-B[6])/BEAT))
        if fb>0.002: f.alpha_composite(Image.new('RGBA',(1920,1080),(0,0,0,int(255*fb))))
    return f
seqd=f'{ROOT}/trans/{MODE}ing'; os.makedirs(seqd,exist_ok=True)
for k in range(N): frame(k/FPS,MODE).save(f'{seqd}/{k:04d}.png')
print('opening frames',N,'(%.3fs)'%T,flush=True)
W_=json.load(open('/home/claude/final3/cold_words.json')); R_=json.load(open('/home/claude/final3/cold_words_r.json'))[0]
for i,w in enumerate(W_):
    if w['n']=='Riddhima': W_[i]=R_
    if w['n']=='Ayush': w['on']=6.97
ms=[dict(n=w['n'],src=w['src'],s=w['on']-2.3+(0.0 if MODE=='open' else 3.2)) for w in W_]; n=len(ms)
rows=[[(0,0),(640,0),(1280,0)],[(0,360),(640,360),(1280,360)],[(0,720),(640,720),(1280,720)]]; rects=[(x,y,640,360) for r in rows for x,y in r]
lab=f'{ROOT}/lab/cold_single.png'
inputs=' '.join(f'-ss {m["s"]:.3f} -t {T+0.1:.3f} -i "{m["src"]}"' for m in ms)+f' -loop 1 -framerate 48 -t {T:.3f} -i {lab} -framerate 48 -i {seqd}/%04d.png'
fv=''
for k,m in enumerate(ms):
    bx=BOX[m['n']]; fv+=f'[{k}:v]fps=16,setpts=PTS-STARTPTS,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},scale=640:360:flags=lanczos,setsar=1,format=yuv420p[p{k}];'
lay='|'.join(f'{x}_{y}' for x,y,w,h in rects); fv+=''.join(f'[p{k}]' for k in range(n))+f'xstack=inputs={n}:layout={lay}:fill=0x050e0f[st];[st]fps=48,format=yuv420p,split=2[s1][s2];[s1]gblur=sigma=26:steps=2,eq=brightness=0.05:contrast=0.80:saturation=0.70[hz];[s2]format=yuva420p,fade=t=in:st={B[1]:.3f}:d=0.62:alpha=1[sh];[hz][sh]overlay=0:0:format=auto,format=yuv420p[a];'
fv+=f'[{n}:v]format=rgba,fade=t=in:st={B[3]+0.1:.3f}:d=0.25:alpha=1[lb];[a][lb]overlay=0:0:shortest=1[b0];[{n+1}:v]format=rgba[sq];[b0][sq]overlay=0:0:shortest=1[v]'
base=f'{ROOT}/items/'+('intro_open' if MODE=='open' else 'closing')
cmd=f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{fv}" -map "[v]" -an -t {T:.3f} -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4'
r=subprocess.run(cmd,shell=True,capture_output=True,text=True); print('opening encode:',r.stderr[-300:] or 'ok')
with wave.open(base+'.wav','wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(32000); f.writeframes(np.zeros(int(round(T*32000)),np.int16).tobytes())
json.dump(dict(beat=BEAT,beats=B,T=T),open(ROOT+f'/meta_{MODE}.json','w')); print('meta written',MODE,'T=%.3f'%T)
