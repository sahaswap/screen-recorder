import sys,re,json,subprocess,time,numpy as np
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3')
from reedit_lib import *
from spans_all import words,locate
sys.argv=['x']; exec(open('/home/claude/transcribe.py').read().split("if __name__")[0])
MEMBERS={
 'curious':[('Mohammed','I am curious proactive','curious'),('Riddhima','I am curious thoughtful','curious'),('Shobhita','ambitious adaptable','curious'),('Ayush','curious adventurous','curious'),('Arijit','calm passionate','curious')],
 'welcoming_q4':[('Mohammed','Honestly how welcoming','welcoming'),('Shobhita','What surprised me the most during the first week','welcoming')],
 'supportive':[('Malavikka','one word to describe my new team is supportive','supportive'),('Ananya','If I had to describe my team','supportive'),('Shobhita','If I had to describe my team in one word','supportive')],
 'welcoming_q8':[('Mohammed','I would say welcoming','welcoming'),('Ayush','Welcoming','welcoming')],
 'dancing':[('Malavikka',"I'd say dancing",'dancing'),('Irin','I can dance to any song','dance'),('Ananya','I love dancing','dancing')],
 'dynamic':[('Malavikka',"I think it's dynamic",'dynamic'),('Mohammed','I would say my project is dynamic','dynamic')],
 'zindagi':[('Malavikka','Love You Zindagi','Love You Zindagi'),('Ananya','Love You Zindagi','Love You Zindagi')]}
OK={'curious':r'(a )?curious|curiosity','welcoming':r'(a |the )?welcom\w*|welcome in','supportive':r'(a |the )?support\w*','dancing':r'(a |the )?danc\w*','dance':r'(a |the )?danc\w*','dynamic':r'(a |the )?dynamic\w*','love you zindagi':r'.*zind\w*.*'}
def pcm(src,a0,dur):
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,a0):.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
    return np.frombuffer(raw,np.float32)
PAD=np.zeros(int(0.3*16000),np.float32)
def asr(x):
    st=rec.create_stream(); st.accept_waveform(16000,np.concatenate([PAD,x,PAD])); rec.decode_stream(st); return re.sub(r'[^a-z ]','',st.result.text.lower()).strip()
out={}; log=open('/home/claude/final4/word_bounds.log','w')
for key,mem in MEMBERS.items():
    out[key]={}
    for n,anchor,kw in mem:
        ws=words(n); a,_=locate(ws,anchor); ka,kb=locate(ws,kw,a); t0=orig_time(n,ws[ka][1]); t1=orig_time(n,ws[kb][2]); src=UP+plans[n]['file']; base=t0-0.7; x=pcm(src,base,2.6 if kw=='Love You Zindagi' else 1.9)
        S=lambda t:int((t-base)*16000); rx=re.compile(OK[kw.lower()]); valid=[]; tm=time.time()
        ds=(0.8,0.95,1.1,1.25,1.4) if kw=='Love You Zindagi' else (0.35,0.40,0.45,0.50,0.55,0.60,0.70,0.80)
        for dl in (-0.15,-0.10,-0.05,0.0,0.05,0.10,0.15,0.25):
            for d in ds:
                on=t0+dl; off=on+d
                if rx.fullmatch(asr(x[S(on):S(off)])): valid.append((on,off))
        if valid:
            ons=np.array([v[0] for v in valid]); c=ons.mean(); on,off=min(valid,key=lambda v:(abs(v[0]-c),-(v[1]-v[0]))); how='confirmed'
        else: on,off,how=t0,t0+(1.1 if kw=='Love You Zindagi' else 0.55),'transcript timing (not confirmed)'
        line=f"{key:13} {n:10} transcript {t0:7.2f}-{t1:7.2f} | {len(valid):2d} confirmed cuts | chosen {on:.2f}-{off:.2f} ({off-on:.2f}s) {how} [{time.time()-tm:.0f}s]"; print(line,flush=True); log.write(line+'\n'); log.flush()
        out[key][n]=dict(on=float(on),off=float(off),how=how,t0=float(t0),t1=float(t1)); json.dump(out,open('/home/claude/final4/word_bounds.json','w'))
log.write('DONE\n'); log.close()
