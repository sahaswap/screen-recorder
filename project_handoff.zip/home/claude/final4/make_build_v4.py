s=open('/home/claude/final3/build_v3.py').read()
s=s.replace("ROOT='/home/claude/final3/w'","ROOT='/home/claude/final4/w'")
# ---- 1) new content: the order, picks, merges and flashes from the spreadsheet
a=s.index("def S(n,sp,ep"); b=s.index("log=open(")
spec='''def S(n,sp,ep,**o): return dict(kind='single',n=n,sp=sp,ep=ep,o=o)
def MG(key,names,flash=None): return dict(kind='merge',key=key,names=names,flash=flash)
DELTA={'Malavikka':0.12,'Ananya':0.0,'Mohammed':0.0,'Irin':0.118,'Ayush':0.05,'Shobhita':0.042,'Riddhima':0.16,'Arijit':0.03,'Monesh':0.0}
WB=json.load(open('/home/claude/final4/word_bounds.json'))
WB['connect']={'Malavikka':dict(on=116.72,off=117.27),'Ananya':dict(on=106.67,off=107.17)}
COLD=[]
ROUNDS=[
 ("Introduce yourself in 3 words","Introduce yourself in three words.",[MG('curious',['Mohammed','Riddhima','Shobhita','Ayush','Arijit']),S('Malavikka','quiet caring','ambitious'),S('Irin','Driven committed','growing'),S('Ananya',"I would say that I'm sweet",'curious'),S('Monesh','I would describe myself as adaptable','comfort zone')]),
 ("What's something you're unexpectedly good at?","What is something you're unexpectedly good at?",[S('Ananya','I can read minds','read minds'),S('Irin','making Excel do magic','do magic'),S('Riddhima','I can still guess the song title','notes of the song'),S('Arijit','I like to cook Italian','made the best',end_at=63.50)]),
 ("What surprised you about your first week?","What surprised you about your first week?",[MG('welcoming_q4',['Mohammed','Shobhita'],flash='Welcoming'),S('Ananya','so many passwords','remember them all'),S('Ayush','how many people are genuinely willing','settle in')]),
 ("What's your hidden talent?","What is your hidden talent?",[MG('dancing',['Malavikka','Irin','Ananya']),S('Riddhima','very efficient at packing','able to do that'),S('Ananya','I would proudly say','overthinker'),S('Shobhita','Now my hidden talent is making connections','comfortable around me'),S('Monesh','experience has taught me how to connect dots','think on my feet',complete=False)]),
 ("Describe your project in 1 word","Describe your project in one word.",[MG('dynamic',['Malavikka','Mohammed'],flash='Dynamic'),S('Riddhima','to describe my project in one word','interesting and unique'),S('Irin','My project in one word','detectives'),S('Arijit',"I would say it's awesome",'awesome'),S('Ayush','Intriguing','Intriguing'),S('Monesh','comprehensive challenging','analyze and report')]),
 ("What's one word you'd use to describe your new team?","What is one word you'd use to describe your new team?",[MG('supportive',['Malavikka','Ananya','Shobhita'],flash='Supportive'),MG('welcoming_q8',['Mohammed','Ayush']),S('Arijit','that I used synergistic','completely synergistic'),S('Monesh','financial superheroes','terrorist financing')]),
 ("If your life had a theme song, what would it be?","If your life had a theme song, what would it be?",[MG('zindagi',['Malavikka','Ananya']),S('Irin','My theme song would be 7 Rings by Ariana','7 Rings by Ariana'),S('Riddhima','Wake Up Sid',"hustle I'm facing",complete=False),S('Shobhita',"Shin Chan's theme song",'get things done'),S('Ayush','The Nights by Avicii','gets better'),S('Monesh','life is like Kabhi Khushi Kabhie Gham','ups and downs'),S('Arijit',"Don't Stop Me Now by Queen",'by Queen')]),
 ("What's the most common phrase you heard after joining?","What is the most common phrase you heard after joining?",[MG('connect',['Malavikka','Ananya']),S('Irin','Did you fill your timesheet','timesheet'),S('Mohammed','networking networking and more networking','official Deloitte skill')]),
]
for _r in ROUNDS: _r[2][0]['first']=True
'''
s=s[:a]+spec+s[b:]
# ---- 2) resolution of items (merges use the recogniser-confirmed word boundaries)
a=s.index("def resolve_member"); b=s.index("for it in COLD: resolve(it)")
res='''def resolve(it):
    if it['kind']=='single':
        o=it['o']; c=clip_def(it['n'],it['sp'],it['ep'],complete=o.get('complete',True)); c['real_end']=c['end']; c['freeze']=0.0; ext=0.0
        if o.get('end_at'): c['end']=c['real_end']=o['end_at']
        it['c']=c; it['raw']=vlen_of(c)+ext; it['dur']=it['raw']/SPD; it['persons']=[it['n']]
    else:
        ms=[dict(n=n,src=UP+plans[n]['file'],on=WB[it['key']][n]['on'],dur=WB[it['key']][n]['off']-WB[it['key']][n]['on'],d=DELTA[n]) for n in it['names']]
        PRE=0.8 if it.get('first') else 0.25; maxd=max(m['dur'] for m in ms); POST=max(0.35,0.95-maxd) if it.get('flash') else 0.35
        L=PRE+maxd+POST; it.update(ms=ms,PRE=PRE,L=L,raw=L,dur=L,persons=list(it['names']))
'''
s=s[:a]+res+s[b:]
# ---- 3) merge command builder (normal pace, word-only sound, sound advance per person, flash word)
a=s.index("    else:\n        ms=it['ms']; n=len(ms); pd=panels(n)"); b=s.index("# cold open (no question, no dock)")
mg='''    else:
        ms=it['ms']; n=len(ms); pd=panels(n); L=it['L']; PRE=it['PRE']; lab=f'{ROOT}/lab/{label}_i{ii:02d}.png'; make_labels([m['n'] for m in ms],pd,lab)
        AX=0.17; inputs=' '.join(f'-ss {m["on"]-PRE:.3f} -t {L+AX:.3f} -i "{m["src"]}"' for m in ms)
        inputs+=f' -loop 1 -framerate 48 -t {D:.3f} -i {lab} -loop 1 -framerate 48 -t {D:.3f} -i /home/claude/mont/re/logo.png'; nxt=n+2; gi=ti=fi=None
        if dock: inputs+=f' -framerate 48 -i {rd}/%04d.png'; gi=nxt; nxt+=1
        if td: inputs+=f' -framerate 48 -i {td}/%04d.png'; ti=nxt; nxt+=1
        if it.get('flash'):
            fd=flash_seq(it['flash'],N,PRE-0.05,f'{ROOT}/reg/{label}_i{ii:02d}_flash'); inputs+=f' -framerate 48 -i {fd}/%04d.png'; fi=nxt; nxt+=1
        fv=''
        for k,m in enumerate(ms):
            chain=f'[{k}:v]fps=16'
            if pd['crop'] is None: bxk=BOX[m['n']]; chain+=f',delogo=x={bxk[0]}:y={bxk[1]}:w={bxk[2]}:h={bxk[3]}'
            else: cx,cy,cw,ch=pd['crop']; chain+=f',crop={cw}:{ch}:{cx}:{cy}'
            if pd['scale']: chain+=f',scale={pd["scale"][0]}:{pd["scale"][1]}:flags=lanczos'
            fv+=chain+f',setsar=1,format=yuv420p[p{k}];'
        lay='|'.join(f'{x}_{y}' for x,y,w,h in pd['rects']); fv+=''.join(f'[p{k}]' for k in range(n))+f'xstack=inputs={n}:layout={lay}:fill=0x050e0f[st];[st]fps=48,format=yuv420p[a];'
        fv+=f'[{n}:v]format=rgba,fade=t=in:st={max(0.0,PRE-0.25):.3f}:d=0.25:alpha=1[lb];[a][lb]overlay=0:0:shortest=1[b0];[{n+1}:v]format=rgba[lg];[b0][lg]overlay=40:25:shortest=1[b1]'; last='b1'
        if gi is not None: fv+=f';[{gi}:v]format=rgba[gf];[{last}][gf]overlay={GX}:{GY}:shortest=1[b2]'; last='b2'
        if fi is not None: fv+=f';[{fi}:v]format=rgba[fl];[{last}][fl]overlay=0:690:shortest=1[b3]'; last='b3'
        if ti is not None: fv+=f';[{ti}:v]format=rgba[tr];[{last}][tr]overlay=0:0:eof_action=pass[b4]'; last='b4'
        fv+=f';[{last}]null[v]'
        att=-3*math.log2(n); fa=''
        for k,m in enumerate(ms):
            g=max(-12,min(15,-18.5-vol(m['src'],m['on'],m['dur'],'mean_volume')))+att
            fa+=f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,atrim={PRE:.3f}:{PRE+m["dur"]+0.04:.3f},asetpts=PTS-STARTPTS,volume={g:.2f}dB,afade=t=in:st=0:d=0.012,afade=t=out:st={m["dur"]+0.04-0.03:.3f}:d=0.03,adelay={int(max(0,PRE-m["d"])*1000)}:all=1,apad=whole_dur={D:.3f},atrim=0:{D:.3f}[a{k}];'
        fa+=''.join(f'[a{k}]' for k in range(n))+f'amix=inputs={n}:normalize=0,alimiter=limit=0.89,apad=whole_dur={D:.3f},atrim=0:{D:.3f}[a]'
        cmds.append(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{fv};{fa}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 19 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4 -map "[a]" -t {D:.3f} -c:a pcm_s16le -ar {SR} -ac 1 {base}.wav')
        segs.append(dict(round=ri,type='merge',who='+'.join(m['n'] for m in ms),video=base+'.mp4',audio=base+'.wav',text='(merge: '+it['key']+(' + flash '+it['flash'] if it.get('flash') else '')+')'))
'''
s=s[:a]+mg+s[b:]
# ---- 4) the flash-word overlay generator (placed before make_item)
a=s.index("def make_item(")
fl='''FONT_BI='/home/claude/fonts_ttf/OpenSans-BoldItalic.ttf'
def flash_layer(word,scale):
    S2=2; f=ImageFont.truetype(FONT_BI,int(170*scale*S2)); W_,H_=1920*S2,280*S2; lay=Image.new('RGBA',(W_,H_),(0,0,0,0)); d=ImageDraw.Draw(lay); cx,cy=W_//2,H_//2
    sh=Image.new('RGBA',(W_,H_),(0,0,0,0)); ImageDraw.Draw(sh).text((cx+4*S2,cy+7*S2),word,font=f,fill=(0,0,0,200),anchor='mm',stroke_width=6*S2,stroke_fill=(0,0,0,200)); lay.alpha_composite(sh.filter(ImageFilter.GaussianBlur(7*S2)))
    gl=Image.new('RGBA',(W_,H_),(0,0,0,0)); ImageDraw.Draw(gl).text((cx,cy),word,font=f,fill=(134,188,37,255),anchor='mm'); gl=gl.filter(ImageFilter.GaussianBlur(18*S2)); gl.putalpha(gl.getchannel('A').point(lambda v:int(v*0.6))); lay.alpha_composite(gl)
    d.text((cx,cy),word,font=f,fill=(134,188,37,255),anchor='mm',stroke_width=5*S2,stroke_fill=(10,24,6,255)); return lay.resize((1920,280),Image.LANCZOS)
def flash_seq(word,N,t_f,rd):
    os.makedirs(rd,exist_ok=True); blank=f'{rd}/blank.png'; Image.new('RGBA',(1920,280),(0,0,0,0)).save(blank); stat=f'{rd}/static.png'; flash_layer(word,1.0).save(stat)
    for k in range(N):
        t=k/48; p=(t-t_f)/0.28; lk=f'{rd}/{k:04d}.png'
        if p<=0: os.symlink(blank,lk); continue
        q=(t-t_f-0.95)/0.25
        if q>=1: os.symlink(blank,lk); continue
        if p>=1 and q<=0: os.symlink(stat,lk); continue
        sc=0.75+0.25*G.eback(G.clamp(p),1.6) if p<1 else 1.0; im=flash_layer(word,sc); al=G.eo(G.clamp(p))*(1-G.clamp(q))
        im.putalpha(im.getchannel('A').point(lambda v,al=al:int(v*al))); im.save(f'{rd}/u{k:04d}.png'); os.symlink(f'{rd}/u{k:04d}.png',lk)
    return rd
'''
s=s[:a]+fl+s[a:]
open('/home/claude/final4/build_v4.py','w').write(s)
import ast; ast.parse(s); print('build_v4.py written; syntax ok | lines:',s.count('\\n'))
