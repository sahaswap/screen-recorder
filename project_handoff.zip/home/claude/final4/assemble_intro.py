import json,subprocess,wave,numpy as np
W='/home/claude/final4/w'; BEAT=60/118; T0=12*BEAT
mo=json.load(open(W+'/meta_open.json')); mc=json.load(open(W+'/meta_close.json'))
subprocess.run(f'cp /home/claude/demo_open/cards.mp4 {W}/items/cards.mp4',shell=True,check=True)
r=subprocess.run(f'ffmpeg -y -nostdin -v error -i {W}/items/cards.mp4 -i {W}/items/intro_open.mp4 -filter_complex "[0:v][1:v]xfade=transition=fade:duration=0.30:offset={T0:.4f}[v]" -map "[v]" -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {W}/items/intro.mp4',shell=True,capture_output=True,text=True); print('intro:',r.stderr[-200:] or 'ok')
d=float(subprocess.check_output(['ffprobe','-v','error','-select_streams','v','-show_entries','stream=duration','-of','csv=p=0',W+'/items/intro.mp4']).decode().split()[0])
with wave.open(W+'/items/intro.wav','wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(32000); f.writeframes(np.zeros(int(round(d*32000)),np.int16).tobytes())
P=json.load(open(W+'/plan.json'))
P['segs'].insert(0,dict(round=-1,type='intro',who='intro',video=W+'/items/intro.mp4',audio=W+'/items/intro.wav',text='(title cards + Deloitte opening)'))
P['segs'].append(dict(round=99,type='closing',who='closing',video=W+'/items/closing.mp4',audio=W+'/items/closing.wav',text='(Deloitte closing)'))
P['intro']=dict(T0=T0,TA=4*BEAT,T=mo['T'],beat=BEAT); P['closing']=dict(T=mc['T'])
json.dump(P,open(W+'/plan.json','w')); print('intro length %.3fs (title cards one bar + two bars, Deloitte opening from %.3fs) | closing %.3fs'%(d,T0,mc['T']))
