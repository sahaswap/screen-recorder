import sys,os,json,shutil,subprocess,math,wave,re,importlib.util
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final'); sys.path.insert(0,'/home/claude/final3'); sys.path.insert(0,'/home/claude/tts')
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
from reedit_lib import *
from spans_all import locate,words
import gfx_final as G, gfx_v3 as V
SPD=1.2; SR=32000
ROOT='/home/claude/final4/w'; shutil.rmtree(ROOT,ignore_errors=True)
for d in ('items','seq','vo','trans','reg','lab','prev'): os.makedirs(f'{ROOT}/{d}')
CHORUS_W='/home/claude/mont/re/items/38_Mohammed+Ayush.mp4'; CHORUS_Z='/home/claude/mont/re3/items/101_Ananya+Malavikka.mp4'
def S(n,sp,ep,**o): return dict(kind='single',n=n,sp=sp,ep=ep,o=o)
def MG(key,names,flash=None): return dict(kind='merge',key=key,names=names,flash=flash)
DELTA={'Malavikka':0.12,'Ananya':0.0,'Mohammed':0.0,'Irin':0.118,'Ayush':0.05,'Shobhita':0.042,'Riddhima':0.16,'Arijit':0.03,'Monesh':0.0}
WB=json.load(open('/home/claude/final4/word_bounds.json'))
WB['connect']={'Malavikka':dict(on=116.72,off=117.27),'Ananya':dict(on=106.67,off=107.17)}
COLD=[]
ROUNDS=[
 ("Introduce yourself in 3 words","Introduce yourself in three words.",[MG('curious',['Mohammed','Riddhima','Shobhita','Ayush','Arijit']),S('Malavikka','quiet caring','ambitious'),S('Irin','Driven committed','growing'),S('Ananya',"I would say that I'm sweet",'curious'),S('Monesh','I would describe myself as adaptable','comfort zone')]),
 ("What's something you're unexpectedly good at?","What is something you're unexpectedly good at?",[S('Ananya','I can read minds','read minds'),S('Irin','making Excel do magic','do magic'),S('Riddhima','I can still guess the song title','notes of the song'),S('Arijit','I like to cook Italian','made the best',end_at=63.50)]),
 ("What surprised you about your first week?","What surprised you about your first week?",[MG('welcoming_q4',['Mohammed','Shobhita'],flash='Welcoming'),S('Ananya','so many passwords','remember them all'),S('Ayush','how many people are genuinely willing','settle in')]),
 ("What's your hidden talent?","What is your hidden talent?",[MG('dancing',['Malavikka','Irin','Ananya']),S('Riddhima','very efficient at packing','able to do that'),S('Ananya','I would proudly say','overthinker'),S('Shobhita','Now my hidden talent is making connections','comfortable around me'),S('Monesh','experience has taught me how to connect dots','think on my feet',complete=False)]),
 ("Describe your project in 1 word","Describe your project in one word.",[MG('dynamic',['Malavikka','Mohammed'],flash='Dynamic'),S('Riddhima','to describe my project in one word','interesting and unique'),S('Irin','My project in one word','detectives'),S('Arijit',"I would say it's awesome",'awesome'),S('Ayush','Intriguing','Intriguing'),S('Monesh','comprehensive challenging','analyze and report')]),
 ("What's one word you'd use to describe your new team?","What is one word you'd use to describe your new team?",[MG('supportive',['Malavikka','Ananya','Shobhita'],flash='Supportive'),MG('welcoming_q8',['Mohammed','Ayush']),S('Arijit','that I used synergistic','completely synergistic'),S('Monesh','financial superheroes','terrorist financing')]),
 ("If your life had a theme song, what would it be?","If your life had a theme song, what would it be?",[MG('zindagi',['Malavikka','Ananya']),S('Irin','My theme song would be 7 Rings by Ariana','7 Rings by Ariana'),S('Riddhima','Wake Up Sid',"hustle I'm facing",complete=False),S('Shobhita',"Shin Chan's theme song",'get things done'),S('Ayush','The Nights by Avicii','gets better'),S('Monesh','life is like Kabhi Khushi Kabhie Gham','ups and downs'),S('Arijit',"Don't Stop Me Now by Queen",'by Queen')]),
 ("What's the most common phrase you heard after joining?","What is the most common phrase you heard after joining?",[MG('connect',['Malavikka','Ananya']),S('Irin','Did you fill your timesheet','timesheet'),S('Mohammed','networking networking and more networking','official Deloitte skill')]),
]
for _r in ROUNDS: _r[2][0]['first']=True
log=open(ROOT+'/stageA.log','w')
def say(*a):
    print(*a,flush=True); log.write(' '.join(str(x) for x in a)+'\n'); log.flush()
# ---------- voice-overs: Emma, slower
_sp=importlib.util.spec_from_file_location('ttsgen','/home/claude/tts/gen.py'); gen=importlib.util.module_from_spec(_sp); _sp.loader.exec_module(gen)
import wave as _w
VO={}
for ri,(txt,spoken,_) in enumerate(ROUNDS):
    raw=f'{ROOT}/vo/r{ri:02d}_raw.wav'; gen.say(spoken,20,0.92,raw)
    with _w.open(raw) as f: x=np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
    idx=np.where(np.abs(x)>0.012)[0]; a0=max(0,idx[0]-int(0.03*24000)); a1=min(len(x),idx[-1]+int(0.06*24000)); x=x[a0:a1]
    with _w.open(f'{ROOT}/vo/r{ri:02d}_trim.wav','wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(24000); f.writeframes((x*32767).astype(np.int16).tobytes())
    subprocess.run(['ffmpeg','-y','-nostdin','-v','error','-i',f'{ROOT}/vo/r{ri:02d}_trim.wav','-af','highpass=f=80,acompressor=threshold=-22dB:ratio=3:attack=4:release=70:makeup=3,alimiter=limit=0.9','-ar',str(SR),'-ac','1',f'{ROOT}/vo/r{ri:02d}_32k.wav'])
    with _w.open(f'{ROOT}/vo/r{ri:02d}_32k.wav') as f: y=np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
    y*=10**(-20.4/20)/(np.sqrt((y**2).mean())+1e-9); y*=min(1.0,0.95/(np.abs(y).max()+1e-9)); VO[ri]=y; np.save(f'{ROOT}/vo/r{ri:02d}.npy',y); say(f'VO {ri+1}: {len(y)/SR:.2f}s "{spoken}"')
# ---------- resolve every item (durations are after the 1.2x speed-up)
def vlen_of(c):
    L=c['real_end']-c['ss']
    if c['sq']: L=L-(c['sq'][1]-c['sq'][0])+0.45
    return L
def resolve(it):
    if it['kind']=='single':
        o=it['o']; c=clip_def(it['n'],it['sp'],it['ep'],complete=o.get('complete',True)); c['real_end']=c['end']; c['freeze']=0.0; ext=0.0
        if o.get('end_at'): c['end']=c['real_end']=o['end_at']
        it['c']=c; it['raw']=vlen_of(c)+ext; it['dur']=it['raw']/SPD; it['persons']=[it['n']]
    else:
        ms=[dict(n=n,src=UP+plans[n]['file'],on=WB[it['key']][n]['on'],dur=WB[it['key']][n]['off']-WB[it['key']][n]['on'],d=DELTA[n]) for n in it['names']]
        PRE=0.8 if it.get('first') else 0.25; maxd=max(m['dur'] for m in ms); POST=max(0.35,0.95-maxd) if it.get('flash') else 0.35
        L=PRE+maxd+POST; it.update(ms=ms,PRE=PRE,L=L,raw=L,dur=L,persons=list(it['names']))
for it in COLD: resolve(it)
for r in ROUNDS:
    for it in r[2]: resolve(it)
def add_tail(it):
    c=it['c']; n=c['n']; ws=words(n); nxt=None
    for w in ws:
        t=orig_time(n,w[1])
        if t>c['end']-0.05: nxt=t; break
    tl=0.7 if nxt is None else min(0.7,nxt-c['end']-0.15)
    if tl>=0.2:
        raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f"{c['end']:.3f}",'-t',f'{tl:.3f}','-i',c['src'],'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
        x=np.frombuffer(raw,np.float32)
        for k in range(0,len(x)-1600,1600):
            if np.sqrt((x[k:k+1600]**2).mean())>10**(-38/20): tl=max(0.0,k/16000-0.05); break
    if tl>=0.2: c['real_end']=c['end']+tl; it['raw']=vlen_of(c)+(it['raw']-vlen_of({**c,'real_end':c['end']})); it['dur']=it['raw']/SPD; it['tail']=round(tl,2)
for r in ROUNDS:
    last=r[2][-1]
    if last['kind']=='single' and not last['o'].get('final') and not last['o'].get('end_at'): add_tail(last)
bg=Image.open('/home/claude/mont/pause_bg.png').convert('RGBA')
R=[V.DRound(txt,len(VO[i])/SR,bg) for i,(txt,_,_) in enumerate(ROUNDS)]
tot=sum(round(it['dur']*48)/48 for it in COLD)+sum(rr.Tf for rr in R)+sum(round(it['dur']*48)/48 for r in ROUNDS for it in r[2])
say('estimated total length: %.1fs (%d:%02d)'%(tot,tot//60,tot%60))
for it in COLD+[i for r in ROUNDS for i in r[2]]:
    say(f"  {it['kind']:7} {'+'.join(it['persons'])[:40]:40} {it['dur']:5.2f}s")
# ---------- helpers for panels and labels
FNT='/home/claude/fonts_ttf/OpenSans-Bold.ttf'
def panels(n):
    if n==2: return dict(rects=[(0,0,960,1080),(960,0,960,1080)],crop=(480,0,960,1080),scale=None,size=34)
    if n==3: return dict(rects=[(0,0,640,1080),(640,0,640,1080),(1280,0,640,1080)],crop=(640,0,640,1080),scale=None,size=28)
    if n==4: return dict(rects=[(0,0,960,540),(960,0,960,540),(0,540,960,540),(960,540,960,540)],crop=(240,40,1440,810),scale=(960,540),size=26)
    if n in (5,6):
        top=[(0,0,640,540),(640,0,640,540),(1280,0,640,540)]; bot=[(320,540,640,540),(960,540,640,540)] if n==5 else [(0,540,640,540),(640,540,640,540),(1280,540,640,540)]
        return dict(rects=top+bot,crop=(480,40,960,810),scale=(640,540),size=24)
    rows=[[(0,0),(640,0),(1280,0)],[(0,360),(640,360),(1280,360)]]; last={7:[(640,720)],8:[(320,720),(960,720)],9:[(0,720),(640,720),(1280,720)]}[n]
    return dict(rects=[(x,y,640,360) for x,y in rows[0]+rows[1]+last],crop=None,scale=(640,360),size=20)
def make_labels(names,pdef,path):
    im=Image.new('RGBA',(1920,1080),(0,0,0,0)); d=ImageDraw.Draw(im); f=ImageFont.truetype(FNT,pdef['size'])
    for nm,(x,y,w,h) in zip(names,pdef['rects']):
        grad=np.zeros((90,w,4),np.uint8); grad[...,3]=(np.linspace(0,150,90)[:,None]*np.ones((1,w))).astype(np.uint8); im.alpha_composite(Image.fromarray(grad,'RGBA'),(x,y+h-90))
        ty=y+h-int(pdef['size']*0.9)-10; d.ellipse([x+14,ty-6,x+26,ty+6],fill=(134,188,37,255)); d.text((x+36,ty),nm,font=f,fill=(255,255,255,255),anchor='lm',stroke_width=1,stroke_fill=(0,0,0,200))
    im.save(path)
# ---------- graphics frames + commands
cmds=[]; segs=[]
def seq_dirs(rr,off,N,tag):
    rd=f'{ROOT}/reg/{tag}'; os.makedirs(rd)
    for k in range(N):
        t=off+k/48; os.symlink(rr.static if t>=rr.Tf+rr.trans else rr.blank,f'{rd}/{k:04d}.png')
    return rd
FONT_BI='/home/claude/fonts_ttf/OpenSans-BoldItalic.ttf'
def flash_layer(word,scale):
    S2=2; f=ImageFont.truetype(FONT_BI,int(170*scale*S2)); W_,H_=1920*S2,280*S2; lay=Image.new('RGBA',(W_,H_),(0,0,0,0)); d=ImageDraw.Draw(lay); cx,cy=W_//2,H_//2
    sh=Image.new('RGBA',(W_,H_),(0,0,0,0)); ImageDraw.Draw(sh).text((cx+4*S2,cy+7*S2),word,font=f,fill=(0,0,0,200),anchor='mm',stroke_width=6*S2,stroke_fill=(0,0,0,200)); lay.alpha_composite(sh.filter(ImageFilter.GaussianBlur(7*S2)))
    gl=Image.new('RGBA',(W_,H_),(0,0,0,0)); ImageDraw.Draw(gl).text((cx,cy),word,font=f,fill=(134,188,37,255),anchor='mm'); gl=gl.filter(ImageFilter.GaussianBlur(18*S2)); gl.putalpha(gl.getchannel('A').point(lambda v:int(v*0.6))); lay.alpha_composite(gl)
    d.text((cx,cy),word,font=f,fill=(134,188,37,255),anchor='mm',stroke_width=5*S2,stroke_fill=(10,24,6,255)); return lay.resize((1920,280),Image.LANCZOS)
def flash_seq(word,N,t_f,rd):
    os.makedirs(rd,exist_ok=True); blank=f'{rd}/blank.png'; Image.new('RGBA',(1920,280),(0,0,0,0)).save(blank); stat=f'{rd}/static.png'; flash_layer(word,1.0).save(stat)
    for k in range(N):
        t=k/48; p=(t-t_f)/0.28; lk=f'{rd}/{k:04d}.png'
        if p<=0: os.symlink(blank,lk); continue
        q=(t-t_f-0.95)/0.25
        if q>=1: os.symlink(blank,lk); continue
        if p>=1 and q<=0: os.symlink(stat,lk); continue
        sc=0.75+0.25*G.eback(G.clamp(p),1.6) if p<1 else 1.0; im=flash_layer(word,sc); al=G.eo(G.clamp(p))*(1-G.clamp(q))
        im.putalpha(im.getchannel('A').point(lambda v,al=al:int(v*al))); im.save(f'{rd}/u{k:04d}.png'); os.symlink(f'{rd}/u{k:04d}.png',lk)
    return rd
def make_item(label,ri,ii,it,rr,off,first):
    N=int(round(it['dur']*48)); D=N/48 if False else it['dur']; base=f'{ROOT}/items/{label}_i{ii:02d}'; dock=rr is not None
    rd=seq_dirs(rr,off,N,f'{label}_i{ii:02d}') if dock else None; td=f'{ROOT}/trans/{label}' if (dock and first) else None
    GX,GY=(rr.di['GX'],rr.di['GY']) if dock else (0,0)
    idx=[0]
    if it['kind']=='single':
        c=it['c']; n=c['n']; bx=BOX[n]; seg=c['real_end']-c['ss']; vl=vlen_of(c); gain=gain_for(c)
        seq=make_seq(n,f'v{label}{ii:02d}_{n}',D,root=ROOT+'/seq'); inputs=f'-ss {c["ss"]:.3f} -t {seg:.3f} -i "{c["src"]}" -framerate 48 -i {seq}/%04d.png'; nxt=2
        gi=None; ti=None
        if dock: inputs+=f' -framerate 48 -i {rd}/%04d.png'; gi=nxt; nxt+=1
        if td: inputs+=f' -framerate 48 -i {td}/%04d.png'; ti=nxt; nxt+=1
        if it.get('idle'):
            inputs+=f' -ss {it["idle"][0]:.3f} -t {it["idle"][1]+0.05:.3f} -i "{c["src"]}"'; ii_=nxt
            pre=f'[0:v]fps=16,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[cv];[{ii_}:v]fps=16,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[lv];[cv][lv]xfade=transition=fade:duration=0.25:offset={vl-0.25:.3f}[xv];[xv]'
        else: pre=('[0:v]'+squeeze_video(c)+'[vs];[vs]') if c['sq'] else '[0:v]'
        vf=f'{pre}setpts=PTS/{SPD},fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:877:shortest=1[b0]'; last='b0'
        if gi is not None: vf+=f';[{gi}:v]format=rgba[gf];[{last}][gf]overlay={GX}:{GY}:shortest=1[b1]'; last='b1'
        if ti is not None: vf+=f';[{ti}:v]format=rgba[tr];[{last}][tr]overlay=0:0:eof_action=pass[b2]'; last='b2'
        if it['o'].get('final'): vf+=f';[{last}]fade=t=out:st={D-1.5:.3f}:d=1.5[b3]'; last='b3'
        vf+=f';[{last}]null[v]'
        if c['sq']:
            p1=(c['sq'][0]-c['ss'])+0.35; p2=(c['sq'][1]-c['ss'])-0.25
            core=f'asplit=2[b0][b1];[b0]atrim=0:{p1:.3f},asetpts=PTS-STARTPTS[aa];[b1]atrim={p2:.3f}:{seg:.3f},asetpts=PTS-STARTPTS[ab];[aa][ab]acrossfade=d=0.15,'
        else: core=''
        af='[0:a]aresample=32000,aformat=channel_layouts=mono,'+core+f'atempo={SPD},volume={gain:.2f}dB,alimiter=limit=0.89,apad=whole_dur={D:.3f},atrim=0:{D:.3f},afade=t=in:st=0:d=0.03,afade=t=out:st={D-0.06:.3f}:d=0.06[a]'
        cmds.append(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{vf};{af}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 19 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4 -map "[a]" -t {D:.3f} -c:a pcm_s16le -ar {SR} -ac 1 {base}.wav')
        segs.append(dict(round=ri,type='single',who=n,video=base+'.mp4',audio=base+'.wav',text=c['text']))
    elif it['kind']=='chorus':
        inputs=f'-i "{it["path"]}"'; nxt=1; gi=ti=None
        if dock: inputs+=f' -framerate 48 -i {rd}/%04d.png'; gi=nxt; nxt+=1
        if td: inputs+=f' -framerate 48 -i {td}/%04d.png'; ti=nxt; nxt+=1
        vf=f'[0:v]setpts=PTS/{SPD},fps=48,format=yuv420p[a]'; last='a'
        if gi is not None: vf+=f';[{gi}:v]format=rgba[gf];[{last}][gf]overlay={GX}:{GY}:shortest=1[b1]'; last='b1'
        if ti is not None: vf+=f';[{ti}:v]format=rgba[tr];[{last}][tr]overlay=0:0:eof_action=pass[b2]'; last='b2'
        vf+=f';[{last}]null[v]'
        cmds.append(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{vf}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4')
        cmds.append(f'ffmpeg -y -nostdin -v error -i "{it["path"]}" -vn -af "atempo={SPD},apad=whole_dur={D:.3f},atrim=0:{D:.3f}" -ac 1 -ar {SR} -c:a pcm_s16le {base}.wav')
        segs.append(dict(round=ri,type='chorus',who='+'.join(it['who']),video=base+'.mp4',audio=base+'.wav',text='(chorus)'))
    else:
        ms=it['ms']; n=len(ms); pd=panels(n); L=it['L']; PRE=it['PRE']; lab=f'{ROOT}/lab/{label}_i{ii:02d}.png'; make_labels([m['n'] for m in ms],pd,lab)
        AX=0.17; inputs=' '.join(f'-ss {m["on"]-PRE:.3f} -t {L+AX:.3f} -i "{m["src"]}"' for m in ms)
        inputs+=f' -loop 1 -framerate 48 -t {D:.3f} -i {lab} -loop 1 -framerate 48 -t {D:.3f} -i /home/claude/mont/re/logo.png'; nxt=n+2; gi=ti=fi=None
        if dock: inputs+=f' -framerate 48 -i {rd}/%04d.png'; gi=nxt; nxt+=1
        if td: inputs+=f' -framerate 48 -i {td}/%04d.png'; ti=nxt; nxt+=1
        if it.get('flash'):
            fd=flash_seq(it['flash'],N,PRE-0.05,f'{ROOT}/reg/{label}_i{ii:02d}_flash'); inputs+=f' -framerate 48 -i {fd}/%04d.png'; fi=nxt; nxt+=1
        fv=''
        for k,m in enumerate(ms):
            chain=f'[{k}:v]fps=16'
            if pd['crop'] is None: bxk=BOX[m['n']]; chain+=f',delogo=x={bxk[0]}:y={bxk[1]}:w={bxk[2]}:h={bxk[3]}'
            else: cx,cy,cw,ch=pd['crop']; chain+=f',crop={cw}:{ch}:{cx}:{cy}'
            if pd['scale']: chain+=f',scale={pd["scale"][0]}:{pd["scale"][1]}:flags=lanczos'
            fv+=chain+f',setsar=1,format=yuv420p[p{k}];'
        lay='|'.join(f'{x}_{y}' for x,y,w,h in pd['rects']); fv+=''.join(f'[p{k}]' for k in range(n))+f'xstack=inputs={n}:layout={lay}:fill=0x050e0f[st];[st]fps=48,format=yuv420p[a];'
        fv+=f'[{n}:v]format=rgba,fade=t=in:st={max(0.0,PRE-0.25):.3f}:d=0.25:alpha=1[lb];[a][lb]overlay=0:0:shortest=1[b0];[{n+1}:v]format=rgba[lg];[b0][lg]overlay=40:25:shortest=1[b1]'; last='b1'
        if gi is not None: fv+=f';[{gi}:v]format=rgba[gf];[{last}][gf]overlay={GX}:{GY}:shortest=1[b2]'; last='b2'
        if fi is not None: fv+=f';[{fi}:v]format=rgba[fl];[{last}][fl]overlay=0:690:shortest=1[b3]'; last='b3'
        if ti is not None: fv+=f';[{ti}:v]format=rgba[tr];[{last}][tr]overlay=0:0:eof_action=pass[b4]'; last='b4'
        fv+=f';[{last}]null[v]'
        att=-3*math.log2(n); fa=''
        for k,m in enumerate(ms):
            g=max(-12,min(15,-18.5-vol(m['src'],m['on'],m['dur'],'mean_volume')))+att
            fa+=f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,atrim={PRE:.3f}:{PRE+m["dur"]+0.04:.3f},asetpts=PTS-STARTPTS,volume={g:.2f}dB,afade=t=in:st=0:d=0.012,afade=t=out:st={m["dur"]+0.04-0.03:.3f}:d=0.03,adelay={int(max(0,PRE-m["d"])*1000)}:all=1,apad=whole_dur={D:.3f},atrim=0:{D:.3f}[a{k}];'
        fa+=''.join(f'[a{k}]' for k in range(n))+f'amix=inputs={n}:normalize=0,alimiter=limit=0.89,apad=whole_dur={D:.3f},atrim=0:{D:.3f}[a]'
        cmds.append(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{fv};{fa}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 19 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4 -map "[a]" -t {D:.3f} -c:a pcm_s16le -ar {SR} -ac 1 {base}.wav')
        segs.append(dict(round=ri,type='merge',who='+'.join(m['n'] for m in ms),video=base+'.mp4',audio=base+'.wav',text='(merge: '+it['key']+(' + flash '+it['flash'] if it.get('flash') else '')+')'))
# cold open (no question, no dock)
t=0.0
for ii,it in enumerate(COLD):
    make_item('cold',-1,ii,it,None,t,False); t+=round(it['dur']*48)/48
say('cold open items queued')
for ri,rr in enumerate(R):
    items=ROUNDS[ri][2]; Nf=int(round(rr.Tf*48)); fl=f'{ROOT}/items/r{ri:02d}_flash.mp4'
    enc=subprocess.Popen(['ffmpeg','-y','-nostdin','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r','48','-i','-','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-g','96','-x264-params','scenecut=0',fl],stdin=subprocess.PIPE)
    for k in range(Nf): enc.stdin.write(np.asarray(rr.flash(k/48).convert('RGB')).tobytes())
    enc.stdin.close(); enc.wait(); segs.append(dict(round=ri,type='flash',video=fl,frames=Nf))
    td=f'{ROOT}/trans/r{ri:02d}'; os.makedirs(td)
    for k in range(int(round(rr.trans*48))): rr.transition(k/48).save(f'{td}/{k:04d}.png')
    rr.static=f'{ROOT}/reg/static_{ri}.png'; rr.dock_png.save(rr.static); rr.blank=f'{ROOT}/reg/blank_{ri}.png'; Image.new('RGBA',rr.dock_png.size,(0,0,0,0)).save(rr.blank)
    off=rr.Tf
    for ii,it in enumerate(items):
        make_item(f'r{ri:02d}',ri,ii,it,rr,off,ii==0); off+=round(it['dur']*48)/48
    say(f'round {ri+1} ready')
open(ROOT+'/items.sh','w').write('cd /home/claude\n'+'\n'.join(f'{c} || echo FAIL >> {ROOT}/items.err' for c in cmds)+f'\necho ALLDONE > {ROOT}/items.done\n')
json.dump(dict(segs=segs,rounds=[dict(Tf=rr.Tf,vo_t0=rr.vo_t0,vo_len=rr.vo_len) for rr in R]),open(ROOT+'/plan.json','w'))
say('STAGE_A_DONE',len(cmds),'commands')
