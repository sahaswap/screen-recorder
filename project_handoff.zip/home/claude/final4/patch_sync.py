# Applies the per-person lip-sync correction (tau = seconds the picture must lead the sound) to w/items.sh.
# Run AFTER build_v4.py (Stage A, which regenerates items.sh) and BEFORE `sh w/items.sh` (Stage B).
import re,sys
sys.path.insert(0,'/home/claude')
from reedit_lib import UP,plans
src2n={UP+plans[n]['file']:n for n in plans}
TAU={'Malavikka':0.16,'Ananya':0.20,'Mohammed':0.17,'Irin':0.17,'Riddhima':0.195,'Ayush':0.195,'Shobhita':0.15,'Arijit':0.18,'Monesh':0.16}
P='/home/claude/final4/w/items.sh'; lines=open(P).read().split('\n'); out=[]
for l in lines:
    if not l.startswith('ffmpeg'): out.append(l); continue
    head,rest=l.split(' -filter_complex ',1)
    if 'xstack' in rest:      # split-screen: picture starts earlier by tau; the word's sound stays where it is
        members=list(re.finditer(r'-ss ([\d.]+) -t ([\d.]+) -i "([^"]+)"',head)); newhead=head; newrest=rest
        for k,mm in enumerate(members):
            s,t,src=float(mm.group(1)),float(mm.group(2)),mm.group(3); tau=TAU[src2n[src]]
            newhead=newhead.replace(mm.group(0),f'-ss {max(0.0,s-tau):.3f} -t {t+tau:.3f} -i "{src}"',1)
            am=re.search(rf'\[{k}:a\]aresample=32000,aformat=channel_layouts=mono,atrim=([\d.]+):([\d.]+),',newrest); A,B=float(am.group(1)),float(am.group(2))
            newrest=newrest.replace(am.group(0),f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,atrim={A+tau:.3f}:{B+tau:.3f},',1)
            seg=re.search(rf'\[{k}:a\].*?\[a{k}\]',newrest).group(0); newrest=newrest.replace(seg,re.sub(r'adelay=\d+:all=1',f'adelay={int(round(A*1000))}:all=1',seg),1)
        out.append(newhead+' -filter_complex '+newrest)
    else:                     # solo clip: picture window starts earlier by tau, sound window unchanged (separate audio input)
        mm=re.search(r'-ss ([\d.]+) -t ([\d.]+) -i "([^"]+)"',head); s,t,src=float(mm.group(1)),float(mm.group(2)),mm.group(3); tau=TAU[src2n[src]]; k=head.count(' -i ')
        newhead=head.replace(mm.group(0),f'-ss {max(0.0,s-tau):.3f} -t {t:.3f} -i "{src}"',1)+f' -ss {s:.3f} -t {t+0.05:.3f} -i "{src}"'
        out.append(newhead+' -filter_complex '+rest.replace('[0:a]aresample',f'[{k}:a]aresample',1))
open(P,'w').write('\n'.join(out)); print('lip-sync correction applied to items.sh:',TAU)
