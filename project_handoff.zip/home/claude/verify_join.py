import subprocess,json,numpy as np
files=[l.split("'")[1] for l in open('/home/claude/mont/list_cut.txt')]
F='/mnt/user-data/outputs/curated_cut/Curated_QnA.mp4'
def sdur(p):
    r=subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,duration','-of','json',p]).decode(); j=json.loads(r)
    d={s['codec_type']:float(s['duration']) for s in j['streams']}; return d['video'],d['audio']
fv,fa=sdur(F); print('FINAL  video %.3f s  audio %.3f s  (gap %.3f s)'%(fv,fa,fa-fv))
tot_v=tot_a=0; T=[]; t=0
for p in files:
    v,a=sdur(p); T.append(t); t+=max(v,a); tot_v+=v; tot_a+=a
print('sum of clip files: video %.3f  audio %.3f ; running timeline end %.3f'%(tot_v,tot_a,t))
diffs=[sdur(p)[1]-sdur(p)[0] for p in files]; print('per-file audio-minus-video length: min %.3f max %.3f'%(min(diffs),max(diffs)))
def frame(p,tt):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{tt:.3f}','-i',p,'-frames:v','1','-vf','scale=96:54,format=gray','-f','rawvideo','-'],capture_output=True).stdout
    return np.frombuffer(r,np.uint8).astype(float) if len(r)==96*54 else None
def aud(p,tt,d):
    r=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{tt:.3f}','-t',f'{d:.3f}','-i',p,'-vn','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(r,np.int16).astype(float)/32768
bad=[]
for k,(p,t0) in enumerate(zip(files,T)):
    d=max(sdur(p)); tt=min(0.9,d*0.5)
    a=frame(p,tt); b=frame(F,t0+tt)
    mse=None if a is None or b is None else float(np.mean((a-b)**2))
    ca=aud(p,tt,0.6); fa_=aud(F,t0+tt,0.6)
    n=min(len(ca),len(fa_)); corr=float(np.corrcoef(ca[:n],fa_[:n])[0,1]) if n>100 and ca[:n].std()>1e-4 else None
    if (mse is not None and mse>150) or (corr is not None and corr<0.9): bad.append((k,p.split('/')[-1],round(t0,1),None if mse is None else round(mse,1),None if corr is None else round(corr,2)))
print('joins checked',len(files),'| joins where final video/audio differs from the clip:',len(bad))
for b in bad[:25]: print('  file#%d %s at %.1fs  picture-diff %s  audio-corr %s'%b)
