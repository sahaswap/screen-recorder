import sys,os,json,math,subprocess
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3')
from reedit_lib import *
from PIL import Image,ImageDraw,ImageFont
import numpy as np
ROOT='/home/claude/final3/w'; FPS=48
CW=json.load(open('/home/claude/final3/connect_words.json')); P=json.load(open(ROOT+'/plan.json')); Tf=P['rounds'][4]['Tf']; TRANS=0.70
ms=[dict(n='Malavikka',on=CW['Malavikka']['on'],dur=0.55,d=0.12),dict(n='Ananya',on=CW['Ananya']['on'],dur=0.50,d=0.0)]
for m in ms: m['src']=UP+plans[m['n']]['file']
PRE=0.80; POST=0.30; L=PRE+max(m['dur'] for m in ms)+POST; D=L; N=int(round(D*FPS)); AX=0.17
# labels (names), same look as the other splits
FNT='/home/claude/fonts_ttf/OpenSans-Bold.ttf'; rects=[(0,0,960,1080),(960,0,960,1080)]
im=Image.new('RGBA',(1920,1080),(0,0,0,0)); dr=ImageDraw.Draw(im); f=ImageFont.truetype(FNT,34)
for m,(x,y,w,h) in zip(ms,rects):
    grad=np.zeros((90,w,4),np.uint8); grad[...,3]=(np.linspace(0,150,90)[:,None]*np.ones((1,w))).astype(np.uint8); im.alpha_composite(Image.fromarray(grad,'RGBA'),(x,y+h-90))
    ty=y+h-40; dr.ellipse([x+14,ty-6,x+26,ty+6],fill=(134,188,37,255)); dr.text((x+36,ty),m['n'],font=f,fill=(255,255,255,255),anchor='lm',stroke_width=1,stroke_fill=(0,0,0,200))
lab=f'{ROOT}/lab/connect2.png'; im.save(lab)
# dock frames: nothing until the question card has settled, then the bar
rd=f'{ROOT}/reg/r04_i00_new'; os.makedirs(rd,exist_ok=True)
for k in range(N):
    lk=f'{rd}/{k:04d}.png'
    if os.path.lexists(lk): os.remove(lk)
    os.symlink(f'{ROOT}/reg/static_4.png' if Tf+k/FPS>=Tf+TRANS else f'{ROOT}/reg/blank_4.png',lk)
inputs=' '.join(f'-ss {m["on"]-PRE:.3f} -t {L+AX:.3f} -i "{m["src"]}"' for m in ms)+f' -loop 1 -framerate 48 -t {D:.3f} -i {lab} -loop 1 -framerate 48 -t {D:.3f} -i /home/claude/mont/re/logo.png -framerate 48 -i {rd}/%04d.png -framerate 48 -i {ROOT}/trans/r04/%04d.png'
fv=''
for k,m in enumerate(ms): fv+=f'[{k}:v]fps=16,crop=960:1080:480:0,setsar=1,format=yuv420p[p{k}];'          # normal speed, no clock reset
fv+=f'[p0][p1]xstack=inputs=2:layout=0_0|960_0:fill=0x050e0f[st];[st]fps=48,format=yuv420p[a];[2:v]format=rgba,fade=t=in:st=0.9:d=0.25:alpha=1[lb];[a][lb]overlay=0:0:shortest=1[b0];[3:v]format=rgba[lg];[b0][lg]overlay=40:25:shortest=1[b1];'
fv+=f'[4:v]format=rgba[gf];[b1][gf]overlay=536:944:shortest=1[b2];[5:v]format=rgba[tr];[b2][tr]overlay=0:0:eof_action=pass[v]'
fa=''
for k,m in enumerate(ms):
    g=max(-12,min(15,-18.5-vol(m['src'],m['on'],m['dur'],'mean_volume')))-3.0
    # the shared word only, taken from the source at its true time and played d seconds early so it meets the lips
    fa+=f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,atrim={PRE:.3f}:{PRE+m["dur"]+0.04:.3f},asetpts=PTS-STARTPTS,volume={g:.2f}dB,afade=t=in:st=0:d=0.012,afade=t=out:st={m["dur"]+0.04-0.03:.3f}:d=0.03,adelay={int((PRE-m["d"])*1000)}:all=1,apad=whole_dur={D:.3f},atrim=0:{D:.3f}[a{k}];'
fa+=f'[a0][a1]amix=inputs=2:normalize=0,alimiter=limit=0.89,apad=whole_dur={D:.3f},atrim=0:{D:.3f}[a]'
base=f'{ROOT}/items/r04_i00'
cmd=f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{fv};{fa}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 19 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4 -map "[a]" -t {D:.3f} -c:a pcm_s16le -ar 32000 -ac 1 {base}.wav'
r=subprocess.run(cmd,shell=True,capture_output=True,text=True); print('connect split re-rendered:',r.stderr[-300:] or 'ok','| normal speed, %.2fs long (was 0.81s); the word lands at %.2fs, after the question card settles at %.2fs'%(D,PRE,TRANS))
