import sys,re,json,subprocess,time,numpy as np
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3')
from reedit_lib import *
from spans_all import words,locate
sys.argv=['x']; exec(open('/home/claude/transcribe.py').read().split("if __name__")[0])
def pcm(src,a0,dur):
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,a0):.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
    return np.frombuffer(raw,np.float32)
PAD=np.zeros(int(0.3*16000),np.float32)
def asr(x):
    st=rec.create_stream(); st.accept_waveform(16000,np.concatenate([PAD,x,PAD])); rec.decode_stream(st); return re.sub(r'[^a-z ]','',st.result.text.lower()).strip()
SPEC=[('Malavikka',"let's connect",'connect'),('Ananya','that quick connect never ends','connect')]
out={}
for n,anchor,kw in SPEC:
    ws=words(n); a,_=locate(ws,anchor); ka,kb=locate(ws,kw,a); t0=orig_time(n,ws[ka][1]); t1=orig_time(n,ws[kb][2]); src=UP+plans[n]['file']; base=t0-0.7; x=pcm(src,base,1.9)
    S=lambda t:int((t-base)*16000); valid=[]
    for dl in (-0.20,-0.15,-0.10,-0.05,0.0,0.05,0.10,0.15,0.20,0.25,0.30):
        for d in (0.35,0.40,0.45,0.50,0.55,0.60,0.70):
            on=t0+dl; off=on+d; t=asr(x[S(on):S(off)])
            if t in ('connect','connected','kinect','conduct','a connect','connects'): valid.append((on,off))
    if valid:
        ons=np.array([v[0] for v in valid]); c=ons.mean(); best=min(valid,key=lambda v:(abs(v[0]-c),-(v[1]-v[0]))); on,off=best; how='confirmed'
    else: on,off=t0,t0+0.45; how='not confirmed (kept transcript timing)'
    print(f"{n:10} transcript says 'connect' starts {t0:.2f}s (ends {t1:.2f}s) | {len(valid):2d} recogniser-confirmed cuts | refined onset {on:.2f}s, word {off-on:.2f}s | shift vs transcript {1000*(on-t0):+.0f} ms | {how}",flush=True)
    out[n]=dict(t0=float(t0),on=float(on),off=float(off),how=how,valid=len(valid))
json.dump(out,open('/home/claude/final3/connect_words.json','w'))
if len(out)==2:
    a,b=out['Malavikka'],out['Ananya']; print('onset gap between the two people if the transcript were trusted: %.0f ms ; after refinement the two onsets are aligned exactly'%(1000*abs((a['t0'])-(b['t0']))-0))
