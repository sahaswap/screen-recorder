import sys,os,re,json,subprocess,time,numpy as np
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3')
from reedit_lib import *
from spans_all import words
sys.argv=['x']; exec(open('/home/claude/transcribe.py').read().split("if __name__")[0])
HINT={'Mohammed':13.3,'Riddhima':9.8,'Shobhita':7.8,'Ayush':6.9,'Irin':7.8,'Malavikka':8.8,'Ananya':15.0,'Arijit':7.4,'Monesh':26.4}
ORDER=['Mohammed','Riddhima','Shobhita','Ayush','Irin','Malavikka','Ananya','Arijit','Monesh']
def pcm(src,a0,dur):
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,a0):.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
    return np.frombuffer(raw,np.float32)
PAD=np.zeros(int(0.3*16000),np.float32)
def asr(x):
    st=rec.create_stream(); st.accept_waveform(16000,np.concatenate([PAD,x,PAD])); rec.decode_stream(st); return re.sub(r'[^a-z ]','',st.result.text.lower()).strip()
OKRE=re.compile(r'(the |a )?(de ?loi?tte?|delight|deloit\w*|dloit\w*|de lloyd|deloy\w*)')
def ok(t): return bool(OKRE.fullmatch(t))
out=[]; log=open('/home/claude/final3/cold_fix3.log','w')
for n in ORDER:
    ws=words(n); idx=[i for i,w in enumerate(ws) if re.search('deloitte',w[0],re.I) and abs(orig_time(n,w[1])-HINT[n])<1.5][0]
    t0=orig_time(n,ws[idx][1]); t1=orig_time(n,ws[idx][2]); src=UP+plans[n]['file']; base=t0-0.7; x=pcm(src,base,1.9)
    S=lambda t:int((t-base)*16000); valid=[]; tm=time.time()
    for dl in (-0.10,-0.05,0.0,0.05,0.10,0.15,0.20):
        for d in (0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.80):
            on=t0+dl; off=on+d
            if ok(asr(x[S(on):S(off)])): valid.append((on,off))
    if valid:
        ons=np.array([v[0] for v in valid]); c=ons.mean(); best=min(valid,key=lambda v:(abs(v[0]-c),-(v[1]-v[0])))
        on,off=best; good=ok(asr(x[S(on-0.02):S(off+0.04)])); how='validated'
        if not good: good=ok(asr(x[S(on):S(off)])); how='validated (no margins)'
    else: on,off=t0+0.05,t0+0.05+0.58; how='FALLBACK: transcript start, typical word length'
    line=f"{n:10} transcript {t0:6.2f}-{t1:6.2f} | {len(valid):2d}/56 cuts heard as the word | chosen {on:.2f}-{off:.2f} ({off-on:.2f}s) {how}  [{time.time()-tm:.0f}s]"
    print(line,flush=True); log.write(line+'\n'); log.flush(); out.append(dict(n=n,src=src,on=float(on),off=float(off),how=how,valid=len(valid)))
    json.dump(out,open('/home/claude/final3/cold_words.json','w'))
log.write('DONE\n'); log.close()
