import sys,re,json,subprocess,os
sys.path.insert(0,'/home/claude')
from reedit_lib import UP,plans
ROOT='/home/claude/final3/w'
MED={'Malavikka':0.225,'Ananya':0.0,'Mohammed':0.074,'Irin':0.223,'Ayush':0.138,'Shobhita':0.127,'Riddhima':0.328,'Arijit':0.113}
DELTA={n:round(max(0.0,min(0.16,0.8*m-0.06)),3) for n,m in MED.items()}
print('sound advance per person (s):',DELTA)
SHIFT={('r04_i00','Malavikka'):-0.05,('r04_i00','Ananya'):-0.04}      # recogniser-refined 'connect' onsets
src2n={UP+plans[n]['file']:n for n in plans}
lines=[l for l in open(ROOT+'/items.sh').read().split('\n') if 'xstack' in l and '/cold_' not in l]
cmds=[]
for l in lines:
    base=re.search(r'/items/(r\d\d_i\d\d)\.mp4',l).group(1)
    members=list(re.finditer(r'-ss ([\d.]+) -t ([\d.]+) -i "([^"]+)"',l.split('-loop')[0]))
    n=len(members); new=l; info=[]
    for k,m in enumerate(members):
        s,L,src=float(m.group(1)),float(m.group(2)),m.group(3); p=src2n[src]; d=DELTA[p]; sh=SHIFT.get((base,p),0.0)
        new=new.replace(m.group(0),f'-ss {s+sh:.3f} -t {L+0.17:.3f} -i "{src}"',1)
        new=new.replace(f'[{k}:v]fps=16,setpts=PTS-STARTPTS',f'[{k}:v]fps=16',1)       # no clock reset: keeps each panel's true frame timing
        # audio: take the sound d seconds later in the source so it meets the lips
        am=re.search(rf'\[{k}:a\]aresample=32000,aformat=channel_layouts=mono,atrim=([\d.]+):([\d.]+),asetpts=PTS-STARTPTS',new)
        a0,b0=float(am.group(1)),float(am.group(2))
        if f'adelay=' in new.split(f'[{k}:a]')[1].split(f'[a{k}]')[0]:                  # word-only (gated) merges: word plays d earlier
            new=new.replace(am.group(0),am.group(0),1)
            seg=new.split(f'[{k}:a]')[1].split(f'[a{k}]')[0]; ad=re.search(r'adelay=(\d+):all=1',seg); new=new.replace(seg,seg.replace(ad.group(0),f'adelay={max(0,int(int(ad.group(1))-d*1000))}:all=1'),1)
        else:
            new=new.replace(am.group(0),f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,atrim={a0+d:.3f}:{b0+d:.3f},asetpts=PTS-STARTPTS',1)
        info.append(f'{p} +{d*1000:.0f}ms')
    new=new.split(' || echo FAIL')[0]; cmds.append((base,new)); print(base,'|',', '.join(info),flush=True)
json.dump(cmds,open('/home/claude/final3/merge_cmds.json','w'))
for base,c in cmds:
    r=subprocess.run(f'cd /home/claude && {c}',shell=True,capture_output=True,text=True); print(base,'re-rendered' if not r.stderr.strip() else 'ERR '+r.stderr[-200:],flush=True)
