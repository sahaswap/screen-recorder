import sys,os,re,json,subprocess,time,numpy as np
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3')
from reedit_lib import *
from spans_all import words
sys.argv=['x']; exec(open('/home/claude/transcribe.py').read().split("if __name__")[0])
HINT={'Mohammed':13.3,'Riddhima':9.8,'Shobhita':7.8,'Ayush':6.9,'Irin':7.8,'Malavikka':8.8,'Ananya':15.0,'Arijit':7.4,'Monesh':26.4}
ORDER=['Mohammed','Riddhima','Shobhita','Ayush','Irin','Malavikka','Ananya','Arijit','Monesh']
def pcm(src,a0,dur):
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,a0):.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
    return np.frombuffer(raw,np.float32)
PAD=np.zeros(int(0.3*16000),np.float32)
def asr(x):
    st=rec.create_stream(); st.accept_waveform(16000,np.concatenate([PAD,x,PAD])); rec.decode_stream(st); return re.sub(r'[^a-z ]','',st.result.text.lower()).strip()
def ok(t): return t in ('deloitte','deloite','deloit','delight')   # recogniser spellings of the isolated word
out=[]
for n in ORDER:
    ws=words(n); idx=[i for i,w in enumerate(ws) if re.search('deloitte',w[0],re.I) and abs(orig_time(n,w[1])-HINT[n])<1.5][0]
    t0=orig_time(n,ws[idx][1]); t1=orig_time(n,ws[idx][2]); src=UP+plans[n]['file']; base=t0-0.9; x=pcm(src,base,(t1-t0)+2.0)
    S=lambda t:int((t-base)*16000); valid=[]; tm=time.time()
    for on in np.arange(t0-0.30,t0+0.46,0.05):
        for off in np.arange(t1-0.50,t1+0.31,0.05):
            if 0.30<=off-on<=1.15 and ok(asr(x[S(on):S(off)])): valid.append((round(on,2),round(off,2)))
    if valid:
        ons=sorted(set(v[0] for v in valid)); offs=sorted(set(v[1] for v in valid)); on=ons[len(ons)//2]; off=offs[len(offs)//2]
        # the range's middle, then verify with the small safety margins that will be used in the video
        chk=asr(x[S(on-0.04):S(off+0.05)])
    else: on,off,chk=t0,t1,'(none valid)'
    print(f"{n:10} transcript {t0:6.2f}-{t1:6.2f} | {len(valid):3d} valid cuts, start range {min([v[0] for v in valid],default=0):.2f}..{max([v[0] for v in valid],default=0):.2f} -> chosen {on:.2f}-{off:.2f} ({off-on:.2f}s) | with margins heard: '{chk}'  [{time.time()-tm:.0f}s]",flush=True)
    out.append(dict(n=n,src=src,on=float(on),off=float(off),valid=len(valid),heard=chk))
json.dump(out,open('/home/claude/final3/cold_words.json','w'))
