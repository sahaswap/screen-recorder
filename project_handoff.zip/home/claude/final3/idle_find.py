import sys,subprocess,numpy as np,cv2,json
sys.path.insert(0,'/home/claude')
from reedit_lib import UP,plans
from PIL import Image,ImageDraw
cas=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
FPS=16; W,H=320,180; out={}; ims=[]
for n in ('Malavikka','Ananya'):
    src=UP+plans[n]['file']; dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',src]).decode())
    boxes=[]
    for t in np.linspace(dur*0.12,dur*0.88,9):
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-ss',f'{t:.2f}','-i',src,'-frames:v','1','/home/claude/final3/lp.png'])
        g=cv2.cvtColor(cv2.imread('/home/claude/final3/lp.png'),cv2.COLOR_BGR2GRAY); fs=cas.detectMultiScale(g,1.08,5,minSize=(110,110),maxSize=(560,560))
        if len(fs): boxes.append(max(fs,key=lambda q:q[2]))
    x,y,w,h=[float(np.median([b[i] for b in boxes])) for i in range(4)]; s=W/1920
    mx0,mx1=int((x+0.2*w)*s),int((x+0.8*w)*s); my0,my1=int((y+0.6*h)*s),int(min(1080,(y+1.05*h))*s)
    # also the whole-face region: a listener holds still, a speaker's head and jaw both move
    fx0,fx1=int(x*s),int((x+w)*s); fy0,fy1=int(y*s),int((y+h)*s)
    p=subprocess.Popen(['ffmpeg','-nostdin','-v','error','-i',src,'-vf',f'fps={FPS},scale={W}:{H},format=gray','-f','rawvideo','-'],stdout=subprocess.PIPE)
    prev=None; mm=[]; fm=[]
    while True:
        b=p.stdout.read(W*H)
        if len(b)<W*H: break
        fr=np.frombuffer(b,np.uint8).reshape(H,W).astype(np.float32)
        if prev is None: mm.append(0.0); fm.append(0.0)
        else: mm.append(float(np.abs(fr[my0:my1,mx0:mx1]-prev[my0:my1,mx0:mx1]).mean())); fm.append(float(np.abs(fr[fy0:fy1,fx0:fx1]-prev[fy0:fy1,fx0:fx1]).mean()))
        prev=fr
    mm=np.array(mm); fm=np.array(fm); WL=int(3.4*FPS); best=None
    for i in range(int(15*FPS),len(mm)-WL-int(4*FPS),2):
        sc=mm[i:i+WL].mean()+0.5*mm[i:i+WL].max()+0.5*fm[i:i+WL].mean()
        if best is None or sc<best[0]: best=(sc,i/FPS)
    out[n]=dict(start=best[1],len=3.4,score=float(best[0]),typical=float(np.median([mm[i:i+WL].mean()+0.5*mm[i:i+WL].max()+0.5*fm[i:i+WL].mean() for i in range(int(15*FPS),len(mm)-WL,16)])))
    print(f"{n:10} stillest 3.4 s stretch starts at {best[1]:.1f}s (movement score {best[0]:.2f} vs typical {out[n]['typical']:.2f})",flush=True)
    for k,fr_ in enumerate((0.1,1.7,3.3)):
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-ss',f'{best[1]+fr_:.2f}','-i',src,'-frames:v','1','-vf','scale=480:-1','/home/claude/final3/g.png']); im=Image.open('/home/claude/final3/g.png').convert('RGB'); ImageDraw.Draw(im).text((6,4),f'{n} idle +{fr_}s',fill=(255,255,0)); ims.append(im)
json.dump(out,open('/home/claude/final3/idle_windows.json','w'))
w_,h_=ims[0].size; sh=Image.new('RGB',(w_*3,h_*2)); [sh.paste(im,((i%3)*w_,(i//3)*h_)) for i,im in enumerate(ims)]; sh.save('/home/claude/final3/idle_check.png')
