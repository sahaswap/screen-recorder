import sys; sys.path.insert(0,'/home/claude/final')
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import gfx_final as G
S=G.S; GREEN=G.GREEN; WHITE=G.WHITE; clamp=G.clamp; eo=G.eo; eio=G.eio; eback=G.eback
DOCK_X=560; DOCK_Y=968            # same spot in every round: just right of the name tag, bottom-aligned with it
def make_dock(text):
    for size in (34,32,30,28):
        f=G.FS(size); tw=f.getlength(text)/S; badge=58; W=30+badge+16+tw+34
        if DOCK_X+W<=1888: break
    H=78; x0=y0=24; RW=int(W+2*x0); RH=int(H+2*y0); box=(x0,y0,x0+W,y0+H); rad=H/2
    L=Image.new('RGBA',(RW*S,RH*S),(0,0,0,0))
    def mask(inf=0):
        m=Image.new('L',L.size,0); ImageDraw.Draw(m).rounded_rectangle([(box[0]-inf)*S,(box[1]-inf)*S,(box[2]+inf)*S,(box[3]+inf)*S],radius=(rad+inf)*S,fill=255); return m
    mi=mask(0); mo=mask(4); ring=Image.fromarray(np.clip(np.array(mo).astype(int)-np.array(mi).astype(int),0,255).astype(np.uint8))
    sh=Image.new('RGBA',L.size,(0,0,0,0)); sm=Image.new('L',L.size,0); sm.paste(mo,(4*S,7*S)); sh.putalpha(sm.point(lambda v:int(v*150/255))); L.alpha_composite(sh.filter(ImageFilter.GaussianBlur(6*S)))
    fill=Image.new('RGBA',L.size,(4,13,14,240)); fill.putalpha(Image.composite(fill.getchannel('A'),Image.new('L',L.size,0),mi)); L.alpha_composite(fill)
    ht=Image.new('RGBA',L.size,(0,0,0,0)); G.halftone(ht,box,GREEN,alpha=55,sp=12,rmax=3.0); ht.putalpha(Image.composite(ht.getchannel('A'),Image.new('L',L.size,0),mi)); L.alpha_composite(ht)
    gl=Image.new('RGBA',L.size,(0,0,0,0)); gl.paste(Image.new('RGBA',L.size,GREEN+(255,)),(0,0),ring); g2=gl.filter(ImageFilter.GaussianBlur(10*S)); g2.putalpha(g2.getchannel('A').point(lambda v:int(min(255,v*1.8)))); L.alpha_composite(g2); L.alpha_composite(gl)
    d=ImageDraw.Draw(L); cx=(x0+30+badge/2)*S; cy=(y0+H/2)*S; r=badge/2*S
    d.ellipse([cx-r-3*S,cy-r-3*S,cx+r+3*S,cy+r+3*S],fill=WHITE+(255,)); d.ellipse([cx-r,cy-r,cx+r,cy+r],fill=GREEN+(255,)); d.text((cx,cy+2*S),'?',font=G.FS(40),fill=WHITE+(255,),anchor='mm',stroke_width=int(1.5*S),stroke_fill=(20,60,10,255))
    x=(x0+30+badge+16)*S; y=(y0+H/2)*S; f=G.FS(size)
    d.text((x+2*S,y+3*S),text,font=f,fill=(0,0,0,170),stroke_width=int(2.5*S),stroke_fill=(0,0,0,170),anchor='lm'); d.text((x,y),text,font=f,fill=WHITE+(255,),stroke_width=int(2.5*S),stroke_fill=(5,8,8,255),anchor='lm')
    return L,dict(RW=RW,RH=RH,GX=DOCK_X-x0,GY=DOCK_Y-y0,cx=DOCK_X+W/2,cy=DOCK_Y+H/2,W=W,H=H)
def place_center(layerS,scale,center,alpha=1.0):
    sc=scale/S; L=layerS.resize((max(1,int(layerS.width*sc)),max(1,int(layerS.height*sc))),Image.LANCZOS)
    out=Image.new('RGBA',(1920,1080),(0,0,0,0)); out.paste(L,(int(center[0]-L.width/2),int(center[1]-L.height/2)))
    if alpha<0.999: out.putalpha(out.getchannel('A').point(lambda v:int(v*alpha)))
    return out
class DRound:
    def __init__(self,text,vo_len,bg,vo_t0=0.30,trans=0.70):
        self.text=text; self.g=G.make_geom(text,'below'); self.full=G.bubble_layer(self.g,len(text),1.0)
        self.vo_t0=vo_t0; self.vo_len=vo_len; self.Tf=round((vo_t0+vo_len+0.45)*48)/48; self.trans=trans; self.bg=bg
        self.fs=min(2.0,1500/self.g['W'],800/self.g['H']); self.dock,self.di=make_dock(text)
        self.dock_png=self.dock.resize((self.di['RW'],self.di['RH']),Image.LANCZOS)
    def flash(self,t):
        f=Image.new('RGBA',(1920,1080),(0,0,0,0)); f.alpha_composite(self.bg)
        if t>=0.15:
            pop=eback(clamp((t-0.15)/0.22),1.2); n=int(len(self.text)*clamp((t-self.vo_t0)/(0.92*self.vo_len)))
            L=G.bubble_layer(self.g,n,clamp((t-self.vo_t0-0.92*self.vo_len)/0.25)); f.alpha_composite(G.place(L,self.g,self.fs*max(pop,0.02),(960,540)))
        return f
    def transition(self,tt):
        """the big question card shrinks toward the bottom and turns into the docked bar while the background dissolves"""
        p=eio(clamp(tt/self.trans)); a=1-eo(clamp(tt/(self.trans-0.1))); f=Image.new('RGBA',(1920,1080),(0,0,0,0))
        if a>0.003: s=self.bg.copy(); s.putalpha(int(255*a)); f.alpha_composite(s)
        fa=1-clamp((p-0.15)/0.5); da=clamp((p-0.40)/0.5)
        if fa>0.003:
            sc=self.fs+(0.55-self.fs)*p; cen=(960+(self.di['cx']-960)*p,540+(self.di['cy']-540)*p); f.alpha_composite(G.place(self.full,self.g,sc,cen,fa))
        if da>0.003: f.alpha_composite(place_center(self.dock,0.88+0.12*eo(da),(self.di['cx'],self.di['cy']),da))
        return f
