import sys,os,json,math,subprocess
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final3')
from reedit_lib import *
from PIL import Image,ImageDraw,ImageFont
import numpy as np
ROOT='/home/claude/final3/w'; SPD=1.2
W_=json.load(open('/home/claude/final3/cold_words.json')); R_=json.load(open('/home/claude/final3/cold_words_r.json'))[0]
for i,w in enumerate(W_):
    if w['n']=='Riddhima': W_[i]=R_
    if w['n']=='Ayush': w['on'],w['off']=6.97,7.55
ms=[dict(n=w['n'],src=w['src'],on=w['on'],dur=w['off']-w['on']) for w in W_]
PRE=0.18; L=PRE+max(m['dur'] for m in ms)+0.22; D=L/SPD; n=len(ms)
FNT='/home/claude/fonts_ttf/OpenSans-Bold.ttf'
rows=[[(0,0),(640,0),(1280,0)],[(0,360),(640,360),(1280,360)],[(0,720),(640,720),(1280,720)]]; rects=[(x,y,640,360) for r in rows for x,y in r]
im=Image.new('RGBA',(1920,1080),(0,0,0,0)); d=ImageDraw.Draw(im); f=ImageFont.truetype(FNT,20)
for m,(x,y,w,h) in zip(ms,rects):
    grad=np.zeros((90,w,4),np.uint8); grad[...,3]=(np.linspace(0,150,90)[:,None]*np.ones((1,w))).astype(np.uint8); im.alpha_composite(Image.fromarray(grad,'RGBA'),(x,y+h-90))
    ty=y+h-28; d.ellipse([x+14,ty-6,x+26,ty+6],fill=(134,188,37,255)); d.text((x+36,ty),m['n'],font=f,fill=(255,255,255,255),anchor='lm',stroke_width=1,stroke_fill=(0,0,0,200))
lab=f'{ROOT}/lab/cold_single.png'; im.save(lab)
inputs=' '.join(f'-ss {m["on"]-PRE:.3f} -t {L:.3f} -i "{m["src"]}"' for m in ms)+f' -loop 1 -framerate 48 -t {D:.3f} -i {lab} -loop 1 -framerate 48 -t {D:.3f} -i /home/claude/mont/re/logo.png'
fv=''
for k,m in enumerate(ms):
    bx=BOX[m['n']]; fv+=f'[{k}:v]fps=16,setpts=PTS-STARTPTS,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},scale=640:360:flags=lanczos,setsar=1,format=yuv420p[p{k}];'
lay='|'.join(f'{x}_{y}' for x,y,w,h in rects); fv+=''.join(f'[p{k}]' for k in range(n))+f'xstack=inputs={n}:layout={lay}:fill=0x050e0f[st];[st]setpts=PTS/{SPD},fps=48,format=yuv420p[a];'
fv+=f'[{n}:v]format=rgba,fade=t=in:st=0.03:d=0.15:alpha=1[lb];[a][lb]overlay=0:0:shortest=1[b0];[{n+1}:v]format=rgba[lg];[b0][lg]overlay=40:25:shortest=1[v]'
att=-3*math.log2(n); fa=''
for k,m in enumerate(ms):
    g=max(-12,min(15,-18.5-vol(m['src'],m['on'],m['dur'],'mean_volume')))+att; a0=PRE; b0=PRE+m['dur']
    fa+=f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,atrim={a0:.3f}:{b0:.3f},asetpts=PTS-STARTPTS,volume={g:.2f}dB,afade=t=in:st=0:d=0.012,afade=t=out:st={b0-a0-0.02:.3f}:d=0.02,adelay={int(a0*1000)}:all=1,apad=whole_dur={L:.3f},atrim=0:{L:.3f}[a{k}];'
fa+=''.join(f'[a{k}]' for k in range(n))+f'amix=inputs={n}:normalize=0,afade=t=out:st={L-0.07:.3f}:d=0.07,atempo={SPD},alimiter=limit=0.89,apad=whole_dur={D:.3f},atrim=0:{D:.3f}[a]'
base=f'{ROOT}/items/cold_i00'
cmd=(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{fv};{fa}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 19 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4 -map "[a]" -t {D:.3f} -c:a pcm_s16le -ar 32000 -ac 1 {base}.wav')
r=subprocess.run(cmd,shell=True,capture_output=True,text=True); print('opening encode:',r.stderr[-300:] or 'ok','| single hit length %.2fs'%D)
P=json.load(open(ROOT+'/plan.json')); cold=[s for s in P['segs'] if s['round']<0]; P['segs']=[s for s in P['segs'] if s['round']>=0]; P['segs'].insert(0,cold[0]); cold[0]['text']='(merge: Deloitte, single hit)'
json.dump(P,open(ROOT+'/plan.json','w')); print('opening segments now:',len([s for s in P['segs'] if s['round']<0]))
for ext in ('mp4','wav'):
    p=f'{ROOT}/items/cold_i01.{ext}'
    if os.path.exists(p): os.remove(p)
