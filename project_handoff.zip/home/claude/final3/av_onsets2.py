import sys,subprocess,numpy as np,cv2,json
sys.path.insert(0,'/home/claude')
from reedit_lib import UP,plans
cas=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
FPS=16; W,H=320,180
def run(n):
    src=UP+plans[n]['file']; dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',src]).decode())
    boxes=[]
    for t in np.linspace(dur*0.12,dur*0.88,9):
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-ss',f'{t:.2f}','-i',src,'-frames:v','1','/home/claude/final3/lp.png'])
        g=cv2.cvtColor(cv2.imread('/home/claude/final3/lp.png'),cv2.COLOR_BGR2GRAY); fs=cas.detectMultiScale(g,1.08,5,minSize=(110,110),maxSize=(560,560))
        if len(fs): boxes.append(max(fs,key=lambda q:q[2]))
    if not boxes: return None
    x,y,w,h=[float(np.median([b[i] for b in boxes])) for i in range(4)]; s=W/1920
    mx0,mx1=int((x+0.2*w)*s),int((x+0.8*w)*s); my0,my1=int((y+0.62*h)*s),int(min(1080,(y+1.05*h))*s)
    p=subprocess.Popen(['ffmpeg','-nostdin','-v','error','-i',src,'-vf',f'fps={FPS},scale={W}:{H},format=gray','-f','rawvideo','-'],stdout=subprocess.PIPE)
    prev=None; mot=[]
    while True:
        b=p.stdout.read(W*H)
        if len(b)<W*H: break
        f=np.frombuffer(b,np.uint8).reshape(H,W).astype(np.float32)[my0:my1,mx0:mx1]; mot.append(0.0 if prev is None else float(np.abs(f-prev).mean())); prev=f
    mot=np.array(mot); raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-i',src,'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
    a=np.frombuffer(raw,np.float32); step=160; env=np.array([np.sqrt((a[k:k+step]**2).mean()) for k in range(0,len(a)-step,step)]); 
    envdb=20*np.log10(env+1e-7); thr=np.percentile(envdb,50)+6; speech=envdb>thr
    ms=np.convolve(mot,np.ones(2)/2,'same'); base=np.median(ms); sd=np.std(ms)
    deltas=[]
    k=40
    while k<len(speech)-40:
        if speech[k] and not speech[k-35:k].any():            # speech starts after >=0.35 s of quiet
            t_a=k/100.0; i0=int((t_a-0.6)*FPS); i1=int((t_a+0.6)*FPS)
            seg=ms[max(0,i0):i1]; 
            if len(seg)>6 and seg.max()>base+2.0*sd:
                idx=np.where(seg>base+1.2*sd)[0]
                # first frame of the rise that leads to the peak
                pk=int(np.argmax(seg)); j=idx[idx<=pk]; j=j[0] if len(j) else pk
                deltas.append((max(0,i0)+j)/FPS-t_a)
            k+=60
        else: k+=1
    d=np.array(deltas); return dict(n_events=len(d),median=float(np.median(d)) if len(d) else None,q25=float(np.percentile(d,25)) if len(d) else None,q75=float(np.percentile(d,75)) if len(d) else None)
out={}
for n in ['Ayush','Shobhita','Riddhima','Arijit']:
    r=run(n); out[n]=r
    print(n,'no face found' if r is None else f"{r['n_events']} speech onsets | mouth starts moving {r['median']*1000:+.0f} ms after the audio starts (middle half of events {r['q25']*1000:+.0f}..{r['q75']*1000:+.0f} ms)",flush=True)
json.dump(out,open('/home/claude/final3/av_onsets2.json','w'))
