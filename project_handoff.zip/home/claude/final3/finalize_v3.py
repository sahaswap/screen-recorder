import sys,os,json,subprocess,wave
import numpy as np
from scipy.signal import butter,lfilter
ROOT='/home/claude/final3/w'; SR=32000; FPS=48
P=json.load(open(ROOT+'/plan.json')); segs=P['segs']; rounds=P['rounds']
def vframes(p):
    d=float(subprocess.check_output(['ffprobe','-v','error','-select_streams','v','-show_entries','stream=duration','-of','csv=p=0',p]).decode().split()[0]); return int(round(d*FPS))
pos=0; rstart={}
for s in segs:
    n=vframes(s['video']); s['frames']=n; s['start']=pos; pos+=n
    if s['type']=='flash': rstart[s['round']]=s['start']
total=pos; print('segments',len(segs),'total frames',total,'= %.2fs'%(total/FPS))
open(ROOT+'/list.txt','w').write(''.join(f"file '{s['video']}'\n" for s in segs))
subprocess.run(['ffmpeg','-y','-nostdin','-v','error','-f','concat','-safe','0','-i',ROOT+'/list.txt','-c','copy',ROOT+'/base.mp4'],check=True)
print('joined video frames',vframes(ROOT+'/base.mp4'),'(expected',total,')')
def rd(p):
    with wave.open(p) as f: return np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
N=int(round(total/FPS*SR)); speech=np.zeros(N+SR,np.float32); vo=np.zeros_like(speech); sfx=np.zeros_like(speech)
def act_rms(x):
    m=np.abs(x)>0.015; return float(np.sqrt((x[m]**2).mean())) if m.sum()>2000 else None
single_r=[act_rms(rd(s['audio'])) for s in segs if s['type']=='single']; target=float(np.median([r for r in single_r if r]))
print('typical speech level %.1f dB (active RMS); singles are evened to it (max +/-5 dB)'%(20*np.log10(target)))
for s in segs:
    if s['type']=='flash': continue
    a=rd(s['audio']); L=int(round(s['frames']/FPS*SR)); a=a[:L]
    if s['type']=='single':
        r=act_rms(a)
        if r: g=float(np.clip(target/r,10**(-5/20),10**(5/20))); a=np.clip(a*g,-0.97,0.97); s['adj']=round(20*np.log10(g),1)
    st=int(round(s['start']/FPS*SR)); speech[st:st+len(a)]+=a
print('level adjustments (dB):',{f"{s['who']}@{s['start']/48:.0f}s":s['adj'] for s in segs if s.get('adj') and abs(s['adj'])>=1.5})
def blip(f0,f1,dur,amp):
    n=int(dur*SR); t=np.arange(n)/SR; f=f0+(f1-f0)*t/dur; return (amp*np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*9)).astype(np.float32)
def put(buf,x,t): s=int(t*SR); buf[s:s+len(x)]+=x[:max(0,len(buf)-s)]
rng=np.random.default_rng(5)
for ri,R in enumerate(rounds):
    t0=rstart[ri]/FPS; y=np.load(f'{ROOT}/vo/r{ri:02d}.npy').copy()*0.60; e=int(0.01*SR); y[:e]*=np.linspace(0,1,e); y[-e:]*=np.linspace(1,0,e)
    put(vo,y,t0+R['vo_t0'])                                   # (bubble pop sound removed)
    # (bubble swoosh removed)
if 'opening' in P:
    Bt=P['opening']['beats']; BEAT=P['opening']['beat']
    bw=rd(ROOT+'/brand.wav'); vo[:len(bw)]+=bw[:len(vo)]          # 'Deloitte' said by the team as the wordmark pops (also ducks the music)
    def thump():
        n=int(0.45*SR); t=np.arange(n)/SR; f=46+70*np.exp(-t*32); return (0.38*np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*8)).astype(np.float32)
    for k in (1,2,3): put(sfx,thump(),Bt[k])
    n=int(0.55*SR); sh=np.diff(rng.standard_normal(n),prepend=0)*np.hanning(n)*0.035; put(sfx,sh.astype(np.float32),Bt[3])
    n=int((P['opening']['T']-Bt[4])*SR); ws=rng.standard_normal(n); ws=np.convolve(ws,np.ones(40)/40,'same'); put(sfx,(ws*np.linspace(0,1,n)**1.6*0.11).astype(np.float32),Bt[4])
# music: original upbeat track, ducked under any speech
with wave.open('/home/claude/final3/music.wav') as f: mus=np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
mus=np.resize(mus,N+SR)*10**(-9/20)*0.5      # background music at 50%
sp=np.abs(speech+vo); k=np.ones(int(0.06*SR))/int(0.06*SR); env=np.convolve(sp,k,'same'); duck=np.clip(env/0.03,0,1)
b,a=butter(1,6/(SR/2)); duck=lfilter(b,a,duck).astype(np.float32); b2,a2=butter(1,2.5/(SR/2)); duck=np.maximum(duck,lfilter(b2,a2,duck).astype(np.float32))
mus*=(1-0.6*duck)
mix=(speech+vo+mus+sfx)[:N]; fo=int(1.5*SR); mix[-fo:]*=np.linspace(1,0,fo); mix=np.clip(mix/max(1.0,np.abs(mix).max()*1.02),-1,1)
with wave.open(ROOT+'/audio.wav','wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR); f.writeframes((mix*32767).astype(np.int16).tobytes())
subprocess.run(['ffmpeg','-y','-nostdin','-v','error','-i',ROOT+'/base.mp4','-i',ROOT+'/audio.wav','-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','160k','-ar','32000','-ac','1','-movflags','+faststart',ROOT+'/final.mp4'],check=True)
json.dump(dict(rstart=rstart,segs=[{k:v for k,v in s.items() if k in ('round','type','who','start','frames','text')} for s in segs],total=total),open(ROOT+'/timeline.json','w'))
print('FINAL_DONE')
