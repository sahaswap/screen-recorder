import sys,json,math,subprocess
sys.path.insert(0,'/home/claude')
from reedit_lib import vol
BEAT=60/118; ONSET=BEAT*2            # 'Deloitte' lands when the pulse starts (beat 2)
W={w['n']:w for w in json.load(open('/home/claude/final3/cold_words.json'))}
use=['Mohammed','Shobhita','Irin','Arijit']; att=-3*math.log2(len(use)); inputs=''; fa=''
for k,n in enumerate(use):
    w=W[n]; d=w['off']-w['on']; inputs+=f' -ss {w["on"]:.3f} -t {d:.3f} -i "{w["src"]}"'
    g=max(-12,min(15,-18.5-vol(w['src'],w['on'],d,'mean_volume')))+att+2.0
    fa+=f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,volume={g:.2f}dB,afade=t=in:st=0:d=0.012,afade=t=out:st={d-0.02:.3f}:d=0.02,adelay={int(ONSET*1000)}:all=1[a{k}];'
fa+=''.join(f'[a{k}]' for k in range(len(use)))+f'amix=inputs={len(use)}:normalize=0,alimiter=limit=0.89,apad=whole_dur=1.8,atrim=0:1.8[a]'
r=subprocess.run(f'ffmpeg -y -nostdin -v error{inputs} -filter_complex "{fa}" -map "[a]" -c:a pcm_s16le -ar 32000 -ac 1 /home/claude/final3/w/brand.wav',shell=True,capture_output=True,text=True)
print('brand audio:',r.stderr[-200:] or 'ok','| voices:',use,'| lands at %.3fs'%ONSET)
