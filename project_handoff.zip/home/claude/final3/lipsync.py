import sys,subprocess,numpy as np,cv2,json
sys.path.insert(0,'/home/claude')
from reedit_lib import UP,plans
cas=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
FPS=16; W,H=320,180
def measure(n):
    src=UP+plans[n]['file']
    dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',src]).decode())
    boxes=[]
    for t in np.linspace(dur*0.15,dur*0.85,7):
        subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-ss',f'{t:.2f}','-i',src,'-frames:v','1','/home/claude/final3/lp.png'])
        g=cv2.cvtColor(cv2.imread('/home/claude/final3/lp.png'),cv2.COLOR_BGR2GRAY); fs=cas.detectMultiScale(g,1.08,6,minSize=(110,110),maxSize=(520,520))
        if len(fs): boxes.append(max(fs,key=lambda q:q[2]))
    if not boxes: return None
    x,y,w,h=[float(np.median([b[i] for b in boxes])) for i in range(4)]; s=W/1920
    mx0,mx1=int((x+0.22*w)*s),int((x+0.78*w)*s); my0,my1=int((y+0.64*h)*s),int(min(1080,(y+1.02*h))*s)
    p=subprocess.Popen(['ffmpeg','-nostdin','-v','error','-i',src,'-vf',f'fps={FPS},scale={W}:{H},format=gray','-f','rawvideo','-'],stdout=subprocess.PIPE)
    prev=None; mot=[]
    while True:
        b=p.stdout.read(W*H)
        if len(b)<W*H: break
        f=np.frombuffer(b,np.uint8).reshape(H,W).astype(np.float32)[my0:my1,mx0:mx1]
        mot.append(0.0 if prev is None else float(np.abs(f-prev).mean())); prev=f
    mot=np.array(mot)
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-i',src,'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
    a=np.frombuffer(raw,np.float32); n_=min(len(mot),len(a)//1000); env=np.array([np.sqrt((a[int(k*1000):int((k+1)*1000)]**2).mean()) for k in range(n_)]); mot=mot[:n_]
    def z(v): v=v-np.convolve(v,np.ones(9)/9,'same'); return (v-v.mean())/(v.std()+1e-9)
    m=z(mot); e=z(env); lags=range(-12,13); res=[]
    for L in lags:
        if L>=0: r=np.corrcoef(m[:len(m)-L],e[L:])[0,1]
        else: r=np.corrcoef(m[-L:],e[:len(e)+L])[0,1]
        res.append(r)
    res=np.array(res); k=int(np.argmax(res)); 
    if 0<k<len(res)-1: den=res[k-1]-2*res[k]+res[k+1]; off=0.5*(res[k-1]-res[k+1])/den if abs(den)>1e-9 else 0.0
    else: off=0.0
    return dict(lag_s=(list(lags)[k]+off)/FPS,peak=float(res[k]),zero=float(res[12]),second=float(np.sort(res)[-2]))
out={}
for n in ['Ananya','Arijit','Ayush','Irin','Malavikka','Mohammed','Monesh','Riddhima','Shobhita']:
    r=measure(n); out[n]=r
    print(f"{n:10} " + ("no face" if r is None else f"audio-vs-picture offset {r['lag_s']*1000:+5.0f} ms (peak corr {r['peak']:.2f}, at zero {r['zero']:.2f})"),flush=True)
json.dump(out,open('/home/claude/final3/lipsync.json','w'))
