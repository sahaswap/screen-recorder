import sys,os,re,json,subprocess,math,numpy as np
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final'); sys.path.insert(0,'/home/claude/final3')
from reedit_lib import *
from spans_all import words
from PIL import Image,ImageDraw,ImageFont
sys.argv=['x']; exec(open('/home/claude/transcribe.py').read().split("if __name__")[0])
ROOT='/home/claude/final3/w'; SPD=1.2
HINT={'Mohammed':13.3,'Riddhima':9.8,'Shobhita':7.8,'Ayush':6.9,'Irin':7.8,'Malavikka':8.8,'Ananya':15.0,'Arijit':7.4,'Monesh':26.4}
ORDER=['Mohammed','Riddhima','Shobhita','Ayush','Irin','Malavikka','Ananya','Arijit','Monesh']
def pcm(src,a0,dur):
    raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f'{max(0,a0):.3f}','-t',f'{dur:.3f}','-i',src,'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
    return np.frombuffer(raw,np.float32)
def asr(x):
    pad=np.zeros(int(0.25*16000),np.float32); x=np.concatenate([pad,x,pad]); st=rec.create_stream(); st.accept_waveform(16000,x); rec.decode_stream(st); return st.result.text.strip()
M=[]
for n in ORDER:
    ws=words(n); idx=[i for i,w in enumerate(ws) if re.search('deloitte',w[0],re.I) and abs(orig_time(n,w[1])-HINT[n])<1.5][0]
    t0=orig_time(n,ws[idx][1]); t1=orig_time(n,ws[idx][2]); src=UP+plans[n]['file']
    base=t0-0.6; x=pcm(src,base,(t1-t0)+1.2); fr=160; env=np.array([20*np.log10(np.sqrt((x[k:k+fr]**2).mean())+1e-7) for k in range(0,len(x)-fr,fr)])
    tt=base+np.arange(len(env))*0.01; sel=np.where((tt>=t0-0.02)&(tt<=t1+0.02))[0]; kpk=sel[np.argmax(env[sel])]; thr=env[kpk]-26
    k=kpk
    while k>0 and env[k-1]>thr and tt[k-1]>=t0-0.30: k-=1
    on=tt[k]-0.03
    k=kpk
    while k<len(env)-1 and env[k+1]>thr and tt[k+1]<=t1+0.10: k+=1
    off=tt[k]+0.05
    # does this cut contain exactly the word?  recognise it on its own
    heard=asr(pcm(src,on-0.02,(off-on)+0.04))
    M.append(dict(n=n,src=src,on=on,off=off,dur=off-on,asr_t=(t0,t1),heard=heard))
    print(f"{n:10} transcript word {t0:6.2f}-{t1:6.2f}  ->  refined {on:6.2f}-{off:6.2f} ({off-on:.2f}s)  heard alone: '{heard}'",flush=True)
json.dump(M,open('/home/claude/final3/cold_words.json','w'))
