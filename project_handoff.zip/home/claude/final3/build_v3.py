import sys,os,json,shutil,subprocess,math,wave,re,importlib.util
sys.path.insert(0,'/home/claude'); sys.path.insert(0,'/home/claude/final'); sys.path.insert(0,'/home/claude/final3'); sys.path.insert(0,'/home/claude/tts')
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
from reedit_lib import *
from spans_all import locate,words
import gfx_final as G, gfx_v3 as V
SPD=1.2; SR=32000
ROOT='/home/claude/final3/w'; shutil.rmtree(ROOT,ignore_errors=True)
for d in ('items','seq','vo','trans','reg','lab','prev'): os.makedirs(f'{ROOT}/{d}')
CHORUS_W='/home/claude/mont/re/items/38_Mohammed+Ayush.mp4'; CHORUS_Z='/home/claude/mont/re3/items/101_Ananya+Malavikka.mp4'
def S(n,sp,ep,**o): return dict(kind='single',n=n,sp=sp,ep=ep,o=o)
def CH(path,who,frames): return dict(kind='chorus',path=path,who=who,frames=frames)
def MG(label,members,pre_max=0.8,post_max=0.55,gate=False): return dict(kind='merge',label=label,members=members,pre_max=pre_max,post_max=post_max,gate=gate)
def M(n,anchor,kw,hint=None): return dict(n=n,anchor=anchor,kw=kw,hint=hint)
COLD=[MG('Deloitte',[M('Mohammed',None,'Deloitte',13.3),M('Riddhima',None,'Deloitte',9.8),M('Shobhita',None,'Deloitte',7.8),M('Ayush',None,'Deloitte',6.9),M('Irin',None,'Deloitte',7.8),
                     M('Malavikka',None,'Deloitte',8.8),M('Ananya',None,'Deloitte',15.0),M('Arijit',None,'Deloitte',7.4),M('Monesh',None,'Deloitte',26.4)],pre_max=0.2,post_max=0.2,gate=True),
      MG('Deloitte2',[M('Mohammed',None,'Deloitte',38.1),M('Riddhima',None,'Deloitte',76.4),M('Shobhita',None,'Deloitte',19.0),M('Ayush',None,'Deloitte',6.9),M('Irin',None,'Deloitte',19.2),
                     M('Malavikka',None,'Deloitte',28.6),M('Ananya',None,'Deloitte',26.9),M('Arijit',None,'Deloitte',43.3),M('Monesh',None,'Deloitte',41.7)],pre_max=0.2,post_max=0.2,gate=True)]
ROUNDS=[
 ("Introduce yourself in 3 words","Introduce yourself in three words.",[MG('curious',[M('Mohammed','I am curious proactive','curious'),M('Riddhima','I am curious thoughtful','curious'),M('Shobhita','ambitious adaptable','curious'),M('Ayush','curious adventurous','curious'),M('Arijit','calm passionate','curious')],pre_max=0.2,post_max=0.2,gate=True),
    S('Malavikka','quiet caring','ambitious')]),
 ("What's something you're unexpectedly good at?","What is something you're unexpectedly good at?",[S('Ananya','I can read minds','read minds'),S('Irin','making Excel do magic','do magic'),S('Arijit','I like to cook Italian','made the best',end_at=63.50)]),
 ("What's your hidden talent?","What is your hidden talent?",[MG('dancing',[M('Malavikka',"I'd say dancing",'dancing'),M('Irin','I can dance to any song','dance'),M('Ananya','I love dancing','dancing')],pre_max=0.2,post_max=0.2,gate=True),
    S('Ananya','I would proudly say','overthinker'),S('Riddhima','very efficient at packing','able to do that')]),
 ("What's one thing your new team should know about you?","What is one thing your new team should know about you?",[S('Irin','If I say I will do it',"I'll do it"),S('Arijit','terrified about spiders','bit fun'),S('Riddhima',"I'm always up to learn something new",'feeling down'),S('Monesh','I always get my deliverables done','hook or crook')]),
 ("What's the most common phrase you heard after joining?","What is the most common phrase you heard after joining?",[MG('connect',[M('Malavikka',"let's connect",'connect'),M('Ananya','that quick connect never ends','connect')]),
    S('Irin','Did you fill your timesheet','timesheet'),S('Mohammed','networking networking and more networking','official Deloitte skill')]),
 ("Describe your project in 1 word","Describe your project in one word.",[MG('dynamic',[M('Malavikka',"I think it's dynamic",'dynamic'),M('Mohammed','I would say my project is dynamic','dynamic')]),
    MG('detective',[M('Irin','My project in one word','detectives'),M('Ananya','more like a detective work','detective')]),
    S('Ayush','Intriguing','Intriguing'),S('Riddhima','to describe my project in one word','interesting and unique'),S('Arijit',"I would say it's awesome",'awesome'),S('Monesh','comprehensive challenging','analyze and report')]),
 ("What surprised you about your first week?","What surprised you about your first week?",[S('Ananya','so many passwords','remember them all'),S('Ayush','how many people are genuinely willing','settle in')]),
 ("What's one word you'd use to describe your new team?","What is one word you'd use to describe your new team?",[MG('welcoming',[M('Mohammed','I would say welcoming','welcoming'),M('Ayush','Welcoming','welcoming')],post_max=0.4),S('Arijit','that I used synergistic','completely synergistic'),S('Monesh','financial superheroes','terrorist financing')]),
 ("If your life had a theme song, what would it be?","If your life had a theme song, what would it be?",[MG('zindagi',[M('Ananya','Love You Zindagi','Love You Zindagi'),M('Malavikka','Love You Zindagi','Love You Zindagi')],pre_max=0.6,post_max=0.4),S('Irin','My theme song would be 7 Rings by Ariana','7 Rings by Ariana'),S('Riddhima','Wake Up Sid',"hustle I'm facing",complete=False),S('Shobhita',"Shin Chan's theme song",'get things done'),S('Ayush','The Nights by Avicii','gets better'),S('Monesh','life is like Kabhi Khushi Kabhie Gham','ups and downs'),S('Arijit',"Don't Stop Me Now by Queen",'by Queen',final=True)]),
]
log=open(ROOT+'/stageA.log','w')
def say(*a):
    print(*a,flush=True); log.write(' '.join(str(x) for x in a)+'\n'); log.flush()
# ---------- voice-overs: Emma, slower
_sp=importlib.util.spec_from_file_location('ttsgen','/home/claude/tts/gen.py'); gen=importlib.util.module_from_spec(_sp); _sp.loader.exec_module(gen)
import wave as _w
VO={}
for ri,(txt,spoken,_) in enumerate(ROUNDS):
    raw=f'{ROOT}/vo/r{ri:02d}_raw.wav'; gen.say(spoken,20,0.92,raw)
    with _w.open(raw) as f: x=np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
    idx=np.where(np.abs(x)>0.012)[0]; a0=max(0,idx[0]-int(0.03*24000)); a1=min(len(x),idx[-1]+int(0.06*24000)); x=x[a0:a1]
    with _w.open(f'{ROOT}/vo/r{ri:02d}_trim.wav','wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(24000); f.writeframes((x*32767).astype(np.int16).tobytes())
    subprocess.run(['ffmpeg','-y','-nostdin','-v','error','-i',f'{ROOT}/vo/r{ri:02d}_trim.wav','-af','highpass=f=80,acompressor=threshold=-22dB:ratio=3:attack=4:release=70:makeup=3,alimiter=limit=0.9','-ar',str(SR),'-ac','1',f'{ROOT}/vo/r{ri:02d}_32k.wav'])
    with _w.open(f'{ROOT}/vo/r{ri:02d}_32k.wav') as f: y=np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
    y*=10**(-20.4/20)/(np.sqrt((y**2).mean())+1e-9); y*=min(1.0,0.95/(np.abs(y).max()+1e-9)); VO[ri]=y; np.save(f'{ROOT}/vo/r{ri:02d}.npy',y); say(f'VO {ri+1}: {len(y)/SR:.2f}s "{spoken}"')
# ---------- resolve every item (durations are after the 1.2x speed-up)
def vlen_of(c):
    L=c['real_end']-c['ss']
    if c['sq']: L=L-(c['sq'][1]-c['sq'][0])+0.45
    return L
def resolve_member(m,pre_cap):
    n=m['n']; ws=words(n)
    if m['anchor'] is None:
        idx=[i for i,w in enumerate(ws) if re.search(m['kw'],w[0],re.I) and abs(orig_time(n,w[1])-m['hint'])<1.5]; ka=kb=idx[0]; a=max(0,ka-2)
    else: a,_=locate(ws,m['anchor']); ka,kb=locate(ws,m['kw'],a)
    t0=orig_time(n,ws[ka][1]); t1=orig_time(n,ws[kb][2]); w0=orig_time(n,ws[a][1]); prev_end=orig_time(n,ws[a-1][2]) if a>0 else None
    lead=0.25 if prev_end is None else max(0.05,min(0.25,w0-prev_end-0.04)); nxt=orig_time(n,ws[kb+1][1]) if kb+1<len(ws) else None
    return dict(n=n,src=UP+plans[n]['file'],t0=t0,t1=t1,avail=t0-(w0-lead),post_avail=(0.6 if nxt is None else max(0.06,min(0.6,nxt-t1-0.02))))
def resolve(it):
    if it['kind']=='single':
        o=it['o']; c=clip_def(it['n'],it['sp'],it['ep'],complete=o.get('complete',True)); c['real_end']=c['end']; c['freeze']=0.0; ext=0.0
        if o.get('end_at'): c['end']=c['real_end']=o['end_at']
        if o.get('final'):
            ls,Lis=192.4,2.25; it['idle']=(ls,Lis); ext=Lis-0.25
        it['c']=c; it['raw']=vlen_of(c)+ext; it['dur']=it['raw']/SPD; it['persons']=[it['n']]
    elif it['kind']=='chorus': it['raw']=it['frames']/48; it['dur']=it['raw']/SPD; it['persons']=it['who']
    else:
        ms=[resolve_member(m,it['pre_max']) for m in it['members']]; PRE=min(it['pre_max'],max(0.12,min(m['avail'] for m in ms)))
        for m in ms: m['post']=min(it['post_max'],m['post_avail']); m['kwdur']=m['t1']-m['t0']; m['s']=m['t0']-PRE
        E=[PRE+m['kwdur']+m['post'] for m in ms]; Wd=[PRE+m['kwdur'] for m in ms]; L=max(max(Wd)+0.12,min(E)); L=min(L,max(E)); it['ms']=ms; it['PRE']=PRE; it['L']=L; it['raw']=L; it['dur']=L/SPD; it['persons']=[m['n'] for m in ms]
for it in COLD: resolve(it)
for r in ROUNDS:
    for it in r[2]: resolve(it)
def add_tail(it):
    c=it['c']; n=c['n']; ws=words(n); nxt=None
    for w in ws:
        t=orig_time(n,w[1])
        if t>c['end']-0.05: nxt=t; break
    tl=0.7 if nxt is None else min(0.7,nxt-c['end']-0.15)
    if tl>=0.2:
        raw=subprocess.run(['ffmpeg','-nostdin','-v','error','-ss',f"{c['end']:.3f}",'-t',f'{tl:.3f}','-i',c['src'],'-vn','-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
        x=np.frombuffer(raw,np.float32)
        for k in range(0,len(x)-1600,1600):
            if np.sqrt((x[k:k+1600]**2).mean())>10**(-38/20): tl=max(0.0,k/16000-0.05); break
    if tl>=0.2: c['real_end']=c['end']+tl; it['raw']=vlen_of(c)+(it['raw']-vlen_of({**c,'real_end':c['end']})); it['dur']=it['raw']/SPD; it['tail']=round(tl,2)
for r in ROUNDS:
    last=r[2][-1]
    if last['kind']=='single' and not last['o'].get('final') and not last['o'].get('end_at'): add_tail(last)
bg=Image.open('/home/claude/mont/pause_bg.png').convert('RGBA')
R=[V.DRound(txt,len(VO[i])/SR,bg) for i,(txt,_,_) in enumerate(ROUNDS)]
tot=sum(round(it['dur']*48)/48 for it in COLD)+sum(rr.Tf for rr in R)+sum(round(it['dur']*48)/48 for r in ROUNDS for it in r[2])
say('estimated total length: %.1fs (%d:%02d)'%(tot,tot//60,tot%60))
for it in COLD+[i for r in ROUNDS for i in r[2]]:
    say(f"  {it['kind']:7} {'+'.join(it['persons'])[:40]:40} {it['dur']:5.2f}s")
# ---------- helpers for panels and labels
FNT='/home/claude/fonts_ttf/OpenSans-Bold.ttf'
def panels(n):
    if n==2: return dict(rects=[(0,0,960,1080),(960,0,960,1080)],crop=(480,0,960,1080),scale=None,size=34)
    if n==3: return dict(rects=[(0,0,640,1080),(640,0,640,1080),(1280,0,640,1080)],crop=(640,0,640,1080),scale=None,size=28)
    if n==4: return dict(rects=[(0,0,960,540),(960,0,960,540),(0,540,960,540),(960,540,960,540)],crop=(240,40,1440,810),scale=(960,540),size=26)
    if n in (5,6):
        top=[(0,0,640,540),(640,0,640,540),(1280,0,640,540)]; bot=[(320,540,640,540),(960,540,640,540)] if n==5 else [(0,540,640,540),(640,540,640,540),(1280,540,640,540)]
        return dict(rects=top+bot,crop=(480,40,960,810),scale=(640,540),size=24)
    rows=[[(0,0),(640,0),(1280,0)],[(0,360),(640,360),(1280,360)]]; last={7:[(640,720)],8:[(320,720),(960,720)],9:[(0,720),(640,720),(1280,720)]}[n]
    return dict(rects=[(x,y,640,360) for x,y in rows[0]+rows[1]+last],crop=None,scale=(640,360),size=20)
def make_labels(names,pdef,path):
    im=Image.new('RGBA',(1920,1080),(0,0,0,0)); d=ImageDraw.Draw(im); f=ImageFont.truetype(FNT,pdef['size'])
    for nm,(x,y,w,h) in zip(names,pdef['rects']):
        grad=np.zeros((90,w,4),np.uint8); grad[...,3]=(np.linspace(0,150,90)[:,None]*np.ones((1,w))).astype(np.uint8); im.alpha_composite(Image.fromarray(grad,'RGBA'),(x,y+h-90))
        ty=y+h-int(pdef['size']*0.9)-10; d.ellipse([x+14,ty-6,x+26,ty+6],fill=(134,188,37,255)); d.text((x+36,ty),nm,font=f,fill=(255,255,255,255),anchor='lm',stroke_width=1,stroke_fill=(0,0,0,200))
    im.save(path)
# ---------- graphics frames + commands
cmds=[]; segs=[]
def seq_dirs(rr,off,N,tag):
    rd=f'{ROOT}/reg/{tag}'; os.makedirs(rd)
    for k in range(N):
        t=off+k/48; os.symlink(rr.static if t>=rr.Tf+rr.trans else rr.blank,f'{rd}/{k:04d}.png')
    return rd
def make_item(label,ri,ii,it,rr,off,first):
    N=int(round(it['dur']*48)); D=N/48 if False else it['dur']; base=f'{ROOT}/items/{label}_i{ii:02d}'; dock=rr is not None
    rd=seq_dirs(rr,off,N,f'{label}_i{ii:02d}') if dock else None; td=f'{ROOT}/trans/{label}' if (dock and first) else None
    GX,GY=(rr.di['GX'],rr.di['GY']) if dock else (0,0)
    idx=[0]
    if it['kind']=='single':
        c=it['c']; n=c['n']; bx=BOX[n]; seg=c['real_end']-c['ss']; vl=vlen_of(c); gain=gain_for(c)
        seq=make_seq(n,f'v{label}{ii:02d}_{n}',D,root=ROOT+'/seq'); inputs=f'-ss {c["ss"]:.3f} -t {seg:.3f} -i "{c["src"]}" -framerate 48 -i {seq}/%04d.png'; nxt=2
        gi=None; ti=None
        if dock: inputs+=f' -framerate 48 -i {rd}/%04d.png'; gi=nxt; nxt+=1
        if td: inputs+=f' -framerate 48 -i {td}/%04d.png'; ti=nxt; nxt+=1
        if it.get('idle'):
            inputs+=f' -ss {it["idle"][0]:.3f} -t {it["idle"][1]+0.05:.3f} -i "{c["src"]}"'; ii_=nxt
            pre=f'[0:v]fps=16,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[cv];[{ii_}:v]fps=16,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[lv];[cv][lv]xfade=transition=fade:duration=0.25:offset={vl-0.25:.3f}[xv];[xv]'
        else: pre=('[0:v]'+squeeze_video(c)+'[vs];[vs]') if c['sq'] else '[0:v]'
        vf=f'{pre}setpts=PTS/{SPD},fps=48,delogo=x={bx[0]}:y={bx[1]}:w={bx[2]}:h={bx[3]},format=yuv420p[a];[1:v]format=rgba[tg];[a][tg]overlay=0:877:shortest=1[b0]'; last='b0'
        if gi is not None: vf+=f';[{gi}:v]format=rgba[gf];[{last}][gf]overlay={GX}:{GY}:shortest=1[b1]'; last='b1'
        if ti is not None: vf+=f';[{ti}:v]format=rgba[tr];[{last}][tr]overlay=0:0:eof_action=pass[b2]'; last='b2'
        if it['o'].get('final'): vf+=f';[{last}]fade=t=out:st={D-1.5:.3f}:d=1.5[b3]'; last='b3'
        vf+=f';[{last}]null[v]'
        if c['sq']:
            p1=(c['sq'][0]-c['ss'])+0.35; p2=(c['sq'][1]-c['ss'])-0.25
            core=f'asplit=2[b0][b1];[b0]atrim=0:{p1:.3f},asetpts=PTS-STARTPTS[aa];[b1]atrim={p2:.3f}:{seg:.3f},asetpts=PTS-STARTPTS[ab];[aa][ab]acrossfade=d=0.15,'
        else: core=''
        af='[0:a]aresample=32000,aformat=channel_layouts=mono,'+core+f'atempo={SPD},volume={gain:.2f}dB,alimiter=limit=0.89,apad=whole_dur={D:.3f},atrim=0:{D:.3f},afade=t=in:st=0:d=0.03,afade=t=out:st={D-0.06:.3f}:d=0.06[a]'
        cmds.append(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{vf};{af}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 19 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4 -map "[a]" -t {D:.3f} -c:a pcm_s16le -ar {SR} -ac 1 {base}.wav')
        segs.append(dict(round=ri,type='single',who=n,video=base+'.mp4',audio=base+'.wav',text=c['text']))
    elif it['kind']=='chorus':
        inputs=f'-i "{it["path"]}"'; nxt=1; gi=ti=None
        if dock: inputs+=f' -framerate 48 -i {rd}/%04d.png'; gi=nxt; nxt+=1
        if td: inputs+=f' -framerate 48 -i {td}/%04d.png'; ti=nxt; nxt+=1
        vf=f'[0:v]setpts=PTS/{SPD},fps=48,format=yuv420p[a]'; last='a'
        if gi is not None: vf+=f';[{gi}:v]format=rgba[gf];[{last}][gf]overlay={GX}:{GY}:shortest=1[b1]'; last='b1'
        if ti is not None: vf+=f';[{ti}:v]format=rgba[tr];[{last}][tr]overlay=0:0:eof_action=pass[b2]'; last='b2'
        vf+=f';[{last}]null[v]'
        cmds.append(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{vf}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4')
        cmds.append(f'ffmpeg -y -nostdin -v error -i "{it["path"]}" -vn -af "atempo={SPD},apad=whole_dur={D:.3f},atrim=0:{D:.3f}" -ac 1 -ar {SR} -c:a pcm_s16le {base}.wav')
        segs.append(dict(round=ri,type='chorus',who='+'.join(it['who']),video=base+'.mp4',audio=base+'.wav',text='(chorus)'))
    else:
        ms=it['ms']; n=len(ms); pd=panels(n); L=it['L']; PRE=it['PRE']; lab=f'{ROOT}/lab/{label}_i{ii:02d}.png'; make_labels([m['n'] for m in ms],pd,lab)
        inputs=' '.join(f'-ss {m["s"]:.3f} -t {L:.3f} -i "{m["src"]}"' for m in ms)
        inputs+=f' -loop 1 -framerate 48 -t {D:.3f} -i {lab} -loop 1 -framerate 48 -t {D:.3f} -i /home/claude/mont/re/logo.png'; nxt=n+2; gi=ti=None
        if dock: inputs+=f' -framerate 48 -i {rd}/%04d.png'; gi=nxt; nxt+=1
        if td: inputs+=f' -framerate 48 -i {td}/%04d.png'; ti=nxt; nxt+=1
        fv=''
        for k,m in enumerate(ms):
            bxk=BOX[m['n']]; chain=f'[{k}:v]fps=16,setpts=PTS-STARTPTS'
            if pd['crop'] is None: chain+=f',delogo=x={bxk[0]}:y={bxk[1]}:w={bxk[2]}:h={bxk[3]}'
            else: cx,cy,cw,ch=pd['crop']; chain+=f',crop={cw}:{ch}:{cx}:{cy}'
            if pd['scale']: chain+=f',scale={pd["scale"][0]}:{pd["scale"][1]}:flags=lanczos'
            fv+=chain+f',setsar=1,format=yuv420p[p{k}];'
        lay='|'.join(f'{x}_{y}' for x,y,w,h in pd['rects']); fv+=''.join(f'[p{k}]' for k in range(n))+f'xstack=inputs={n}:layout={lay}:fill=0x050e0f[st];[st]setpts=PTS/{SPD},fps=48,format=yuv420p[a];'
        fv+=f'[{n}:v]format=rgba,fade=t=in:st=0.03:d=0.15:alpha=1[lb];[a][lb]overlay=0:0:shortest=1[b0];[{n+1}:v]format=rgba[lg];[b0][lg]overlay=40:25:shortest=1[b1]'; last='b1'
        if gi is not None: fv+=f';[{gi}:v]format=rgba[gf];[{last}][gf]overlay={GX}:{GY}:shortest=1[b2]'; last='b2'
        if ti is not None: fv+=f';[{ti}:v]format=rgba[tr];[{last}][tr]overlay=0:0:eof_action=pass[b3]'; last='b3'
        fv+=f';[{last}]null[v]'
        att=-3*math.log2(n); fa=''
        for k,m in enumerate(ms):
            g=max(-12,min(15,-18.5-vol(m['src'],m['s'],min(L,m['kwdur']+0.6),'mean_volume')))+att; fo=0
            if it.get('gate'):
                a0=max(0.0,PRE-0.04); b0=min(L,PRE+m['kwdur']+0.05)
                fa+=f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,atrim={a0:.3f}:{b0:.3f},asetpts=PTS-STARTPTS,volume={g:.2f}dB,afade=t=in:st=0:d=0.02,afade=t=out:st={b0-a0-0.03:.3f}:d=0.03,adelay={int(a0*1000)}:all=1,apad=whole_dur={L:.3f},atrim=0:{L:.3f}[a{k}];'
            else:
                fa+=f'[{k}:a]aresample=32000,aformat=channel_layouts=mono,atrim=0:{L:.3f},asetpts=PTS-STARTPTS,volume={g:.2f}dB,afade=t=in:st=0:d=0.02[a{k}];'
        fa+=''.join(f'[a{k}]' for k in range(n))+f'amix=inputs={n}:normalize=0,afade=t=out:st={L-0.07:.3f}:d=0.07,atempo={SPD},alimiter=limit=0.89,apad=whole_dur={D:.3f},atrim=0:{D:.3f}[a]'
        cmds.append(f'ffmpeg -y -nostdin -v error {inputs} -filter_complex "{fv};{fa}" -map "[v]" -an -t {D:.3f} -c:v libx264 -preset fast -crf 19 -pix_fmt yuv420p -r 48 -g 96 -x264-params scenecut=0 {base}.mp4 -map "[a]" -t {D:.3f} -c:a pcm_s16le -ar {SR} -c:a pcm_s16le -ac 1 {base}.wav')
        segs.append(dict(round=ri,type='merge',who='+'.join(m['n'] for m in ms),video=base+'.mp4',audio=base+'.wav',text='(merge: '+it['label']+')'))
# cold open (no question, no dock)
t=0.0
for ii,it in enumerate(COLD):
    make_item('cold',-1,ii,it,None,t,False); t+=round(it['dur']*48)/48
say('cold open items queued')
for ri,rr in enumerate(R):
    items=ROUNDS[ri][2]; Nf=int(round(rr.Tf*48)); fl=f'{ROOT}/items/r{ri:02d}_flash.mp4'
    enc=subprocess.Popen(['ffmpeg','-y','-nostdin','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r','48','-i','-','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-g','96','-x264-params','scenecut=0',fl],stdin=subprocess.PIPE)
    for k in range(Nf): enc.stdin.write(np.asarray(rr.flash(k/48).convert('RGB')).tobytes())
    enc.stdin.close(); enc.wait(); segs.append(dict(round=ri,type='flash',video=fl,frames=Nf))
    td=f'{ROOT}/trans/r{ri:02d}'; os.makedirs(td)
    for k in range(int(round(rr.trans*48))): rr.transition(k/48).save(f'{td}/{k:04d}.png')
    rr.static=f'{ROOT}/reg/static_{ri}.png'; rr.dock_png.save(rr.static); rr.blank=f'{ROOT}/reg/blank_{ri}.png'; Image.new('RGBA',rr.dock_png.size,(0,0,0,0)).save(rr.blank)
    off=rr.Tf
    for ii,it in enumerate(items):
        make_item(f'r{ri:02d}',ri,ii,it,rr,off,ii==0); off+=round(it['dur']*48)/48
    say(f'round {ri+1} ready')
open(ROOT+'/items.sh','w').write('cd /home/claude\n'+'\n'.join(f'{c} || echo FAIL >> {ROOT}/items.err' for c in cmds)+f'\necho ALLDONE > {ROOT}/items.done\n')
json.dump(dict(segs=segs,rounds=[dict(Tf=rr.Tf,vo_t0=rr.vo_t0,vo_len=rr.vo_len) for rr in R]),open(ROOT+'/plan.json','w'))
say('STAGE_A_DONE',len(cmds),'commands')
