import numpy as np,wave,sys
from scipy.signal import butter,lfilter
SR=32000; BPM=116; BEAT=60/BPM; E8=BEAT/2
rng=np.random.default_rng(11)
def mid2hz(m): return 440*2**((m-69)/12)
def env_ad(n,a,d):
    t=np.arange(n)/SR; return np.minimum(t/max(a,1e-4),1)*np.exp(-t/d)
def lp(x,fc,order=2): b,a=butter(order,fc/(SR/2)); return lfilter(b,a,x)
def hp(x,fc,order=2): b,a=butter(order,fc/(SR/2),'high'); return lfilter(b,a,x)
def saw(f,n):
    t=np.arange(n)/SR; ph=(f*t)%1.0; return 2*ph-1
def pulse(f,n,w=0.35):
    t=np.arange(n)/SR; ph=(f*t)%1.0; return np.where(ph<w,1.0,-1.0)
def marimba(m,dur,vel=1.0):
    n=int(dur*SR); t=np.arange(n)/SR; f=mid2hz(m)
    x=np.sin(2*np.pi*f*t)+0.35*np.sin(2*np.pi*f*4*t)*np.exp(-t*18)+0.12*np.sin(2*np.pi*f*10*t)*np.exp(-t*40)
    return vel*x*env_ad(n,0.002,0.22)
def pluck_stab(ms,dur,vel=1.0):
    n=int(dur*SR); x=sum(pulse(mid2hz(m),n,0.3)+0.6*saw(mid2hz(m)*1.004,n) for m in ms)/len(ms)
    return vel*lp(x,2600)*env_ad(n,0.003,0.09)
def bass_note(m,dur,vel=1.0):
    n=int(dur*SR); f=mid2hz(m); x=np.sin(2*np.pi*f*np.arange(n)/SR)+0.5*lp(saw(f,n),500)
    return vel*x*env_ad(n,0.004,0.16)
def kick(vel=1.0):
    n=int(0.28*SR); t=np.arange(n)/SR; f=45+110*np.exp(-t*28); ph=2*np.pi*np.cumsum(f)/SR
    return vel*(np.sin(ph)*np.exp(-t*11)+0.25*hp(rng.standard_normal(n),3000)*np.exp(-t*90))
def clap(vel=1.0):
    n=int(0.22*SR); t=np.arange(n)/SR; x=hp(lp(rng.standard_normal(n),6500),1100)
    e=np.exp(-t*22)+0.6*np.exp(-((t-0.012)*160)**2)+0.5*np.exp(-((t-0.024)*160)**2); return vel*0.9*x*e
def hat(open_=False,vel=1.0):
    n=int((0.18 if open_ else 0.045)*SR); t=np.arange(n)/SR; x=hp(rng.standard_normal(n),7000); return vel*0.5*x*np.exp(-t*(16 if open_ else 70))
def shaker(vel=1.0):
    n=int(0.05*SR); t=np.arange(n)/SR; x=hp(rng.standard_normal(n),5000); return vel*0.25*x*np.minimum(t/0.01,1)*np.exp(-t*60)
CH=[(48,[60,64,67]),(43,[59,62,67]),(45,[60,64,69]),(41,[60,65,69]),(48,[60,64,67]),(43,[59,62,67]),(41,[60,65,69]),(43,[62,67,71])]   # C G Am F | C G F G
MEL=[[76,79,81,79,76,74,72,None],[74,76,79,76,74,76,79,None],[76,79,81,84,81,79,76,None],[72,74,76,79,76,74,72,None],
     [79,81,79,76,79,81,84,None],[79,76,74,76,79,76,74,None],[81,79,76,74,72,74,76,None],[74,76,79,81,79,76,74,79]]
def render(total_s):
    n=int(total_s*SR)+SR*2; out=np.zeros(n,np.float32); loop=8*4*BEAT; loops=int(np.ceil(total_s/loop))+1
    def add(x,t,g=1.0):
        s=int(t*SR); 
        if s<0 or s>=n: return
        x=x[:n-s]; out[s:s+len(x)]+=(g*x).astype(np.float32)
    for L in range(loops):
        t0=L*loop; section=L%4; full=L>=1; mel=(L%2==1) or L>=4; breakdown=(L%4==3)
        for bar in range(8):
            tb=t0+bar*4*BEAT; root,ch=CH[bar]
            for step in range(8):                       # 8th notes with light swing
                sw=0.10*E8 if step%2==1 else 0.0; ts=tb+step*E8+sw
                vel=0.85+0.15*rng.random()
                add(hat(False,vel if step%2==1 else 0.7*vel),ts,0.55)
                if step in (3,7) and bar%2==1: add(hat(True,0.8),ts,0.5)
                if full: add(shaker(0.8+0.2*rng.random()),ts+E8*0.5,0.5)
                # bouncy bass: root, octave, root, rest pattern
                pat=[0,12,0,None,0,12,7,None][step]
                if pat is not None: add(bass_note(root+pat,E8*0.9,0.9*vel),ts,0.55 if full else 0.45)
                # chord stabs on the off-beats
                if step in (3,6) or (step==7 and bar%2==1): add(pluck_stab(ch,E8*0.8,vel),ts,0.20 if L>=1 else 0.12)
                m=MEL[bar][step]
                if mel and m is not None: add(marimba(m,0.5,vel),ts,0.34)
            if not breakdown:
                for b in (0,2): add(kick(1.0),tb+b*BEAT,0.9)
                if bar%2==1: add(kick(0.8),tb+3.5*BEAT,0.7)
            for b in (1,3): add(clap(1.0),tb+b*BEAT,0.55 if not breakdown else 0.4)
            # soft pad under everything
            pn=int(4*BEAT*SR); pad=sum(np.sin(2*np.pi*mid2hz(m-12)*np.arange(pn)/SR) for m in ch)/3; w=np.minimum(np.arange(pn)/(0.2*SR),1)*np.minimum((pn-np.arange(pn))/(0.3*SR),1); add(pad*w,tb,0.05)
    out=out[:int(total_s*SR)]; fo=int(2.5*SR); out[-fo:]*=np.linspace(1,0,fo).astype(np.float32)
    out=hp(out,35); out/= (np.abs(out).max()+1e-9); return out.astype(np.float32)
if __name__=='__main__':
    T=float(sys.argv[1]) if len(sys.argv)>1 else 200; x=render(T)
    rms=np.sqrt((x**2).mean()); x=x*(10**(-18/20)/rms); x=np.clip(x,-0.98,0.98)
    with wave.open('/home/claude/final3/music.wav','wb') as f: f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR); f.writeframes((x*32767).astype(np.int16).tobytes())
    print('music',T,'s rms -18 dB, peak %.2f'%np.abs(x).max(),'loop %.1fs'%(8*4*BEAT))
