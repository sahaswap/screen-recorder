import re
CAPS='/home/claude/caps/'
def cues(n):
    out=[]
    for b in open(CAPS+n+'.srt').read().strip().split('\n\n'):
        l=b.split('\n'); m=re.findall(r'(\d+):(\d+):(\d+),(\d+)',l[1])[0]
        t=int(m[0])*3600+int(m[1])*60+int(m[2])
        out.append((t,' '.join(l[2:])))
    return out
# (video, text to find, why)
ITEMS=[
 ('Ananya','Quite until Monday','three-words answer – sounds garbled'),
 ('Ananya','new laymen','probably a different word'),
 ('Ananya','look quite first','probably a different word'),
 ('Arijit','all-hand meets','phrase looks garbled'),
 ('Arijit','failed and delighted','two words he mentions – please confirm'),
 ('Arijit','at this time of the year','sentence looks garbled'),
 ('Irin','7 Rings','my best guess (heard as "7 drinks")'),
 ('Malavikka','Deloitte Hill','unclear word after "Deloitte"'),
 ('Malavikka','your name,','garbled question wording'),
 ('Shobhita','how much.','sentence looks cut / garbled'),
 ('Shobhita','making me feel','probably "making others feel"'),
 ('Riddhima','that met','garbled – likely "my team needs to"'),
 ('Riddhima','Wake Up Sid','my best guess (heard as "Wake Up Sit")'),
 ('Riddhima','that is why I','sentence looks garbled'),
 ('Ayush','Avicii','my best guess (heard as "ABC")'),
]
rows=[]
for n,p,why in ITEMS:
    cs=cues(n); hit=[c for c in cs if p.lower() in c[1].lower().replace('\n',' ')]
    if not hit:
        # phrase may span two cues
        for i in range(len(cs)-1):
            if p.lower() in (cs[i][1]+' '+cs[i+1][1]).lower(): hit=[cs[i]]; break
    t=hit[0][0] if hit else None
    rows.append((n,t,p,why,hit[0][1] if hit else ''))
    print(n,f"{t//60}:{t%60:02d}" if t is not None else 'NOT FOUND',p,'|',hit[0][1] if hit else '')
