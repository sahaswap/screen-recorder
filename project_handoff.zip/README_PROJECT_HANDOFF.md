# AML "Share a Story" – Project Handoff
*Everything asked, everything built, every decision and measurement, up to 16 Nov 2026. Written so a brand-new chat can continue without any history.*

---

## 0. TL;DR – where we are right now

**Goal:** turn nine Teams recordings of new hires (Deloitte AML team) into one short, fun Q&A video, in an F1-"quick-fire questions" style but with Deloitte branding.

**Latest deliverables (use these):**

| What | File (in `/mnt/user-data/outputs/`) | Notes |
|---|---|---|
| **Current master video** | `final_video/ShareAStory_QnA_v23.mp4` | 2:56 (176 s), 1080p 48 fps, 53.5 MB. Built from `QnA.xlsx` picks, with title cards, Deloitte opening, closing, whole-video lip-sync correction |
| **Compressed (<25 MB), main** | `final_video/under_25MB/ShareAStory_QnA_v23_1080p_HEVC_20MB.mp4` | HEVC 1080p, 20.2 MB, SSIM 0.991 |
| **Compressed (<25 MB), fallback** | `final_video/under_25MB/ShareAStory_QnA_v23_720p_H264_17MB.mp4` | H.264 720p, 16.6 MB – plays everywhere |
| Transcripts workbook | `transcripts/AML_ShareAStory_transcripts.xlsx` | all 99 answers by question + per-person full transcripts |
| Analysed workbook | `transcripts/AML_ShareAStory_transcripts_analysed.xlsx` | + insights, suggested picks, merge ideas |
| Opening demo | `opening_demo/Opening_demo_welcome_to_Deloitte.mp4` | title cards + Deloitte flash + first question (older audio settings) |
| This handoff bundle | `project_handoff.zip` | all scripts + small data files (see section 12) |

**Hard constraints from the user:** max length 3:30 · files under 25 MB for sharing · fun parts only · no zoom · hard cuts · merged "same-word" split-screens go first in each round · Deloitte Green · no bubble/swoosh sounds on the question card.

**Biggest open risks:** nothing has been *watched/listened to* by the assistant (only measured); the lip-sync correction is statistical (see §8); music licence/credit unconfirmed (§7); one flash word differs from what the user typed (§10).

---

## 1. People and source material

Nine participants, Teams recordings (1080p, ~16 fps, ~1 Mbps; each starts with a ~2 s Teams title card, then silence, then speech; a purple Teams name label sits bottom-left and is removed with `delogo`). Original uploads live in `/mnt/user-data/uploads/` (**the user must re-upload them in a new chat**).

| Key | Name | Role | Location | Client | Source file |
|---|---|---|---|---|---|
| Malavikka | Malavikka Subash | Analyst | Bengaluru | TD Bank | `AML_ShareAStory_Malavikka_Subash.mp4` |
| Monesh | Monesh M C | Senior Consultant | Bengaluru | TD Bank | `AML_ShareStory_MONESH_MC.mp4` |
| Riddhima | Riddhima Gupta | Associate Analyst | Pune | Synovus | `AML_ShareAStory_Riddhima_Gupta.mp4` |
| Mohammed | Mohammed Maqsood | Associate Analyst | Bengaluru | Walmart | `AML_ShareAStory_Mohammed_Maqsood.mp4` |
| Ananya | Ananya K | Associate Analyst | Hyderabad | CFSB | `AML_ShareAStory_Ananya_K.mp4` |
| Irin | Irin Winona S | Associate Analyst | Hyderabad | TD Bank | `AML_ShareAStory_Irin_WinonaS.mp4` |
| Arijit | Arijit Sarkar | Consultant | Kolkata | Visa | `AML_ShareAStory_Arijit_Sarkar.mp4` |
| Ayush | Ayush Bhalotia | Associate Analyst | Pune | Banco Santander | `AML_ShareAstory_Ayush_Bhalotia.mp4` |
| Shobhita | Shobhita P Hegde | Analyst | Bengaluru | TD Bank | `AML_ShareAStory_Shobhita_Hegde.mp4` |

Four other roster people have no videos: Kenneth G, Mansi Bhalla, Subhajit Gupta, Palak Daftari.

Other files the user uploaded over the project: the F1 reference video (`Adobe_Express_-_vidssave_com_Putting_The_2026_F1_Grid_On_The_Spot_With_Quick-fire_Questions_480P-4.mp4`), `QnA.xlsx` (the user's edit list), and the music `…Corporate_Motivational_by_Infraction__No_Copyright_Music____Clouds_In_Motion_128KBPS.mp3`.

## 2. The 11 questions (numbering used everywhere)

| Q# | Question |
|---|---|
| 1 | Introduce yourself in 3 words |
| 2 | Complete: "My Deloitte journey is going to be / has been…" |
| 3 | What's something you're unexpectedly (or weirdly) good at? |
| 4 | What surprised you about your first week? |
| 5 | What's one thing the new team should know about you? |
| 6 | What's your hidden talent? |
| 7 | What are you looking forward to the most? |
| 8 | Describe your new team in one word |
| 9 | If your life had a theme song (book/movie title), what would it be? |
| 10 | What's the most common phrase you've heard after joining Deloitte? |
| 11 | Describe your project in one word |

Note: in the recordings most people read the question aloud and answer; Ayush, Irin and Monesh answer without reading it; Monesh and Shobhita answer in a different order. Unanswered: Monesh Q3 and Q10, Riddhima Q4, Ayush Q10, Shobhita Q7.

---

## 3. What was asked and what was delivered (chronological)

### Phase 1 – per-person videos (earlier chat)
| Ask | Output |
|---|---|
| Compress Riddhima's video under 25 MB | H.265 two-pass → `AML_ShareAStory_Riddhima_Gupta_compressed.mp4` (23.3 MB) |
| Cut dead air: shorten long pauses (~0.9 s+ → ~0.5 s with 0.25 s dissolves), drop leading Teams title card, trim trailing silence, fade out | `…_trimmed.mp4`, then the same for all 9 → `softcut/` |
| Captions | made, later **removed at user request** (`captioned/`, SRT zip, review md still in outputs, obsolete) |
| Bottom-left name/info tag | iterated: small text → green block → CNBC strap → compact card → **animated "node and line" tag (chosen)**: name / role · location / "Client: X", 48 fps. Purple Teams label removed everywhere. Finals: `final_node_line/` (other folders = superseded variants) |
| Per-question montages Q01–Q11 + all-questions montage | `montage/` |
| Curated Q&A cut (10 rounds, ~47 clips), several re-edits (dissolves, split-screens, buffers; Riddhima Q2 removed because of a real ~1.1 s camera stall; Riddhima plays at true 100 %) | `curated_cut/Curated_QnA*.mp4`, last = `Curated_QnA_reedit_v2.mp4` (4:47, 65 MB) |
| Analyse the F1 "quick-fire" video as the style model | see §4 |

### Phase 2 – F1-style redesign (this chat)
1. **F1 analysis** (§4) → proposed: cold open, typed question card, hard cuts, tight rhythm.
2. **Demo iterations on Q1:** tally bar and "QUICKFIRE" tag tried then dropped; bubble designs compared (comic green, black, neon, white card…) → user chose the **neon bubble** (dark fill, glowing Deloitte-green outline, halftone dots, "?" badge, Poppins Bold text).
3. **Placement problem:** bubble landed on faces → measured every speaker's chin height (Haar face boxes) and placed the bubble below the chin / left space; later replaced by the **docked bar** (§5.4).
4. **Full-screen flash card** of the question first, then the bubble flies down and becomes the docked bar.
5. **Zoom removed** (130 % punch-in was disliked): every clip keeps original framing.
6. **Spoken question (synthetic voice):** Kokoro (local, via sherpa-onnx). Tried Heart → Bella 1.22× (matched to F1 delivery) → user said too fast → **Emma (`bf_emma`) at 0.92×**. Azure `en-US-AnaNeural` / `AvaMultilingualNeural` and ElevenLabs were researched but **cannot be reached from the sandbox** (user would have to generate audio themselves). Kokoro cannot say "Deloitte" and skips "What's" at sentence start (use "What is").
7. **Merges (split-screens):** people saying the same word are shown side by side, sound = just that word, normal pace. User loved "I would say welcoming" and "Love You Zindagi".
8. **Cut to ≤ 3:30, fun parts only** → 3:02 cut, then 2:33 rebuilds.
9. **Deloitte brand moment:** official lockup (from the Deloitte PPT template SVG, recoloured white) pulsing over a hazy→clear grid of the nine people; the team says "Deloitte" once (softened); tagline "Together makes progress"; opening ends the instant the lockup leaves; bar-aligned to the music.
10. **Title cards:** "*Welcome* our 2026 New Hires" → "Let's hear them share their *stories*" / "and answer some fun questions." / "(no pressure… mostly)". Accent words = Open Sans Bold Italic in Deloitte Green (user asked for bold + italic after the serif italic didn't read as italic).
11. **Music:** synthetic placeholder → user's **Infraction "Clouds In Motion"** (118 BPM). Everything beat-timed was retuned to 118 BPM.
12. **Audio clean-ups (all user-requested):** remove question-bubble pop; remove the swoosh when the card flies down; remove per-word ticks/chimes on title cards; team "Deloitte" 8 dB softer; music at 50 %; spoken question at 75 % then a further 20 % (= 60 %).
13. **Lip-sync work** (§8), repeated several times; final whole-video correction in v23.
14. **Transcripts → Excel → analysis → user's `QnA.xlsx`** (§9) → v22 rebuild → v23 sync fix.
15. **Compression under 25 MB** (§11).

---

## 4. F1 reference video – what it taught us
`854×480, 25 fps, 485 s`. Cold open straight into Q1 (no title card); off-screen voice reads each question while a **typed-on comic speech-bubble card** appears (mint fill, white outline, halftone dots, tilted lime "QUICKFIRE" tag); ~16 questions, ~15–20 drivers each, 1–3 word answers; **260 cuts (~32/min), median shot 1.4 s, 259/260 hard cuts**; ~70 % close-ups, ~25 % wide; no name labels; tally bar for binary questions; continuous music bed (voice ≈ 20 dB above bed). Question voice measured: median pitch ≈ 200 Hz, ≈ 4.9 syllables/s, falling end (~-90 Hz), ≈ +1 dB vs answers, mono. The user later said matching F1 was *not mandatory*.

---

## 5. Final video design (v22/v23)

### 5.1 Timeline of v23 (175.98 s)
`intro 8.54 s` → rounds → `closing 3.56 s`.

* **Intro:** title card 1 (1 bar, 2.03 s) → title card 2 (2 bars, 4.07 s) → cross-fade (0.3 s) → Deloitte opening starting at **T0 = 12 beats = 6.10 s** (hazy grid → clear grid as "Deloitte." pops on beat 1 → ring pulses on beats 1-3 → team says "Deloitte" at the first pulse (beat 2) → tagline rises on beat 3 → lockup zooms through and fades by 0.8 beat after beat 4; opening length 2.44 s).
* **Rounds, in this order** (the spreadsheet row order): **Q1, Q3, Q4, Q6, Q11, Q8, Q9, Q10**. Each round = full-screen flash card (typed-on neon bubble + spoken question, 2–3.6 s) → the card shrinks/moves into the docked bar while the background dissolves into the first clip → clips.
* **Closing:** hazy→clear grid again, "Deloitte." pulse + team "Deloitte" + tagline, hold, fade to black (3.56 s).

### 5.2 Content per round (from `QnA.xlsx`)
| Round | Items in order |
|---|---|
| **Q1** Introduce yourself in 3 words | merge **"curious"** (Mohammed, Riddhima, Shobhita, Ayush, Arijit) · Malavikka · Irin · Ananya (ASR garbled: "sweet… quite until Monday and curious") · Monesh |
| **Q3** unexpectedly good at | Ananya (read minds) · Irin (Excel magic) · Riddhima (guesses song from first notes) · Arijit (cooking Italian; clip ends at source time 63.50 s because he adds an afterthought later) |
| **Q4** first week | merge **"welcoming" + flash word "Welcoming"** (Mohammed, Shobhita) · Ananya (passwords) · Ayush (people willing to help) |
| **Q6** hidden talent | merge **"dancing"** (Malavikka, Irin, Ananya) · Riddhima (packing) · Ananya (overthinker) · Shobhita (making connections) · Monesh (**trimmed** to "…connect dots… think on my feet") |
| **Q11** project in one word | merge **"dynamic" + flash "Dynamic"** (Malavikka, Mohammed) · Riddhima · Irin (detectives) · Arijit (awesome) · Ayush (Intriguing) · Monesh ("…follow the money, analyze and report") — Ananya removed |
| **Q8** team in one word | merge **"supportive" + flash "Supportive"** (Malavikka, Ananya, Shobhita) · merge **"welcoming"** (Mohammed, Ayush) · Arijit (synergistic) · Monesh (financial superheroes… money laundering and terrorist financing) |
| **Q9** theme song | merge **"Love You Zindagi"** (Malavikka, Ananya) · Irin (7 Rings) · Riddhima (Wake Up Sid) · Shobhita (Shin Chan) · Ayush (The Nights) · Monesh (Kabhi Khushi Kabhie Gham) · Arijit (Don't Stop Me Now) |
| **Q10** phrase (**moved to the end**) | merge **"connect"** (Malavikka, Ananya) · Irin (timesheet) · Mohammed (networking ×3 … "first official Deloitte skill") → then the Deloitte closing |

Dropped entirely: Q2 (Deloitte journey), Q5 (one thing about me), Q7 (looking forward). Removed by user request: Shobhita's "welcome to Deloitte" phrase answer and her "disconnect/ODC" answer.

Rules: singles play at **1.2×**; merges at **1.0×**; merges that open a round start their picture 0.8 s before the shared word (so it lands after the card settles); merge sound = the shared word only (boundaries confirmed by recogniser, §7).

### 5.3 Style
* **Colours:** Deloitte Green **#86BC25** (accent words, ring, bubble glow, dock outline, flash words); neon accent #86EB22 tried, not used in the end; dark background/glow from `pause_bg.png`; white text. Brand font Stix Two Text is **not installed** – accent words use **Open Sans Bold Italic** (this deviates from the brand's serif-italic accent; user preference).
* **Fonts:** Open Sans Bold/Regular (headlines, tags), Poppins Bold (question bubble text), Open Sans Bold Italic (accent words and flash words).
* **Tags:** animated node-and-line name tag bottom-left on every clip (name / role · location / Client). Merges use panel name labels instead.
* **Deloitte logo:** official vector lockup from `/mnt/skills/plugins/deloitte-pptx/assets/template.pptx` (`ppt/media/image3.svg`), recoloured white; top-left corner logo overlaid on merges.

### 5.4 Docked question bar (consistent, whole round)
Rounded pill, dark fill, green glow outline, green "?" disc + question text (Poppins Bold 28–34 px). Left edge **x = 560**, top **y = 968**, same spot in every round; it stays until the next flash card. (Chin heights: lowest speaker Ananya at ~y 921, so it clears every face.)

### 5.5 Flash words
Big bold-italic Deloitte-green word (Open Sans Bold Italic 170 px, dark outline + soft glow) pops over the split-screen at the shared word for ~1 s (region y 690–970).

### 5.6 Audio mix (all at 32 kHz mono, AAC 160 kbps in the master)
* Speech: each solo clip evened to the median active RMS (max ±5 dB).
* **Music:** "Clouds In Motion", trimmed 0.024 s so it starts on the downbeat; normalised to RMS −18 dBFS, then ×10^(−9/20) × **0.5**; ducked by 0.6 × speech envelope under any voice; whole-video fade-out 1.5 s.
* **Spoken questions:** Emma 0.92×, normalised to RMS −20.4 dBFS then × **0.60**.
* **Team "Deloitte"** (4 real voices: Mohammed, Shobhita, Irin, Arijit, word-only cuts) : −6 dB offset, 50 ms fade-in, 90 ms fade-out; used at opening beat 2 and again in the closing.
* Effects kept: low thump on beats 1-3, shimmer on beat 3, whoosh as the lockup zooms (opening only); two soft sweeps as the title cards leave. Removed: bubble pop, swoosh on the question card, word ticks, chimes.

---

## 6. Music
Infraction – "Clouds In Motion" (Corporate Motivational), 185.1 s, **118.00 BPM**, first downbeat 0.024 s, grid stable within ±4 ms across the track; breakdown (quieter) at ≈ 1:20–1:36. Playlist: Infraction "Corporate No Copyright Music" (126 tracks). Only the first ~2:56 is used. **Licence/credit terms not confirmed** – if credit is required add e.g. "Music: 'Clouds In Motion' by Infraction (No Copyright Music)". Also check Deloitte's own policy.

---

## 7. Word-boundary data (critical lesson)
ASR transcript timestamps are **loose (±0.1–0.3 s, ends worst)**. For anything word-accurate (merges, the team "Deloitte"), every word was located by an **ASR-in-the-loop search**: try cut windows around the transcript time, keep those the recogniser hears as exactly the word, take the central one. Results are in `data/word_bounds.json` (19 shared words, all confirmed), `data/cold_words*.json` (the 9 "Deloitte" words; Ayush's is not recogniser-confirmable, transcript timing used), `data/connect_words.json`. The recogniser fails on overlapping voices, so merged audio itself can only be checked by level, not by transcription.

---

## 8. Lip-sync – the full story (read before touching audio timing)
* **Finding (final):** in nearly every recording the **sound arrives ~0.11–0.25 s after the picture** (audio late). Evidence: (a) syllable-rhythm cross-correlation between landmark lip-opening (mediapipe FaceMesh **0.10.14**; newer versions lack the bundled-model API) and the voice's 1.5–6.5 Hz envelope; (b) onset-event test (speech onset after a pause vs lip opening); pooled median **+171 ms over 94 events**. Streams start together (no container offset). Estimator sign verified with a synthetic +200 ms test.
* **Per-person correction applied in v23** (`TAU`, seconds the picture leads the sound; implemented as: video window starts earlier by τ, audio window unchanged; for merges the audio atrim starts τ later, adelay = PRE):

| Person | τ | Evidence quality |
|---|---|---|
| Malavikka | 0.16 | rhythm +160, events +144; user confirmed ~0.12 "right" earlier |
| Ananya | 0.20 | rhythm +237 (tight blocks) – **conflicts with user's earlier report** (see below) |
| Mohammed | 0.17 | rhythm +151, events +173 |
| Irin | 0.17 | **weak** – own measurements noisy; common value used |
| Riddhima | 0.195 | rhythm +196, events +241 |
| Ayush | 0.195 | rhythm +247, events +195/+249 |
| Shobhita | 0.15 | rhythm +114, events +154/+124 |
| Arijit | 0.18 | rhythm +210, events +164/+211 |
| Monesh | 0.16 | rhythm +156, events +146 |

* **Verification in the finished video** (residual offset, + = sound late) v22 → v23: Ananya +231→+58, Ayush +192→+39, Arijit +140→−1, Monesh +122→−15, Riddhima −55→+42 ms. **Mohammed, Shobhita, Irin could not be verified** (too little solo footage in the cut; readings noisy).
* **Unresolved conflict:** after an earlier partial advance (0.095 s) the user said *Ananya's sound ran before her mouth*; measurements say her sound is among the latest. If she still looks wrong the other way, reduce her τ.
* Earlier crude methods (frame-difference mouth motion, whole-envelope correlation) were unreliable – do not reuse. Bugs found on the way: `setpts=PTS-STARTPTS` on merge video inputs shifts each panel by up to 62 ms (removed).

---

## 9. Spreadsheets
* `transcripts/AML_ShareAStory_transcripts.xlsx` – sheets: README, All answers (Q#, question, person, location, role, client, question read aloud, answer, video time, length, "In current video?", Your pick, Your notes), By question, one sheet per person. Answers were matched to questions by content (SPEC phrases in `spans_all.py`).
* `…_analysed.xlsx` – adds Insights, Suggested picks, Merge ideas and suggestion columns (my editorial ratings).
* **`QnA.xlsx` (user's edit list)** – the sheet order is the video order; fill colours are instructions: **green = selected, purple = include (Q1: Monesh, Ananya, Irin), blue = add (Q3 Riddhima; Q6 Monesh, Shobhita), red = removed (Q11 Ananya), yellow = merge & flash the shared word**. Comments: Q4 "Merge and flash the 'Supportive' from the two", Q6 "Cut Monesh's a bit – snooze fest", Q8 "Merge and flash 'Supportive' from all three", Q11 "Can flash Dynamic", Q10 "Moving this to the bottom – ki last me wo Deloitte wala bhi aa jaaye and closing". Cell text was unchanged from my transcripts.

Key analysis facts: 94/99 answers exist; "curious" in 6/9 intros; Deloitte said 25× in total; AML vocabulary almost only from Monesh; fastest speaker Riddhima (~3.1 words/s).

---

## 10. Interpretations, assumptions and things to confirm with the user
1. **Q4 flash word:** sheet says "Supportive" but the two highlighted answers (Mohammed, Shobhita) both say *welcoming* → flashed **"Welcoming"**.
2. **"…wo Deloitte wala bhi aa jaaye and closing"** read as: phrase round last (ends on "official Deloitte skill") then a Deloitte closing card.
3. Ananya's Q1 words are uncertain (garbled transcript).
4. Ananya sync conflict (§8); Irin's offset is a guess.
5. Music credit/licence (§6); brand lockup restrictions (A&A/Tax, sub-brands, co-branding) – user should confirm this internal piece is allowed.
6. Accent font deviates from brand (Stix Two Text unavailable).
7. Nothing has been watched/listened to by the assistant; only numbers (levels, SSIM, correlation, glitch scans) and frame contact sheets.

---

## 11. Compression (<25 MB)
Master is 53.5 MB. Two outputs: **HEVC 1080p 48 fps**, x265 `-preset fast -crf 26 -x265-params vbv-maxrate=900:vbv-bufsize=2250`, `-tag:v hvc1`, AAC 96k mono → **20.2 MB**; **H.264 720p** `-preset medium -crf 24 -maxrate 900k -bufsize 2250k` → **16.6 MB**. Sampled quality vs master (352 frames at 720p): SSIM 0.991 / PSNR 47.1 dB (HEVC), SSIM 0.991 / 45.4 dB (H.264). Encode time ≈ 10 min (HEVC) + 4 min.

---

## 12. Technical pipeline (how v23 was built) and the handoff bundle
**Environment limits:** 1 CPU core, ~4 GB RAM, ~5 GB disk; tool calls time out at ~300 s → run long jobs with `setsid nohup … &` and poll; background jobs can die if a turn ends mid-run; **never `pkill -f` a pattern that matches your own command line**; many-input xfade / `-itsoffset` chains can OOM or deadlock; no internet except pypi/GitHub/npm (no YouTube, ElevenLabs, Azure TTS).

**Not in the bundle (re-download/re-upload):** source videos, the music mp3, Kokoro TTS model (`kokoro-multi-lang-v1_0` from the sherpa-onnx `tts-models` GitHub release, ~350 MB), Parakeet-TDT ASR model (sherpa-onnx), tag-frame cache (`mont/cache`, 30 MB; regenerate with the tag scripts), the Deloitte PPT template (skill folder `/mnt/skills/plugins/deloitte-pptx`).

**To restore the bundle in a new chat:** `unzip -o project_handoff.zip -d /` (entries are stored as `home/claude/...`, so this recreates `/home/claude/...` exactly; data such as `QnA.xlsx` and the two transcript workbooks are under `data/`, the readme at the zip root). System dependencies seen in this project: `ffmpeg` with libx264/libx265/libass, Python 3.12 with numpy, scipy, Pillow, opencv, openpyxl, cairosvg, fonttools, parselmouth (praat-parselmouth), **mediapipe==0.10.14**, sherpa-onnx (ASR + Kokoro TTS). Poppins Bold is a system font (`/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf`); Lora (a stand-in italic that was later replaced) was not kept.

**Key scripts** (all in `project_handoff.zip` → `code/`):
| Script | Role |
|---|---|
| `captions.py`, `spans_all.py`, `reedit_lib.py`, `transcribe.py` | transcripts → word lists (`words(n)`, `locate`, `orig_time`), clip definition (`clip_def`, tails, squeeze), helpers (`BOX`, `vol`, `make_seq`, `gain_for`) |
| `final3/gfx_final.py`, `final3/gfx_v3.py` | neon bubble, flash card→dock transition, docked bar |
| `final4/word_bounds.py` | recogniser-confirmed word boundaries |
| `final4/make_build_v4.py` → `build_v4.py` | **Stage A**: voice-overs (Kokoro Emma), round objects, graphics frames, merge/flash builders, writes `w/items.sh` + `w/plan.json` |
| `w/items.sh` | **Stage B**: encodes every clip/merge (≈8–10 min) |
| `final4/intro_outro.py open|close`, `demo_open/titles.py`, `final4/assemble_intro.py` | opening, closing, title cards, intro join |
| `final4/finalize_v4.py` | **Stage C**: concatenates, builds the whole soundtrack (levels, ducking, SFX, music), muxes `w/final.mp4` |
| `final4/patch_sync.py` | applies the per-person lip-sync τ to `items.sh` (run after Stage A, before Stage B) |
| `sync/*.py` | lip-sync measurement (`lipsync_mp.py`, `lipsync_bp.py`, `events2.py`, `both.py`, `measure_final.py`) |
| `xl/*.py` | spreadsheet builders |
| `compress/run.sh`, `q.sh` | compression and SSIM/PSNR |

**Rebuild order:** `word_bounds.py` → `make_build_v4.py` → `python3 build_v4.py` → copy `brand.wav` + `lab/cold_single.png` into `w/` → `patch_sync.py` → `sh w/items.sh` → `intro_outro.py open` and `close` → `assemble_intro.py` → `finalize_v4.py`. (Better: fold `patch_sync` into `build_v4` so τ is applied at generation time.)

**To change content:** edit the `ROUNDS` block in `make_build_v4.py` (`S(person,start-phrase,end-phrase)` for solos, `MG(key,[names],flash=word)` for merges; merges need entries in `word_bounds.json`), then rebuild. First item of each round is flagged `first=True` (longer lead-in).

**Verification routine used every time:** `ffmpeg -v error -i f.mp4 -f null -` (clean decode) · A/V duration equal · glitch scan (Teams grey "AS" avatar disc, stray black frames) · per-segment loudness table · per-round ASR transcript order check · frame contact sheets · for sync: `measure_final.py`.

---

## 13. Lessons learned / pitfalls
* Teams recordings contain **camera dropouts** (a grey avatar disc, e.g. "AS" for Arijit; Ananya has long ones) – avoid borrowing "idle" footage from the start of recordings; scan outputs for them.
* Kokoro: skips "What's" at sentence start; cannot pronounce "Deloitte"; use "What is…".
* Transcript timings are loose; always validate word cuts (§7).
* Don't compute volume/loudness metrics in frequency bands masked by music; use subtraction against an earlier render to prove what changed.
* Removing one random-noise effect changes the random draw for later noise effects (shared RNG) – use separate seeds if byte-identical audio matters.
* First-in-round merges are covered by the transition for ~0.7 s – give them lead-in.
* mediapipe must be 0.10.14 for the bundled face model; the first lip-sync method (frame-diff) was misleading.

---

## 14. Version ladder of the master (for reference; all in `final_video/`)
`ShareAStory_QnA_final` (4:47, first full) → `3min_cut` (3:02) → `v3` (2:33 dock + merges + Emma + placeholder music) → `v4` (opening without Monesh AML clips) → `v5` (merge sync + round-end tails) → `v6` (word-only big grids) → `v7` (single Deloitte hit, validated) → `v8` (official lockup opening) → `v9` (grid behind tagline + team "Deloitte") → `v10` (hazy→clear grid, no black) → `v11` (opening ends when lockup leaves) → `v12` (first per-person sound advance) → `v13` ("connect" split normal pace) → `v14` (Ananya shift removed) → `v15` (bubble pop removed) → `v16` (Clouds In Motion, retimed 118 BPM) → `v17` (swoosh removed) → `v18` (team "Deloitte" softer) → `v19` (music 50 %) → `v20` (questions 75 %) → `v21` (questions 60 %) → **`v22` (rebuilt from QnA.xlsx: order, picks, flashes, title cards, closing)** → **`v23` (whole-video lip-sync correction; current)**. Everything before v22 is superseded.

---

## 15. Prompt to paste into a new chat
> I'm continuing the AML "Share a Story" video project. Please read `AML_ShareAStory_PROJECT_HANDOFF.md` and unzip `project_handoff.zip` into `/home/claude` (code → `/home/claude`, data → as listed). The current master is `ShareAStory_QnA_v23.mp4`; compressed versions are under `final_video/under_25MB/`. I'll re-upload the nine source videos and the music file. Before changing anything, confirm you've understood §0 (constraints), §5 (design) and §8 (lip-sync).

## 16. Suggested next steps
1. User reviews v23 by eye/ear: especially Ananya, Irin, Mohammed, Shobhita sync (§8) and the Q4 flash word (§10).
2. Fix music credit/licence; add credit line if required.
3. Fold per-person τ into `build_v4.py`; optionally re-measure Irin with more footage.
4. Any further content swaps via `ROUNDS`; re-compress to <25 MB afterwards (§11).
